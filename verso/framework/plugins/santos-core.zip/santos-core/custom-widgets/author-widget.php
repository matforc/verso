<?php


function santos_author_info_widget_init() {
	register_widget('santos_author_info_Widget');
}

add_action('widgets_init', 'santos_author_info_widget_init');


class SANTOS_author_info_Widget extends WP_Widget {		

	var $sites = array(
            'dribbble', 
            'dropbox', 
            'facebook', 
			'twitter', 
            'github', 
            'google', 
            'googleplus', 
            'linkedin',
            'instagram', 
            'pinterest', 
            'rss', 
            'skype', 
            'tumblr', 
            'vimeo', 
            'wordpress', 
            'yahoo', 
            'youtube',
            'whatsapp',
	);

	function __construct() {
		
		$widget_ops = array(
		'classname' => 'santos_author_info_widget', 
		'description' => esc_html__( "Author Info widget at the footer.",'santos')
		);
				
		parent::__construct('author-info', 'Santos' . ' - ' . esc_html__('Author Info', 'santos'), $widget_ops);
		
		add_action('admin_enqueue_scripts', array($this, 'upload_scripts'));
	}
	
	
	/**
     * Upload the Javascripts for the media uploader
     */
    public function upload_scripts()
    {
        wp_enqueue_script('media-upload');
        wp_enqueue_script('thickbox');
        wp_enqueue_script('upload_media_widget', get_template_directory_uri() . '/framework/assets/js/upload-media.js', array('jquery'));

        wp_enqueue_style('thickbox');
    }
	

	function widget($args, $instance) {


		ob_start();
		extract($args);
		
		$name = $instance['name'] ? $instance['name'] : '';	
		$description = $instance['description'] ? $instance['description'] : '';	
		$image = $instance['image'];
		?>
		
		<?php echo do_shortcode($before_widget); ?>
		
		 <div class="about-me text-center">
                    <img src="<?php echo esc_url($image); ?>" class="img-circle" width="80" alt="" />
                    <h4><?php echo esc_attr($name); ?></h4>
                    <p><?php echo esc_attr($description); ?></p>
					<div class="h-10"></div>
      
		<?php
		$output = '';
		if ( !empty( $instance['enable_sites'] ) ) {

			foreach ( $instance['enable_sites'] as $site ) {

				$link = isset( $instance[strtolower( $site )] )?$instance[strtolower( $site )]:'#';

					$output .= '<li><a href="'.$link.'" rel="nofollow" target="_blank" title="'.$name.' '.$site.'"><i class="ion-social-'.$site.'"></i></a></li>';

	

			}								

		}
		
		if ( !empty( $output ) ) {

		
				echo ' <ul class="social-ul clearfix">';

				echo do_shortcode($output);

				echo ' </ul>';


		}
		?>
				  
  
                   
         </div>
				
			
		<div class="clear"></div>
        
      
		<?php echo do_shortcode($after_widget); 
					
	}

	
	
	 public function update( $new_instance, $old_instance ) {

        
        $updated_instance = $new_instance;
		
		if ( !empty( $instance['enable_sites'] ) ) {
			foreach ( $instance['enable_sites'] as $site ) {
				$instance[strtolower( $site )] = isset( $new_instance[strtolower( $site )] )?strip_tags( $new_instance[strtolower( $site )] ):'';
			}
		}
		
		
        return $updated_instance;
    }
	



function form( $instance ) {
	
	$name = isset($instance['name']) ? esc_attr($instance['name']) : '';	
	$image = isset($instance['image']) ? esc_attr($instance['image']) : '';
	$description = isset($instance['description']) ? esc_attr($instance['description']) : '';
	
		$enable_sites = isset( $instance['enable_sites'] ) ? $instance['enable_sites'] : array();

		foreach ( $this->sites as $site ) {
			$$site = isset( $instance[strtolower( $site )] ) ? esc_attr( $instance[strtolower( $site )] ) : '';
		}

        ?>
		
        <p>
            <label for="<?php echo esc_attr($this->get_field_name( 'name' )); ?>"><?php esc_html_e( 'Name:','santos' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id( 'name' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'name' )); ?>" type="text" value="<?php echo esc_attr( $name ); ?>" />
        </p>

        <p>
            <label for="<?php echo esc_attr($this->get_field_name( 'image' )); ?>"><?php esc_html_e( 'Image:','santos' ); ?></label>
            <input name="<?php echo esc_attr($this->get_field_name( 'image' )); ?>" id="<?php echo esc_attr($this->get_field_id( 'image' )); ?>" class="widefat" type="text" size="36"  value="<?php echo esc_url( $image ); ?>" />
            <input class="upload_image_button button button-primary" type="button" value="Upload Image" />
        </p>
		
		
		
		<p>
            <label for="<?php echo esc_attr($this->get_field_name( 'description' )); ?>"><?php esc_html_e( 'Description:','santos' ); ?></label>
            <textarea class="widefat" rows="4" cols="16" id="<?php echo esc_attr($this->get_field_id('description')); ?>" name="<?php echo esc_attr($this->get_field_name('description')); ?>"><?php echo esc_attr($description); ?></textarea>
        </p>
		
			<p class="santos-choose-social-networks">

			<label for="<?php echo esc_attr($this->get_field_id( 'enable_sites' )); ?>"><?php esc_html_e( 'Choose Sites:', 'santos'); ?></label>

			<select name="<?php echo esc_attr($this->get_field_name( 'enable_sites' )); ?>[]" id="<?php echo esc_attr($this->get_field_id( 'enable_sites' )); ?>" style="width:300px" class="social_icon_select_sites santos-chosen widefat" multiple="multiple">

				<?php foreach ( $this->sites as $site ):?>

				<option value="<?php echo strtolower( $site );?>"<?php echo in_array( strtolower( $site ), $enable_sites )? 'selected="selected"':'';?>><?php echo esc_attr($site);?></option>

				<?php endforeach;?>

			</select>

		</p>



		<p>

			<em><?php "Note: Please input FULL URL <br/>(e.g. <code>http://www.facebook.com/username</code>)";?></em>

		</p>

		<div class="social_icon_wrap">

		<?php foreach ( $this->sites as $site ):?>

		<p class="social_icon_<?php echo strtolower( $site );?>" <?php if ( !in_array( strtolower( $site ), $enable_sites ) ):?>style="display:none"<?php endif;?>>

			<label for="<?php echo esc_attr($this->get_field_id( strtolower( $site ) )); ?>"><?php echo esc_attr($site).' '.'URL:'?></label>

			<input class="widefat" id="<?php echo esc_attr($this->get_field_id( strtolower( $site ) )); ?>" name="<?php echo esc_attr($this->get_field_name( strtolower( $site ) )); ?>" type="text" value="<?php echo strtolower($$site); ?>" />

		</p>

		<?php endforeach;?>

		</div>
		
		
		<script type="text/javascript">

			jQuery(document).ready(function($) {							

				santos_init_widgets_chosen();

			});

		</script>	
		
    <?php
	}
}


?>