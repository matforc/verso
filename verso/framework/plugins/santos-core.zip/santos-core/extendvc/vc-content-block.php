<?php


add_action( 'vc_load_default_templates_action','santos_content_block_for_vc' ); 

function santos_content_block_for_vc() {
	
	
$cat_display_names = array(
	'about' => __('About', 'santos-core'),
	'blog' => __('Blog', 'santos-core'),
	'contact' => __('Contact Section', 'santos-core'),
	'general' => __('General', 'santos-core'),
	'icons' => __('Icons', 'santos-core'),
	'hero' => __('Hero Section', 'santos-core'),
	'portfolio' => __('Project', 'santos-core'),
	'pricing' => __('Pricing', 'santos-core'),
	'services' => __('Services', 'santos-core'),
	'team' => __('Team', 'santos-core'),
	'testimonials' => __('Testimonials', 'santos-core')
);




$data = array();
$data['name'] = __( 'Hero Simple', 'js_composer' );
$data['cat_display_name'] = $cat_display_names['hero']  .', '. $cat_display_names['general'];
$data['custom_class'] = 'general hero';
$data['image_path'] = preg_replace( '/\s/', '%20', plugins_url( 'img/templates/simple-hero.jpg', plugin_dir_path( __FILE__ ) ) ); 
$data['content'] = <<<CONTENT
[vc_row row_container="container-fullwidth" sep_img_width="100"][vc_column][santos_hero image="140"][vc_row_inner][vc_column_inner width="1/2"][vc_custom_heading text="Build amazing." font_container="tag:h1|font_size:70px|text_align:left|color:%23333333" use_theme_fonts="yes"][vc_empty_space][vc_custom_heading text="We create amazing fully responsive templates to help our clients build their brands and grow their businesses " font_container="tag:p|font_size:19px|text_align:left|color:%23777777|line_height:32px" use_theme_fonts="yes"][vc_empty_space][santos_button title="SEE MORE" text_color="#ffffff" align="left"][/vc_column_inner][vc_column_inner width="1/2"][/vc_column_inner][/vc_row_inner][/santos_hero][/vc_column][/vc_row]
CONTENT;

vc_add_default_templates( $data );



$data = array();
$data['name'] = __( 'About - video lightbox', 'js_composer' );
$data['cat_display_name'] = $cat_display_names['about'];
$data['custom_class'] = 'general about';
$data['image_path'] = preg_replace( '/\s/', '%20', plugins_url( 'img/templates/video-lightbox.jpg', plugin_dir_path( __FILE__ ) ) ); 
$data['content'] = <<<CONTENT
[vc_row santos_section_padding="padding-150" animation="fade-up" sep_img_width="100" gap="30" santos_section="true"][vc_column width="1/2"][santos_lightbox_video style="img" color="" url="https://www.youtube.com/embed/6v2L2UGZJAM?version=3" image="1143"][/vc_column][vc_column width="1/2" css=".vc_custom_1504206337201{padding-top: 5% !important;padding-right: 8% !important;padding-bottom: 5% !important;padding-left: 8% !important;}"][vc_column_text]
<h2>Perfect components for modern startups</h2>
[/vc_column_text][vc_empty_space][vc_column_text]Hanc ergo intuens debet institutum illud quasi signum absolvere. Quoniam, si dis placet, ab Epicuro loqui discimus. Universa enim illorum ratione cum tota vestra confligendum puto.[/vc_column_text][/vc_column][/vc_row]
CONTENT;

vc_add_default_templates( $data );


$data = array();
$data['name'] = __( 'Service - Icon with Text', 'js_composer' );
$data['cat_display_name'] = $cat_display_names['icons']  .', '. $cat_display_names['services'];
$data['custom_class'] = 'icons services';
$data['image_path'] = preg_replace( '/\s/', '%20', plugins_url( 'img/templates/icon-with-text-1.jpg', plugin_dir_path( __FILE__ ) ) ); 
$data['content'] = <<<CONTENT
[vc_row santos_section_padding="padding-100" sep_img_width="100" full_width="stretch_row" css_animation="none" css=".vc_custom_1499416051623{background-color: #f3f3f3 !important;}"][vc_column width="1/2"][santos_icon_box icon_ion="ion-ios-pulse" icon_position="left" title="Speed Optimzed" hover_bg_color="#ffffff" animation="fade-up" icon_type="etline" enable_hover="true"]Hanc ergo intuens debet institutum illud quasi signum absolvere. Quoniam, si dis placet, ab Epicuro loqui discimus. [/santos_icon_box][vc_empty_space height="30px"][santos_icon_box icon_ion="ion-ios-settings" icon_position="left" title="Custom Menus" hover_bg_color="#ffffff" animation="fade-up" icon_type="etline" enable_hover="true"]Hanc ergo intuens debet institutum illud quasi signum absolvere. Quoniam, si dis placet, ab Epicuro loqui discimus. [/santos_icon_box][/vc_column][vc_column width="1/2"][santos_icon_box icon_ion="ion-ios-gear-outline" icon_position="left" title="Unlimited Options" hover_bg_color="#ffffff" animation="fade-up" icon_type="etline" enable_hover="true"]Hanc ergo intuens debet institutum illud quasi signum absolvere. Quoniam, si dis placet, ab Epicuro loqui discimus. [/santos_icon_box][vc_empty_space height="30px"][santos_icon_box icon_ion="ion-ios-heart-outline" icon_position="left" title="Lovely support" hover_bg_color="#ffffff" animation="fade-up" icon_type="etline" enable_hover="true"]Hanc ergo intuens debet institutum illud quasi signum absolvere. Quoniam, si dis placet, ab Epicuro loqui discimus. [/santos_icon_box][/vc_column][/vc_row]
CONTENT;

vc_add_default_templates( $data );



$data = array();
$data['name'] = __( 'Portfolio Section', 'js_composer' );
$data['cat_display_name'] = $cat_display_names['portfolio'];
$data['custom_class'] = 'portfolio';
$data['image_path'] = preg_replace( '/\s/', '%20', plugins_url( 'img/templates/portfolio-section.jpg', plugin_dir_path( __FILE__ ) ) ); 
$data['content'] = <<<CONTENT
[vc_row row_container="container-fullwidth" sep_img_width="100" full_width="stretch_row_content_no_spaces" css=".vc_custom_1499431706113{padding-top: 100px !important;}"][vc_column][vc_column_text]
<h2 style="text-align: center;">Our Work</h2>
[/vc_column_text][vc_empty_space][vc_column_text css=".vc_custom_1503534655518{padding-right: 15px !important;padding-left: 15px !important;}"]
<p style="text-align: center;">Hanc ergo intuens debet institutum illud quasi signum absolvere. Quoniam
si dis placet, ab Epicuro loqui discimus.

[/vc_column_text][vc_empty_space height="60px"][santos_portfolio enable_filter="true" style="grid" order="ASC" hover_color_style="custom_color" hover_custom_color="rgba(0,0,0,0.8)" items_per_page="6"][/vc_column][/vc_row]
CONTENT;

vc_add_default_templates( $data );








$data = array();
$data['name'] = __( 'Team Section', 'js_composer' );
$data['cat_display_name'] = $cat_display_names['team'];
$data['custom_class'] = 'team';
$data['image_path'] = preg_replace( '/\s/', '%20', plugins_url( 'img/templates/team-section.jpg', plugin_dir_path( __FILE__ ) ) ); 
$data['content'] = <<<CONTENT
[vc_section santos_section_padding="padding-100" sep_img_width="100"][vc_row animation="fade-up" sep_img_width="100" full_width="stretch_row_content_no_spaces"][vc_column][vc_column_text]
<h2 style="text-align: center;">Meet the Talents</h2>
[/vc_column_text][vc_empty_space][vc_column_text]
<p style="text-align: center;">Hanc ergo intuens debet institutum illud quasi signum absolvere. Quoniam
si dis placet, ab Epicuro loqui discimus</p>
[/vc_column_text][vc_empty_space height="50px"][/vc_column][/vc_row][vc_row animation="fade-up" sep_img_width="100"][vc_column width="1/3"][santos_team team_social_icon_1="whatsapp-outline" team_social_icon_2="twitter" team_social_icon_3="instagram-outline" image="165" name="Harold Reynolds" position="Web designer" team_social_icon_1_link="#" team_social_icon_2_link="#" team_social_icon_3_link="#"][/vc_column][vc_column width="1/3"][santos_team team_social_icon_1="whatsapp-outline" team_social_icon_2="twitter" team_social_icon_3="instagram-outline" icon_color="#ffffff" image="167" name="Hannah Carter" position="Founder" team_social_icon_1_link="#" team_social_icon_2_link="#" team_social_icon_3_link="#"][/vc_column][vc_column width="1/3"][santos_team team_social_icon_1="whatsapp-outline" team_social_icon_2="twitter" team_social_icon_3="instagram-outline" icon_color="#ffffff" image="166" name="Zachary Knight" position="Developer" team_social_icon_1_link="#" team_social_icon_2_link="#" team_social_icon_3_link="#"][/vc_column][/vc_row][/vc_section]
CONTENT;

vc_add_default_templates( $data );







$data = array();
$data['name'] = __( 'Testimonial Carousel Style', 'js_composer' );
$data['cat_display_name'] = $cat_display_names['testimonials'];
$data['custom_class'] = 'general testimonials';
$data['image_path'] = preg_replace( '/\s/', '%20', plugins_url( 'img/templates/testimonial-section.jpg', plugin_dir_path( __FILE__ ) ) ); 
$data['content'] = <<<CONTENT
[vc_row parallax="content-moving" parallax_speed_bg="2" sep_img_width="100" santos_parallax="simple" santos_parallax_image="145" full_width="stretch_row" css=".vc_custom_1500154783556{padding-top: 100px !important;padding-bottom: 100px !important;background-image: url(http://uxcode.net/themes/santos/wp-content/uploads/2017/04/video-bg.jpg?id=145) !important;}" overlay_color="rgba(0,0,0,0.7)"][vc_column width="2/3"][santos_testimonial_carousel][santos_testimonial_carousel_item quote="Ad eos igitur converte te, quaeso. Duo Reges: constructio interrete. Tertium autem omnibus aut maximis" name="Ahmed eissa" position="Webdesigner"][santos_testimonial_carousel_item quote="voluptatis repudiandum. Tertium autem omnibus aut maximis rebus iis, quae secundum " name="Amber Reed" position="Webdesigner"][santos_testimonial_carousel_item quote="philosophiam et omnes ingenuas disciplinas habemus; Sed ne, dum huic obsequor vobis molestus" name="Jack Schneider" position="Webdesigner"][/santos_testimonial_carousel][/vc_column][vc_column width="1/3"][/vc_column][/vc_row]
CONTENT;

vc_add_default_templates( $data );




$data = array();
$data['name'] = __( 'Blog Section', 'js_composer' );
$data['cat_display_name'] = $cat_display_names['blog'];
$data['custom_class'] = 'blog';
$data['image_path'] = preg_replace( '/\s/', '%20', plugins_url( 'img/templates/blog-section.jpg', plugin_dir_path( __FILE__ ) ) ); 
$data['content'] = <<<CONTENT
[vc_section sep_img_width="100" css=".vc_custom_1503663816038{padding-top: 100px !important;padding-bottom: 100px !important;background-color: #f3f3f3 !important;}"][vc_row][vc_column][vc_column_text]
<h2 style="text-align: center;">We Make Beautiful Things</h2>
[/vc_column_text][vc_empty_space][vc_column_text]
<p style="text-align: center;">Hanc ergo intuens debet institutum illud quasi signum absolvere. Quoniam
si dis placet, ab Epicuro loqui discimus

[/vc_column_text][vc_empty_space height="50px"][/vc_column][/vc_row][vc_row sep_img_width="100" row_stick_col="false"][vc_column][santos_recent_posts items_per_page="3" post_excerpt_length="18" ignore_post_format="true"][vc_empty_space][santos_button title="GO TO BLOG" text_color="#ffffff" align="center"][/vc_column][/vc_row][/vc_section]
CONTENT;

vc_add_default_templates( $data );


$data = array();
$data['name'] = __( 'Portfolio Container', 'js_composer' );
$data['cat_display_name'] = $cat_display_names['portfolio'];
$data['custom_class'] = 'portfolio';
$data['image_path'] = preg_replace( '/\s/', '%20', plugins_url( 'img/templates/portfolio-container.jpg', plugin_dir_path( __FILE__ ) ) ); 
$data['content'] = <<<CONTENT
[vc_row parallax="content-moving" sep_img_width="100" full_width="stretch_row" css=".vc_custom_1501243442187{padding-top: 100px !important;padding-bottom: 200px !important;background-image: url(http://uxcode.net/themes/santos/wp-content/uploads/2017/04/row_bg_port.jpg?id=295) !important;}" overlay_color="rgba(0,0,0,0.81)"][vc_column][vc_custom_heading text="We Are Creative" font_container="tag:h2|font_size:50|text_align:center|color:%23ffffff|line_height:60px" google_fonts="font_family:Lato%3A100%2C100italic%2C300%2C300italic%2Cregular%2Citalic%2C700%2C700italic%2C900%2C900italic|font_style:700%20bold%20regular%3A700%3Anormal"][/vc_column][/vc_row][vc_row sep_img_width="100" css=".vc_custom_1502233820103{margin-top: -100px !important;}" row_stick_col="true"][vc_column][santos_portfolio style="grid" column="6" order="ASC" items_per_page="6"][vc_empty_space height="100px"][/vc_column][/vc_row]
CONTENT;

vc_add_default_templates( $data );




$data = array();
$data['name'] = __( 'Hero with video lightbox Style', 'js_composer' );
$data['cat_display_name'] = $cat_display_names['hero'];
$data['custom_class'] = 'hero';
$data['image_path'] = preg_replace( '/\s/', '%20', plugins_url( 'img/templates/hero-style-2.jpg', plugin_dir_path( __FILE__ ) ) ); 
$data['content'] = <<<CONTENT
[vc_row row_container="container-fullwidth" sep_img_width="100"][vc_column][santos_hero hero_height="90" image="279" overlay_color="rgba(0,0,0,0.4)"][vc_row_inner][vc_column_inner][vc_custom_heading text="Your needs are important to us" font_container="tag:h1|font_size:50|text_align:center|color:%23ffffff" google_fonts="font_family:Lato%3A100%2C100italic%2C300%2C300italic%2Cregular%2Citalic%2C700%2C700italic%2C900%2C900italic|font_style:900%20bold%20regular%3A900%3Anormal"][vc_empty_space][vc_column_text width="700"]
<p style="text-align: center;"><span style="color: #ffffff;">Create super fast responsive websites with amazing user experience. Sanots got unlimited
options so you can create anything without coding..</span>

[/vc_column_text][santos_cta_btn title="" btn_title="SEE MORE" btn_position="left" enable_video="true" url="" video_url="https://www.youtube.com/embed/6v2L2UGZJAM?version=3" video_title="Watch Full video"][/vc_column_inner][/vc_row_inner][/santos_hero][/vc_column][/vc_row]
CONTENT;

vc_add_default_templates( $data );





$data = array();
$data['name'] = __( 'Service - Icon with text Different Style', 'js_composer' );
$data['cat_display_name'] = $cat_display_names['icons']  .', '. $cat_display_names['services'];
$data['custom_class'] = 'icons services';
$data['image_path'] = preg_replace( '/\s/', '%20', plugins_url( 'img/templates/icon-with-text-2.jpg', plugin_dir_path( __FILE__ ) ) ); 
$data['content'] = <<<CONTENT
[vc_row santos_section_padding="padding-100" sep_img_width="100" gap="35" full_width="stretch_row" css=".vc_custom_1499432592473{background-color: #425bb5 !important;}"][vc_column width="1/3"][santos_icon_box icon_ion="ion-ios-monitor-outline" icon_color="#ffffff" icon_size="50" icon_position="top" icon_align="left" title="Responsive Design" title_color="#ffffff" text_color="#ffffff" hover_bg_color="#ffffff" animation="fade-up"]Hanc ergo intuens debet institutum illud quasi signum absolvere. Quoniam, si dis placet, ab Epicuro loqui discimus. [/santos_icon_box][/vc_column][vc_column width="1/3"][santos_icon_box icon_ion="ion-ios-infinite-outline" icon_color="#ffffff" icon_size="50" icon_position="top" icon_align="left" title="Unlimited Options" title_color="#ffffff" text_color="#ffffff" hover_bg_color="#ffffff" animation="fade-up"]Hanc ergo intuens debet institutum illud quasi signum absolvere. Quoniam, si dis placet, ab Epicuro loqui discimus. [/santos_icon_box][/vc_column][vc_column width="1/3"][santos_icon_box icon_ion="ion-ios-albums-outline" icon_color="#ffffff" icon_size="50" icon_position="top" icon_align="left" title="Interactive Elements" title_color="#ffffff" text_color="#ffffff" hover_bg_color="#ffffff" animation="fade-up"]Hanc ergo intuens debet institutum illud quasi signum absolvere. Quoniam, si dis placet, ab Epicuro loqui discimus. [/santos_icon_box][/vc_column][/vc_row]
CONTENT;

vc_add_default_templates( $data );



$data = array();
$data['name'] = __( 'About - Text with Signature', 'js_composer' );
$data['cat_display_name'] = $cat_display_names['icons']  .', '. $cat_display_names['about'];
$data['custom_class'] = 'about signature';
$data['image_path'] = preg_replace( '/\s/', '%20', plugins_url( 'img/templates/about-sign.jpg', plugin_dir_path( __FILE__ ) ) ); 
$data['content'] = <<<CONTENT
[vc_row santos_section_padding="padding-150" sep_img_width="100"][vc_column][vc_column_text]
<p style="text-align: center;">Cupit enim dícere nihil posse ad beatam vitam deesse sapienti. Nunc haec primum fortasse audientis servire
debemus. Cupit enim dícere nihil posse ad beatam vitam deesse sapienti.

[/vc_column_text][santos_signature align="center" image="286"][/vc_column][/vc_row]
CONTENT;

vc_add_default_templates( $data );



$data = array();
$data['name'] = __( 'Service Section', 'js_composer' );
$data['cat_display_name'] = $cat_display_names['services']  .', '. $cat_display_names['general'];
$data['custom_class'] = 'general services';
$data['image_path'] = preg_replace( '/\s/', '%20', plugins_url( 'img/templates/service-section.jpg', plugin_dir_path( __FILE__ ) ) ); 
$data['content'] = <<<CONTENT
[vc_row row_container="container-fullwidth" row_equal_height="yes" sep_img_width="100" full_width="stretch_row_content_no_spaces" equal_height="yes"][vc_column width="5/12" css=".vc_custom_1504216096831{padding-top: 0px !important;background-image: url(http://uxcode.net/themes/santos/wp-content/uploads/2017/04/col_bg_3.jpg?id=288) !important;}"][/vc_column][vc_column width="7/12" santos_column_padding="padding-100" padding_behaviour="mobile_remove_padding" css=".vc_custom_1504216070065{background-color: #232323 !important;}"][vc_column_text]
<h3><span style="color: #ffffff;">What makes Santos different?</span></h3>
[/vc_column_text][vc_empty_space height="15px"][vc_column_text]<span style="color: #a9a9a9;">Quare attende, quaeso. Stuprata per vim Lucretia a regis filio testata civis se ipsa interemit. Nec lapathi suavitatem acupenseri Galloni Laelius anteponebat, sed suavitatem ipsam neglegebat; De vacuitate doloris eadem sententia erit.</span>[/vc_column_text][vc_empty_space height="50px"][vc_row_inner][vc_column_inner width="1/2"][santos_milestone number_size="50" align="left" number="500" number_color="#425bb5" title="line of code" title_color="#ffffff"]Cupit enim dícere nihil posse ad beatam vitam deesse sapienti[/santos_milestone][/vc_column_inner][vc_column_inner width="1/2"][santos_milestone number_size="50" align="left" number="873" number_color="#425bb5" title="smile" title_color="#ffffff"]Cupit enim dícere nihil posse ad beatam vitam deesse sapienti[/santos_milestone][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row]
CONTENT;

vc_add_default_templates( $data );





$data = array();
$data['name'] = __( 'Team Carousel Style', 'js_composer' );
$data['cat_display_name'] = $cat_display_names['team'];
$data['custom_class'] = 'team';
$data['image_path'] = preg_replace( '/\s/', '%20', plugins_url( 'img/templates/team-section-2.jpg', plugin_dir_path( __FILE__ ) ) ); 
$data['content'] = <<<CONTENT
[vc_row][vc_column][santos_team_carousel][santos_team_carousel_item team_social_icon_1="whatsapp-outline" team_social_icon_2="twitter" team_social_icon_3="instagram-outline" icon_color="#111111" image="292" name="Harold Reynolds" position="Web designer" team_social_icon_1_link="#" team_social_icon_2_link="#" team_social_icon_3_link="#"][santos_team_carousel_item team_social_icon_1="whatsapp-outline" team_social_icon_2="twitter" team_social_icon_3="instagram-outline" icon_color="#111111" image="293" name="Stephanie Porter" position="Web designer" team_social_icon_1_link="#" team_social_icon_2_link="#" team_social_icon_3_link="#"][/santos_team_carousel][/vc_column][/vc_row]
CONTENT;

vc_add_default_templates( $data );




$data = array();
$data['name'] = __( 'Testimonial Section', 'js_composer' );
$data['cat_display_name'] = $cat_display_names['testimonials'];
$data['custom_class'] = 'testimonials';
$data['image_path'] = preg_replace( '/\s/', '%20', plugins_url( 'img/templates/testimonial-section-2.jpg', plugin_dir_path( __FILE__ ) ) ); 
$data['content'] = <<<CONTENT
[vc_row row_container="container-fullwidth" sep_img_width="100" row_stick_col="true" full_width="stretch_row_content_no_spaces"][vc_column width="1/3"][santos_testimonial_box bg_color="#f3f3f3" position_color="#999999" quote="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Atque hoc loco similitudines eas, quibus i" name="Ryan Knight" position="Founder" image="47"][/vc_column][vc_column width="1/3"][santos_testimonial_box bg_color="#eeeeee" position_color="#999999" quote="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Atque hoc loco similitudines eas, quibus i" name="Billy Carroll" position="Founder" image="299"][/vc_column][vc_column width="1/3"][santos_testimonial_box bg_color="#e8e7e7" position_color="#999999" quote="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Atque hoc loco similitudines eas, quibus i" name="Gloria Jacobs" position="Founder" image="300"][/vc_column][/vc_row]
CONTENT;

vc_add_default_templates( $data );




$data = array();
$data['name'] = __( 'Hero Slider', 'js_composer' );
$data['cat_display_name'] = $cat_display_names['hero'];
$data['custom_class'] = 'general hero';
$data['image_path'] = preg_replace( '/\s/', '%20', plugins_url( 'img/templates/hero-slider.jpg', plugin_dir_path( __FILE__ ) ) ); 
$data['content'] = <<<CONTENT
[vc_row row_container="container-fullwidth" sep_img_width="100" full_width="stretch_row_content_no_spaces"][vc_column][santos_hero_slider][santos_hero_slide title_color="#ffffff" description_color="#ffffff" btn_title="SEE MORE" subtitle_color="" bg_color="" subtitle="" title="Your needs are important to us" description="Stand out with powerful and super flexible WordPress Theme that let you build amazing content without writing code." image="183" enable_button="true"][santos_hero_slide title_color="#ffffff" description_color="#ffffff" subtitle_color="" bg_color="" subtitle="" title="Your need are important to us" image="184" enable_video="true" video_title="Watch fullscreen video"][/santos_hero_slider][/vc_column][/vc_row]
CONTENT;

vc_add_default_templates( $data );



$data = array();
$data['name'] = __( 'Icon Tabs', 'js_composer' );
$data['cat_display_name'] = $cat_display_names['icons'];
$data['custom_class'] = 'icons';
$data['image_path'] = preg_replace( '/\s/', '%20', plugins_url( 'img/templates/icon-tabs.jpg', plugin_dir_path( __FILE__ ) ) ); 
$data['content'] = <<<CONTENT
[vc_row santos_section_padding="padding-150" animation="fade-up" sep_img_width="100" full_height="yes"][vc_column][santos_icon_tabs][santos_icon_tab icon_ion="ion-ios-monitor-outline" tab_id="1492605378695-279060fd-7102b8b6-23c0" icon_title="Design" tab_title="Perfect for Designers &amp; Developers"]Cupit enim dícere nihil posse ad beatam vitam deesse sapienti. Nunc haec primum fortasse audientis servire Cupit enim dícere nihil posse ad beatam vitam deesse sapienti. Nunc haec primum fortasse audientis servire
debemus. Cupit enim dícere nihil posse ad beatam vitam deesse sapienti. [/santos_icon_tab][santos_icon_tab tab_id="1492605435967-7f794e01-707fb8b6-23c0" icon_title="Web Design" tab_title="posse ad beatam vitam deesse"]Cupit enim dícere nihil posse ad beatam vitam deesse sapienti. Nunc haec primum fortasse audientis servire Cupit enim dícere nihil posse ad beatam vitam deesse sapienti. Nunc haec primum fortasse audientis servire
debemus. Cupit enim dícere nihil posse ad beatam vitam deesse sapienti. [/santos_icon_tab][santos_icon_tab icon_ion="ion-ios-albums-outline" tab_id="1492605435217-8f1f76ce-99edb8b6-23c0" icon_title="Development" tab_title="posse ad beatam vitam deesse"]Cupit enim dícere nihil posse ad beatam vitam deesse sapienti. Nunc haec primum fortasse audientis servire Cupit enim dícere nihil posse ad beatam vitam deesse sapienti. Nunc haec primum fortasse audientis servire
debemus. Cupit enim dícere nihil posse ad beatam vitam deesse sapienti. [/santos_icon_tab][santos_icon_tab icon_ion="ion-ios-timer-outline" tab_id="1492605433849-65529afd-ea62b8b6-23c0" icon_title="Mobile Apps" tab_title="Makes Elegant different different"]Cupit enim dícere nihil posse ad beatam vitam deesse sapienti. Nunc haec primum fortasse audientis servire Cupit enim dícere nihil posse ad beatam vitam deesse sapienti. Nunc haec primum fortasse audientis servire
debemus. Cupit enim dícere nihil posse ad beatam vitam deesse sapienti. [/santos_icon_tab][/santos_icon_tabs][/vc_column][/vc_row]
CONTENT;

vc_add_default_templates( $data );


$data = array();
$data['name'] = __( 'Service Section Styel 2', 'js_composer' );
$data['cat_display_name'] = $cat_display_names['services']  .', '. $cat_display_names['general'];
$data['custom_class'] = 'general services';
$data['image_path'] = preg_replace( '/\s/', '%20', plugins_url( 'img/templates/service-section-2.jpg', plugin_dir_path( __FILE__ ) ) ); 
$data['content'] = <<<CONTENT
[vc_row row_container="container-fullwidth" row_equal_height="yes" animation="fade-up" sep_img_width="100" full_width="stretch_row_content_no_spaces" equal_height="yes"][vc_column width="1/2" css=".vc_custom_1504218947268{padding-top: 0px !important;background-image: url(http://uxcode.net/themes/santos/wp-content/uploads/2017/04/col_bg.jpg?id=188) !important;}"][/vc_column][vc_column width="1/2" santos_column_padding="padding-100" padding_behaviour="mobile_remove_padding" css=".vc_custom_1504218962365{background-color: #232323 !important;}"][vc_column_text]
<h2><span style="color: #ffffff;">What makes Santos</span>
<span style="color: #ffffff;">different</span></h2>
[/vc_column_text][vc_empty_space][vc_column_text]<span style="color: #a9a9a9;">Quare attende, quaeso. Stuprata per vim Lucretia a regis filio testata civis se ipsa interemit. Nec lapathi suavitatem acupenseri Galloni Laelius anteponebat, sed suavitatem ipsam neglegebat; De vacuitate doloris eadem sententia erit.</span>[/vc_column_text][vc_empty_space height="50px"][santos_lightbox_video url="https://www.youtube.com/embed/6v2L2UGZJAM?version=3" title="Watch fullscreen video"][/vc_column][/vc_row]
CONTENT;

vc_add_default_templates( $data );




$data = array();
$data['name'] = __( 'portfolio Carousel Style', 'js_composer' );
$data['cat_display_name'] = $cat_display_names['portfolio'];
$data['custom_class'] = 'portfolio';
$data['image_path'] = preg_replace( '/\s/', '%20', plugins_url( 'img/templates/portfolio-carousel.jpg', plugin_dir_path( __FILE__ ) ) ); 
$data['content'] = <<<CONTENT
[vc_row santos_section_padding="padding-100" animation="fade-up" sep_img_width="100" full_width="stretch_row" css=".vc_custom_1499534913827{background-color: #f3f3f3 !important;}"][vc_column][vc_column_text]
<h2 style="text-align: center;">Perfect components</h2>
[/vc_column_text][vc_empty_space][vc_column_text]
<p style="text-align: center;">Hanc ergo intuens debet institutum illud quasi signum absolvere. Quoniam
si dis placet, ab Epicuro loqui discimus.

[/vc_column_text][vc_empty_space height="50px"][santos_portfolio_carousel order="ASC" items_per_page="4"][/vc_column][/vc_row]
CONTENT;

vc_add_default_templates( $data );



$data = array();
$data['name'] = __( 'Testimonial Carousel Center', 'js_composer' );
$data['cat_display_name'] = $cat_display_names['testimonials'];
$data['custom_class'] = 'general testimonials';
$data['image_path'] = preg_replace( '/\s/', '%20', plugins_url( 'img/templates/testimonial-section-3.jpg', plugin_dir_path( __FILE__ ) ) ); 
$data['content'] = <<<CONTENT
[vc_row parallax="content-moving" parallax_image="202" full_width="stretch_row" animation_delay="" css=".vc_custom_1492622229739{padding-top: 100px !important;padding-bottom: 100px !important;}" overlay_color="rgba(0,0,0,0.6)"][vc_column width="1/6"][/vc_column][vc_column width="4/6"][santos_testimonial_carousel align="center"][santos_testimonial_carousel_item quote="Ad eos igitur converte te, quaeso. Duo Reges: constructio interrete. Tertium autem omnibus aut maximis" name="Ahmed eissa" position="Webdesigner"][santos_testimonial_carousel_item quote="Ad eos igitur converte te, quaeso. Duo Reges: constructio interrete. Tertium autem omnibus aut maximis" name="Ahmed eissa" position="Webdesigner"][/santos_testimonial_carousel][/vc_column][vc_column width="1/6"][/vc_column][/vc_row]
CONTENT;

vc_add_default_templates( $data );



$data = array();
$data['name'] = __( 'Price Box Section', 'js_composer' );
$data['cat_display_name'] = $cat_display_names['pricing'];
$data['custom_class'] = 'pricing';
$data['image_path'] = preg_replace( '/\s/', '%20', plugins_url( 'img/templates/price-box.jpg', plugin_dir_path( __FILE__ ) ) ); 
$data['content'] = <<<CONTENT
[vc_row full_width="stretch_row" css=".vc_custom_1492612222481{padding-top: 100px !important;padding-bottom: 100px !important;background-color: #f3f3f3 !important;}"][vc_column][vc_column_text]
<h2 style="text-align: center;">Build beautiful sites is easy</h2>
[/vc_column_text][vc_empty_space][vc_column_text]
<p style="text-align: center;">Hanc ergo intuens debet institutum illud quasi signum absolvere. Quoniam
si dis placet, ab Epicuro loqui discimus.

[/vc_column_text][vc_empty_space height="50px"][vc_row_inner][vc_column_inner width="1/3"][santos_price_box bg_color="#ffffff" price="50" symbol="$" title="Basic edition" btn_bg_color="#333333" animation="fade-up"]A no-commitment plan for hobbyists and tinkerers looking to experiment with design.[/santos_price_box][/vc_column_inner][vc_column_inner width="1/3"][santos_price_box featured="true" bg_color="#ffffff" price="90" symbol="$" title="Premium edition" animation="fade-up"]A no-commitment plan for hobbyists and tinkerers looking to experiment with design.[/santos_price_box][/vc_column_inner][vc_column_inner width="1/3"][santos_price_box bg_color="#ffffff" price="100" symbol="$" title="Platinum edition" btn_bg_color="#333333" animation="fade-up"]A no-commitment plan for hobbyists and tinkerers looking to experiment with design.[/santos_price_box][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row]
CONTENT;

vc_add_default_templates( $data );




$data = array();
$data['name'] = __( 'Hero Simple', 'js_composer' );
$data['cat_display_name'] = $cat_display_names['hero'];
$data['custom_class'] = 'general hero';
$data['image_path'] = preg_replace( '/\s/', '%20', plugins_url( 'img/templates/hero-style-3.jpg', plugin_dir_path( __FILE__ ) ) ); 
$data['content'] = <<<CONTENT
[vc_row row_container="container-fullwidth" sep_img_width="100"][vc_column][santos_hero scroll_row_id="#about" image="234" enable_scroll_icon="true"][vc_row_inner][vc_column_inner width="1/4"][/vc_column_inner][vc_column_inner width="1/2"][vc_custom_heading text="Build amazing." font_container="tag:h1|font_size:180|text_align:center|color:%23ffffff|line_height:100px" google_fonts="font_family:Great%20Vibes%3Aregular|font_style:400%20regular%3A400%3Anormal"][/vc_column_inner][vc_column_inner width="1/4"][/vc_column_inner][/vc_row_inner][/santos_hero][/vc_column][/vc_row]
CONTENT;

vc_add_default_templates( $data );



$data = array();
$data['name'] = __( 'Service Section Styel 3', 'js_composer' );
$data['cat_display_name'] = $cat_display_names['services']  .', '. $cat_display_names['general'];
$data['custom_class'] = 'general services';
$data['image_path'] = preg_replace( '/\s/', '%20', plugins_url( 'img/templates/service-section-3.jpg', plugin_dir_path( __FILE__ ) ) ); 
$data['content'] = <<<CONTENT
[vc_row parallax="content-moving" sep_img_width="100" full_width="stretch_row" full_height="yes" css=".vc_custom_1501952212553{padding-top: 100px !important;padding-right: 15px !important;padding-bottom: 100px !important;padding-left: 15px !important;background-image: url(http://uxcode.net/themes/santos/wp-content/uploads/2017/04/service_bg.jpg?id=261) !important;}" el_id="services"][vc_column width="1/2" animation="fade-up" css=".vc_custom_1504221392027{padding-top: 30px !important;padding-right: 30px !important;padding-bottom: 30px !important;padding-left: 30px !important;background-color: #ffffff !important;border-radius: 10px !important;}"][santos_icon_box icon_ion="ion-ios-browsers-outline" icon_position="left" title="Highly Customizable" hover_bg_color="#ffffff"]Hanc ergo intuens debet institutum illud quasi signum absolvere. Quoniam, si dis placet, ab Epicuro loqui discimus.[/santos_icon_box][santos_icon_box icon_ion="ion-ios-clock-outline" icon_position="left" title="Friendly Support" hover_bg_color="#ffffff"]Hanc ergo intuens debet institutum illud quasi signum absolvere. Quoniam, si dis placet, ab Epicuro loqui discimus.[/santos_icon_box][/vc_column][vc_column width="1/2"][/vc_column][/vc_row]
CONTENT;

vc_add_default_templates( $data );




$data = array();
$data['name'] = __( 'Service Section Steps', 'js_composer' );
$data['cat_display_name'] = $cat_display_names['services']  .', '. $cat_display_names['general'];
$data['custom_class'] = 'general services';
$data['image_path'] = preg_replace( '/\s/', '%20', plugins_url( 'img/templates/service-steps.jpg', plugin_dir_path( __FILE__ ) ) ); 
$data['content'] = <<<CONTENT
[vc_section el_id="about" css=".vc_custom_1492900712418{padding-top: 100px !important;padding-bottom: 100px !important;}"][vc_row][vc_column][vc_empty_space behaviour="mobile_remove_space"][vc_column_text]
<h2>Perfect components for modern startups</h2>
[/vc_column_text][vc_empty_space][vc_column_text]Hanc ergo intuens debet institutum illud quasi signum absolvere. Quoniam, si dis placet, ab Epicuro loqui discimus. Universa enim illorum ratione cum tota vestra confligendum puto.[/vc_column_text][vc_empty_space height="60px"][vc_separator][/vc_column][/vc_row][vc_row sep_img_width="100"][vc_column][vc_empty_space height="60px"][vc_row_inner][vc_column_inner width="1/3"][santos_step_box title="Design" number="01" text_color="#ffffff" image="256" enable_bg="true"]Hanc ergo intuens debet institutum illud quasi signum absolvere. Quoniam, si dis placet, ab Epicuro loqui discimus institutum illud quasi [/santos_step_box][/vc_column_inner][vc_column_inner width="1/3"][santos_step_box title="Codeing" number="02"]Hanc ergo intuens debet institutum illud quasi signum absolvere. Quoniam, si dis placet, ab Epicuro loqui discimus institutum illud quasi [/santos_step_box][/vc_column_inner][vc_column_inner width="1/3"][santos_step_box title="Modern startups" number="03"]Hanc ergo intuens debet institutum illud quasi signum absolvere. Quoniam, si dis placet, ab Epicuro loqui discimus institutum illud quasi [/santos_step_box][/vc_column_inner][/vc_row_inner][vc_empty_space height="60px" behaviour="mobile_remove_space"][/vc_column][/vc_row][/vc_section]
CONTENT;

vc_add_default_templates( $data );




$data = array();
$data['name'] = __( 'Contact', 'js_composer' );
$data['cat_display_name'] = $cat_display_names['contact']  .', '. $cat_display_names['general'];
$data['custom_class'] = 'general contact';
$data['image_path'] = preg_replace( '/\s/', '%20', plugins_url( 'img/templates/contact-section.jpg', plugin_dir_path( __FILE__ ) ) ); 
$data['content'] = <<<CONTENT
[vc_row row_container="container-fullwidth" row_equal_height="yes" sep_img_width="100" full_width="stretch_row_content_no_spaces" equal_height="yes" el_id="contact"][vc_column width="5/12" css=".vc_custom_1504221618945{padding-top: 0px !important;background-image: url(http://uxcode.net/themes/santos/wp-content/uploads/2017/04/col_bg_2.jpg?id=273) !important;}" offset="vc_hidden-sm vc_hidden-xs"][/vc_column][vc_column width="7/12" santos_column_padding="padding-100" padding_behaviour="mobile_remove_padding" animation="fade-up"][vc_column_text]
<h2>Contact us</h2>
[/vc_column_text][vc_empty_space][santos_contact_form name_label="Your Name" email_label="Your Email" text_color="#ffffff" placeholder_animate_bg="#ffffff" placeholder_animate="true"][/vc_column][/vc_row]
CONTENT;

vc_add_default_templates( $data );




$data = array();
$data['name'] = __( 'Hero Simple', 'js_composer' );
$data['cat_display_name'] = $cat_display_names['hero']  .', '. $cat_display_names['general'];
$data['custom_class'] = 'general hero';
$data['image_path'] = preg_replace( '/\s/', '%20', plugins_url( 'img/templates/hero-style-4.jpg', plugin_dir_path( __FILE__ ) ) ); 
$data['content'] = <<<CONTENT
[vc_row row_full_height="yes" sep_img_width="100" full_width="stretch_row" full_height="yes" css=".vc_custom_1503925315094{padding-top: 100px !important;background-image: url(http://uxcode.net/themes/santos/wp-content/uploads/2017/05/intro-5.jpg?id=1457) !important;}" enable_parallax="true" el_id="intro" overlay_color="rgba(0,0,0,0.3)"][vc_column width="1/6"][/vc_column][vc_column width="2/3"][vc_custom_heading text="Brian &amp; Judith" font_container="tag:h1|font_size:110|text_align:center|color:%23ffffff|line_height:120px" google_fonts="font_family:Great%20Vibes%3Aregular|font_style:400%20regular%3A400%3Anormal"][vc_empty_space][vc_column_text css_animation="" width="700" css=".vc_custom_1502741617857{padding-right: 8% !important;padding-left: 8% !important;}" remove_padding_mobile="true"]
<h4 style="text-align: center;"><span style="color: #ffffff;">We build different component That help you create beautiful websites to your lovely clients</span></h4>
[/vc_column_text][vc_empty_space][santos_cta_btn title="" btn_title="SEE MORE" btn_title_color="#333333" btn_bg_color="#efaac4" btn_position="left" enable_video="true" url="" video_url="https://www.youtube.com/embed/6v2L2UGZJAM?version=3" video_title="Watch Full video"][/vc_column][vc_column width="1/6"][/vc_column][/vc_row]
CONTENT;

vc_add_default_templates( $data );


$data = array();
$data['name'] = __( 'About - Story', 'js_composer' );
$data['cat_display_name'] = $cat_display_names['general']  .', '. $cat_display_names['about'];
$data['custom_class'] = 'about story';
$data['image_path'] = preg_replace( '/\s/', '%20', plugins_url( 'img/templates/about-story.jpg', plugin_dir_path( __FILE__ ) ) ); 
$data['content'] = <<<CONTENT
[vc_row row_container="container-fullwidth" row_equal_height="yes" sep_img_width="100" full_width="stretch_row_content_no_spaces" equal_height="yes" el_class="fp-auto-height"][vc_column width="1/2" padding_behaviour="mobile_remove_padding" css=".vc_custom_1504225509022{padding-top: 100px !important;padding-right: 75px !important;padding-bottom: 100px !important;padding-left: 75px !important;background-color: #efaac5 !important;}"][vc_empty_space height="100px" behaviour="mobile_remove_space"][vc_column_text]
<h2>Our Story</h2>
[/vc_column_text][vc_empty_space height="20px"][vc_column_text]<span style="color: #333333;">Hanc ergo intuens debet institutum illud quasi signum absolvere. Quoniam, si dis placet, ab Epicuro loqui discimus. Universa enim illorum ratione cum tota vestra confligendum puto. intuens debet institutum illud quasi signum absolvere. Quoniam, si dis placet, ab Epicuro loqui discimus</span>[/vc_column_text][vc_empty_space height="20px"][santos_signature image="522"][vc_empty_space height="100px" behaviour="mobile_remove_space"][/vc_column][vc_column width="1/2" css=".vc_custom_1504225517396{padding-top: 0px !important;background-image: url(http://uxcode.net/themes/santos/wp-content/uploads/2017/05/col_bg_6.jpg?id=511) !important;}" offset="vc_hidden-sm vc_hidden-xs"][/vc_column][/vc_row]
CONTENT;

vc_add_default_templates( $data );



$data = array();
$data['name'] = __( 'Count Down Section', 'js_composer' );
$data['cat_display_name'] = $cat_display_names['general'];
$data['custom_class'] = 'countdown';
$data['image_path'] = preg_replace( '/\s/', '%20', plugins_url( 'img/templates/countdown-section.jpg', plugin_dir_path( __FILE__ ) ) ); 
$data['content'] = <<<CONTENT
[vc_section parallax="content-moving" parallax_speed_bg="1.7" sep_img_width="100" full_width="stretch_row" css=".vc_custom_1502742384477{padding-top: 200px !important;padding-bottom: 160px !important;background: #f3f3f3 url(http://uxcode.net/themes/santos/wp-content/uploads/2017/05/home_5_row_bg.jpg?id=533) !important;}" overlay_color="rgba(239,170,196,0.7)"][vc_row][vc_column][vc_column_text]
<h2 style="text-align: center;">You are invited</h2>
[/vc_column_text][vc_empty_space][vc_column_text]
<p style="text-align: center;"><span style="color: #333333;">Hanc ergo intuens debet institutum illud quasi signum absolvere. Quoniam
si dis placet, ab Epicuro loqui discimus.</span>

[/vc_column_text][vc_empty_space][/vc_column][/vc_row][vc_row][vc_column][santos_down_count day="05" month="10" year="2020"][/vc_column][/vc_row][/vc_section]
CONTENT;

vc_add_default_templates( $data );




$data = array();
$data['name'] = __( 'Photo Gallery', 'js_composer' );
$data['cat_display_name'] = $cat_display_names['general']  .', '. $cat_display_names['portfolio'];
$data['custom_class'] = 'gallery portfolio';
$data['image_path'] = preg_replace( '/\s/', '%20', plugins_url( 'img/templates/gallery-section.jpg', plugin_dir_path( __FILE__ ) ) ); 
$data['content'] = <<<CONTENT
[vc_section full_width="stretch_row" css=".vc_custom_1494374099787{padding-top: 100px !important;padding-bottom: 100px !important;background-color: #f3f3f3 !important;}"][vc_row][vc_column][vc_column_text]
<h2 style="text-align: center;">Photo Album</h2>
[/vc_column_text][vc_empty_space][vc_column_text]
<p style="text-align: center;">Hanc ergo intuens debet institutum illud quasi signum absolvere. Quoniam
si dis placet, ab Epicuro loqui discimus.

[/vc_column_text][vc_empty_space height="50px"][/vc_column][/vc_row][vc_row][vc_column][santos_gallery][santos_gallery_item image="535" title="Consectetur adipiscing elit" date="25 October 2015"][santos_gallery_item image="536" title="Stuprata per vim" date="25 October 2015"][santos_gallery_item image="538" title="Consectetur adipiscing elit" date="25 October 2015"][santos_gallery_item image="539" title="De vacuitate doloris" date="25 October 2015"][santos_gallery_item image="540" title="Consectetur adipiscing elit" date="25 October 2015"][santos_gallery_item image="541" title="Consectetur adipiscing elit" date="25 October 2015"][/santos_gallery][/vc_column][/vc_row][/vc_section]
CONTENT;

vc_add_default_templates( $data );




$data = array();
$data['name'] = __( 'Hero with Fancy Text', 'js_composer' );
$data['cat_display_name'] = $cat_display_names['hero']  .', '. $cat_display_names['general'];
$data['custom_class'] = 'general hero';
$data['image_path'] = preg_replace( '/\s/', '%20', plugins_url( 'img/templates/hero-style-5.jpg', plugin_dir_path( __FILE__ ) ) ); 
$data['content'] = <<<CONTENT
[vc_row row_full_height="yes" row_fullheight_percent="90" row_columns_placement="bottom" sep_img_width="100" content_placement="" fullheight_percent="90" full_width="stretch_row" css=".vc_custom_1502752944104{background-image: url(http://uxcode.net/themes/santos/wp-content/uploads/2017/04/hero_sample.jpg?id=209) !important;}"][vc_column][santos_fancy_text fancytext_prefix="Santos Theme for " text_size="70" fancytext_strings="Designers
Portfolios
Blogers" fancytext_color="#425bb5" prefixtext_color="#ffffff"][vc_custom_heading text="A high-performant Multi-Purpose WordPress theme
suitable for any kind of project." font_container="tag:p|font_size:19px|text_align:center|color:%23ffffff|line_height:32px" use_theme_fonts="yes"][vc_empty_space height="80px"][/vc_column][/vc_row]
CONTENT;

vc_add_default_templates( $data );





$data = array();
$data['name'] = __( 'About with Image Box', 'js_composer' );
$data['cat_display_name'] = $cat_display_names['general']  .', '. $cat_display_names['about'];
$data['custom_class'] = 'about';
$data['image_path'] = preg_replace( '/\s/', '%20', plugins_url( 'img/templates/about-imagebox.jpg', plugin_dir_path( __FILE__ ) ) ); 
$data['content'] = <<<CONTENT
[vc_row santos_section_padding="padding-100" animation="fade-up" sep_img_width="100" css=".vc_custom_1504275112532{background-color: #f3f3f3 !important;}"][vc_column][vc_column_text]
<h2 style="text-align: center;">You deserve a stunning website</h2>
[/vc_column_text][vc_empty_space][vc_column_text]
<p style="text-align: center;">Hanc ergo intuens debet institutum illud quasi signum absolvere.Quoniam,
si dis placet, ab Epicuro loqui

[/vc_column_text][vc_empty_space height="50px"][vc_row_inner][vc_column_inner width="1/3"][santos_image_box title="Developer Friendly" align="left" image="216"]Hanc ergo intuens debet institutum illud quasi signum absolvere. [/santos_image_box][/vc_column_inner][vc_column_inner width="1/3"][santos_image_box title="Modern startups" align="left" image="217"]Hanc ergo intuens debet institutum illud quasi signum absolvere. [/santos_image_box][/vc_column_inner][vc_column_inner width="1/3"][santos_image_box title="Easy Interface" align="left" image="218"]Hanc ergo intuens debet institutum illud quasi signum absolvere. [/santos_image_box][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row]
CONTENT;

vc_add_default_templates( $data );




$data = array();
$data['name'] = __( 'Service Section', 'js_composer' );
$data['cat_display_name'] = $cat_display_names['services']  .', '. $cat_display_names['general'];
$data['custom_class'] = 'general services';
$data['image_path'] = preg_replace( '/\s/', '%20', plugins_url( 'img/templates/service-section-4.jpg', plugin_dir_path( __FILE__ ) ) ); 
$data['content'] = <<<CONTENT
[vc_row parallax="content-moving" parallax_image="220" santos_section_padding="padding-150" sep_img_width="100" full_width="stretch_row"][vc_column width="1/2" animation="fade-up" css=".vc_custom_1501975065483{padding-top: 30px !important;padding-right: 30px !important;padding-bottom: 30px !important;padding-left: 30px !important;}" offset="vc_col-lg-6 vc_col-md-6 vc_col-xs-8"][vc_column_text]
<h2>Perfect components for modern startups</h2>
[/vc_column_text][vc_empty_space][vc_column_text]Hanc ergo intuens debet institutum illud quasi signum absolvere. Quoniam, si dis placet, ab Epicuro loqui discimus. Universa enim illorum ratione cum tota vestra confligendum puto.[/vc_column_text][/vc_column][vc_column width="1/2"][/vc_column][/vc_row]
CONTENT;

vc_add_default_templates( $data );




$data = array();
$data['name'] = __( 'Price Box Section', 'js_composer' );
$data['cat_display_name'] = $cat_display_names['pricing'];
$data['custom_class'] = 'pricing';
$data['image_path'] = preg_replace( '/\s/', '%20', plugins_url( 'img/templates/price-box-2.jpg', plugin_dir_path( __FILE__ ) ) ); 
$data['content'] = <<<CONTENT
[vc_row css=".vc_custom_1492631253787{padding-top: 100px !important;padding-bottom: 100px !important;}"][vc_column width="1/2"][santos_price_box bg_color="#ffffff" price="50" symbol="$" price_color="#425bb5" title="Basic editions" options_sep_color="#eeeeee" options="100 Mb Storage
Unlimited Storage
1 Personalized Page
Unlimited Storage" disable_title_sep="true" disable_hover="true"]A no-commitment plan for hobbyists and tinkerers looking to experiment with design.[/santos_price_box][/vc_column][vc_column width="1/2"][santos_price_box bg_color="#232323" price="90" symbol="$" price_color="#ffffff" title="Premium edition" title_color="#ffffff" desc_color="#a9a9a9" options_color="#ffffff" options_sep_color="#333333" btn_text_color="#333333" btn_bg_color="#ffffff" options="100 Mb Storage
Unlimited Storage
1 Personalized Page
Unlimited Storage" disable_title_sep="true"]A no-commitment plan for hobbyists and tinkerers looking to experiment with design.[/santos_price_box][/vc_column][/vc_row]
CONTENT;

vc_add_default_templates( $data );



$data = array();
$data['name'] = __( 'Hero Simple', 'js_composer' );
$data['cat_display_name'] = $cat_display_names['hero']  .', '. $cat_display_names['general'];
$data['custom_class'] = 'general hero';
$data['image_path'] = preg_replace( '/\s/', '%20', plugins_url( 'img/templates/hero-style-6.jpg', plugin_dir_path( __FILE__ ) ) ); 
$data['content'] = <<<CONTENT
[vc_row row_full_height="yes" row_columns_placement="bottom" row_equal_height="yes" sep_img_width="100" css=".vc_custom_1501203737686{padding-right: 30px !important;padding-left: 30px !important;background-color: #f3f3f3 !important;}"][vc_column width="1/2"][vc_empty_space height="100px"][vc_column_text]
<h1 class="darckColor">Welcome to Santos Studio.</h1>
[/vc_column_text][vc_empty_space][vc_column_text]Cupit enim dícere nihil posse ad beatam vitam deesse sapienti. Nunc haec primum fortasse audientis servire
debemus. Cupit enim dícere nihil posse ad beatam vitam deesse sapienti.[/vc_column_text][vc_empty_space][santos_signature image="1177"][vc_empty_space height="100px" behaviour="mobile_remove_space"][/vc_column][vc_column width="1/2"][vc_single_image image="556" img_size="full" el_class="flex-end"][/vc_column][/vc_row]
CONTENT;

vc_add_default_templates( $data );


$data = array();
$data['name'] = __( 'About with Lightbox Video', 'js_composer' );
$data['cat_display_name'] = $cat_display_names['general']  .', '. $cat_display_names['about'];
$data['custom_class'] = 'about';
$data['image_path'] = preg_replace( '/\s/', '%20', plugins_url( 'img/templates/video-lightbox-2.jpg', plugin_dir_path( __FILE__ ) ) ); 
$data['content'] = <<<CONTENT
[vc_row santos_section_padding="padding-150" sep_img_width="100" full_height="yes" css=".vc_custom_1499449122202{padding-right: 30px !important;padding-left: 30px !important;background-image: url(http://uxcode.net/themes/santos/wp-content/uploads/2017/05/home-7-about.jpg?id=617) !important;}" overlay_color="rgba(0,0,0,0.87)"][vc_column width="1/2"][santos_lightbox_video style="img" image="618" url="https://www.youtube.com/embed/6v2L2UGZJAM?version=3"][/vc_column][vc_column width="1/2" css=".vc_custom_1504279768471{padding-right: 30px !important;padding-left: 30px !important;}"][vc_column_text]
<h2 class="white-color"><span style="color: #ffffff;">Perfect components for modern startups</span></h2>
[/vc_column_text][vc_empty_space][vc_column_text]<span style="color: #ffffff;">Hanc ergo intuens debet institutum illud quasi signum absolvere. Quoniam, si dis placet, ab Epicuro loqui discimus. Universa enim illorum ratione cum tota vestra confligendum puto.</span>[/vc_column_text][/vc_column][/vc_row]
CONTENT;

vc_add_default_templates( $data );





$data = array();
$data['name'] = __( 'Service - Icon with Text', 'js_composer' );
$data['cat_display_name'] = $cat_display_names['icons']  .', '. $cat_display_names['services'];
$data['custom_class'] = 'icons services';
$data['image_path'] = preg_replace( '/\s/', '%20', plugins_url( 'img/templates/icon-with-text-3.jpg', plugin_dir_path( __FILE__ ) ) ); 
$data['content'] = <<<CONTENT
[vc_section css=".vc_custom_1495654211005{padding-top: 100px !important;padding-right: 30px !important;padding-bottom: 100px !important;padding-left: 30px !important;background-color: #f3f3f3 !important;}"][vc_row][vc_column][vc_column_text]
<h2 style="text-align: center;">Core Features</h2>
[/vc_column_text][vc_empty_space][vc_column_text]
<p style="text-align: center;">Hanc ergo intuens debet institutum illud quasi signum absolvere. Quoniam
si dis placet, ab Epicuro loqui discimus.

[/vc_column_text][vc_empty_space height="50px"][/vc_column][/vc_row][vc_row gap="5"][vc_column width="1/3"][santos_icon_box icon_ion="ion-monitor" icon_color="#ffffff" icon_size="50" icon_position="top" icon_align="center" title="Responsive Layout" title_color="#ffffff" text_color="#ffffff" hover_bg_color="#ffffff" image="224" enable_hover="true"]Hanc ergo intuens debet institutum illud quasi signum absolvere. Quoniam, si dis placet, ab Epicuro loqui discimus. [/santos_icon_box][vc_empty_space height="30px"][/vc_column][vc_column width="1/3"][santos_icon_box icon_ion="ion-ios-infinite" icon_color="#ffffff" icon_size="50" icon_position="top" icon_align="center" title="TONS OF FEATURES" title_color="#ffffff" text_color="#ffffff" hover_bg_color="#ffffff" image="631" enable_hover="true"]Hanc ergo intuens debet institutum illud quasi signum absolvere. Quoniam, si dis placet, ab Epicuro loqui discimus. [/santos_icon_box][vc_empty_space height="30px"][/vc_column][vc_column width="1/3"][santos_icon_box icon_ion="ion-ios-albums-outline" icon_color="#ffffff" icon_size="50" icon_position="top" icon_align="center" title="Page Builder" title_color="#ffffff" text_color="#ffffff" hover_bg_color="#ffffff" image="632" enable_hover="true"]Hanc ergo intuens debet institutum illud quasi signum absolvere. Quoniam, si dis placet, ab Epicuro loqui discimus. [/santos_icon_box][vc_empty_space height="30px"][/vc_column][/vc_row][/vc_section]
CONTENT;

vc_add_default_templates( $data );




$data = array();
$data['name'] = __( 'Portfolio Masnory', 'js_composer' );
$data['cat_display_name'] = $cat_display_names['general']  .', '. $cat_display_names['portfolio'];
$data['custom_class'] = 'portfolio';
$data['image_path'] = preg_replace( '/\s/', '%20', plugins_url( 'img/templates/portfolio-masonry-section.jpg', plugin_dir_path( __FILE__ ) ) ); 
$data['content'] = <<<CONTENT
[vc_section css=".vc_custom_1495654233515{padding-top: 100px !important;}"][vc_row][vc_column][vc_column_text]
<h2 style="text-align: center;">Recent Work</h2>
[/vc_column_text][vc_empty_space][vc_column_text]
<p style="text-align: center;">Hanc ergo intuens debet institutum illud quasi signum absolvere. Quoniam
si dis placet, ab Epicuro loqui discimus.

[/vc_column_text][vc_empty_space height="50px"][/vc_column][/vc_row][vc_row row_container="container-fullwidth" sep_img_width="100"][vc_column css=".vc_custom_1495654503141{padding-right: 0px !important;padding-left: 0px !important;}"][santos_portfolio enable_filter="true" style="masonry" hover_color_style="custom_color" hover_custom_color="rgba(30,30,30,0.85)" items_per_page="5"][/vc_column][/vc_row][/vc_section]
CONTENT;

vc_add_default_templates( $data );


}

?>