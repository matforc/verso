<?php

if (!class_exists('WPBakeryShortCode'))
return false;
	


if(!function_exists('santos_get_vc_version')) {
    /**
     * Return Visual Composer version string
     *
     * @return bool|string
     */
    function santos_get_vc_version()
    {
	return WPB_VC_VERSION;

    }
}







/*
 function santos_vc_remove_post_type(){
	unregister_post_type( 'vc_grid_item' );
}
add_action('init','santos_vc_remove_post_type');


function custom_menu_page_removing() {
	//remove_menu_page( 'admin.php?page=vc-roles','vc-general' );
	remove_submenu_page( 'vc-general','vc-roles' );
	remove_submenu_page( 'vc-general','vc_grid_item' );
}
add_action( 'admin_menu', 'custom_menu_page_removing' );
*/

/*** Removing shortcodes ***/
vc_remove_element("vc_widget_sidebar");
vc_remove_element("vc_wp_search");
vc_remove_element("vc_wp_meta");
vc_remove_element("vc_wp_recentcomments");
vc_remove_element("vc_wp_calendar");
vc_remove_element("vc_wp_pages");
vc_remove_element("vc_wp_tagcloud");
vc_remove_element("vc_wp_custommenu");
vc_remove_element("vc_wp_text");
vc_remove_element("vc_wp_posts");
vc_remove_element("vc_wp_links");
vc_remove_element("vc_wp_categories");
vc_remove_element("vc_wp_archives");
vc_remove_element("vc_wp_rss");
vc_remove_element("vc_teaser_grid");
vc_remove_element("vc_images_carousel");
vc_remove_element("vc_pinterest");
vc_remove_element("vc_tweetmeme");
vc_remove_element("vc_facebook");
vc_remove_element("vc_googleplus");
vc_remove_element("vc_message");
vc_remove_element("vc_posts_slider");
vc_remove_element( "vc_tta_pageable" );
vc_remove_element("vc_icon");
vc_remove_element("vc_gallery");
vc_remove_element("vc_gmaps");
vc_remove_element("vc_cta");
vc_remove_element("vc_btn");
vc_remove_element("vc_flickr");





/*vc_remove_element("vc_raw_html"); */

vc_remove_element("vc_raw_js");


/*** Removing deprecated vc items ***/
vc_remove_element("vc_tabs");
vc_remove_element("vc_tour");
vc_remove_element("vc_accordion");



// Removing Grid
vc_remove_element("vc_basic_grid");
vc_remove_element("vc_masonry_grid");
vc_remove_element("vc_media_grid");	
vc_remove_element("vc_masonry_media_grid");


function santos_vc_remove_woocommerce() {

    if ( is_plugin_active( 'woocommerce/woocommerce.php' ) ) {

        vc_remove_element( 'woocommerce_cart' );
        vc_remove_element( 'woocommerce_checkout' );
		vc_remove_element("woocommerce_my_account");
        vc_remove_element( 'woocommerce_order_tracking' );
		vc_remove_element("product");
		vc_remove_element("products");
		vc_remove_element("add_to_cart");
		vc_remove_element("add_to_cart_url");
		vc_remove_element("product_page");
		vc_remove_element("product_category");
		vc_remove_element("product_categories");
		vc_remove_element("product_attribute");

        // Add other elements that should be removed here

    }
}

// Hook for admin editor.
add_action( 'vc_build_admin_page', 'santos_vc_remove_woocommerce', 11 );
// Hook for frontend editor.
add_action( 'vc_load_shortcode', 'santos_vc_remove_woocommerce', 11 );




if(function_exists('vc_add_shortcode_param'))
{
vc_add_shortcode_param('santos_number' , 'santos_number_settings_field');
}
function santos_number_settings_field($settings, $value)
{
			/*$dependency = vc_generate_dependencies_attributes($settings);*/
			$dependency = '';
			$param_name = isset($settings['param_name']) ? $settings['param_name'] : '';
			$type = isset($settings['type']) ? $settings['type'] : '';
			$min = isset($settings['min']) ? $settings['min'] : '';
			$max = isset($settings['max']) ? $settings['max'] : '';
			$step = isset($settings['step']) ? $settings['step'] : '';
			$suffix = isset($settings['suffix']) ? $settings['suffix'] : '';
			$class = isset($settings['class']) ? $settings['class'] : '';
			$output = '<input type="number" min="'.$min.'" max="'.$max.'" step="'.$step.'" class="wpb_vc_param_value ' . $param_name . ' ' . $type . ' ' . $class . '" name="' . $param_name . '" value="'.$value.'" style="max-width:100px; margin-right: 10px;" />'.$suffix;
			return $output;
}



/*
Add Toggle Option to Visual Composer Params
*/
if (function_exists('vc_add_shortcode_param')) {
    vc_add_shortcode_param('santos_toggle', 'santos_toggle_param_field');
}
function santos_toggle_param_field($settings, $value)
{
    $dependency = '';
    $param_name = isset($settings['param_name']) ? $settings['param_name'] : '';
    $type       = isset($settings['type']) ? $settings['type'] : '';
    $output     = '';
    $uniqeID    = uniqid();

    $output .= '<span class="santos-toggle-button santos-composer-toggle" id="toggle-switch-' . $uniqeID . '"><span class="toggle-handle"></span><input type="hidden" ' . $dependency . ' class="wpb_vc_param_value ' . $dependency . ' ' . $param_name . ' ' . $type . '" value="' . $value . '" name="' . $param_name . '"/></span>';

    $output .= '<script type="text/javascript">

        var this_toggle_' . $uniqeID . ' = jQuery("#toggle-switch-' . $uniqeID . '"),
            this_input_' . $uniqeID . ' = this_toggle_' . $uniqeID . '.find("input");

        if(this_input_' . $uniqeID . '.val() == "true"){
            this_toggle_' . $uniqeID . '.addClass("on");
        } else {
            this_toggle_' . $uniqeID . '.addClass("off");
        }

        this_toggle_' . $uniqeID . '.click(function() {

            if(this_toggle_' . $uniqeID . '.hasClass("on")) {
                    this_toggle_' . $uniqeID . '.removeClass("on").addClass("off");
                    this_input_' . $uniqeID . '.val("false");
            } else {
                    this_toggle_' . $uniqeID . '.removeClass("off").addClass("on");
                    this_input_' . $uniqeID . '.val("true");
            }
        });

    </script>';

    return $output;
}


/*

Add Range Option to Visual Composer Params

*/

if (function_exists('vc_add_shortcode_param')) {
    vc_add_shortcode_param('santos_range', 'santos_range_settings_field');
}

function santos_range_settings_field($settings, $value)
{

    $dependency = '';
    $param_name = isset($settings['param_name']) ? $settings['param_name'] : '';
    $type       = isset($settings['type']) ? $settings['type'] : '';
    $min        = isset($settings['min']) ? $settings['min'] : '';
    $max        = isset($settings['max']) ? $settings['max'] : '';
    $step       = isset($settings['step']) ? $settings['step'] : '';
    $unit       = isset($settings['unit']) ? $settings['unit'] : '';
    $uniqeID    = uniqid();

    $output     = '';

    $output .= '<div class="ux-ui-input-slider" ><div ' . $dependency . ' class="ux-range-input ' . $dependency . '" data-value="' . $value . '" data-min="' . $min . '" data-max="' . $max . '" data-step="' . $step . '" id="rangeInput-' . $uniqeID . '"></div><input name="' . $param_name . '"  class="range-input-selector wpb_vc_param_value ' . $param_name . ' ' . $type . '" type="text" value="' . $value . '"/><span class="unit">' . $unit . '</span></div>';

    $output .= '<script type="text/javascript">



        var range_wrapper_' . $uniqeID . ' = jQuery("#rangeInput-' . $uniqeID . '"),


            ux_min = parseFloat(range_wrapper_' . $uniqeID . '.attr("data-min")),
            ux_max = parseFloat(range_wrapper_' . $uniqeID . '.attr("data-max")),
            ux_step = parseFloat(range_wrapper_' . $uniqeID . '.attr("data-step")),
            ux_value = parseFloat(range_wrapper_' . $uniqeID . '.attr("data-value"));


            range_wrapper_' . $uniqeID . '.slider({

                  value:ux_value,

                  min: ux_min,

                  max: ux_max,

                  step: ux_step,

                  slide: function( event, ui ) {

                    range_wrapper_' . $uniqeID . '.siblings(".range-input-selector").val(ui.value );

                  }

            });

    </script>';
    return $output;
}



if(function_exists('vc_add_shortcode_param'))
{
vc_add_shortcode_param('santos_ion_icons', 'santos_ion_icons_settings');
}

// Ionicon Icon Function
	function santos_ion_icons_settings($settings, $value) {
		$dependency = '';
		
		$icons = array(
		'none' => 'No Icon',
		'ion-alert' => 'ion-alert',
		'ion-alert-circled' => 'ion-alert-circled',
		'ion-android-add' => 'ion-android-add',
		'ion-android-add-circle' => 'ion-android-add-circle',
		'ion-android-alarm-clock' => 'ion-android-alarm-clock',
		'ion-android-alert' => 'ion-android-alert',
		'ion-android-apps' => 'ion-android-apps',
		'ion-android-archive' => 'ion-android-archive',
		'ion-android-arrow-back' => 'ion-android-arrow-back',
		'ion-android-arrow-down' => 'ion-android-arrow-down',
		'ion-android-arrow-dropdown' => 'ion-android-arrow-dropdown',
		'ion-android-arrow-dropdown-circle' => 'ion-android-arrow-dropdown-circle',
		'ion-android-arrow-dropleft' => 'ion-android-arrow-dropleft',
		'ion-android-arrow-dropleft-circle' => 'ion-android-arrow-dropleft-circle',
		'ion-android-arrow-dropright' => 'ion-android-arrow-dropright',
		'ion-android-arrow-dropright-circle' => 'ion-android-arrow-dropright-circle',
		'ion-android-arrow-dropup' => 'ion-android-arrow-dropup',
		'ion-android-arrow-dropup-circle' => 'ion-android-arrow-dropup-circle',
		'ion-android-arrow-forward' => 'ion-android-arrow-forward',
		'ion-ion-android-arrow-up' => 'ion-android-arrow-up',
		'ion-android-attach' => 'ion-android-attach',
		'ion-android-bar' => 'ion-android-bar',
		'ion-android-bicycle' => 'ion-android-bicycle',
		'ion-android-boat' => 'ion-android-boat',
		'ion-android-bookmark' => 'ion-android-bookmark',
		'ion-android-bulb' => 'ion-android-bulb',
		'ion-android-bus' => 'ion-android-bus',
		'ion-android-calendar' => 'ion-android-calendar',
		'ion-android-call' => 'ion-android-call',
		'ion-android-camera' => 'ion-android-camera',
		'ion-android-cancel' => 'ion-android-cancel',
		'ion-android-car' => 'ion-android-car',
		'ion-android-cart' => 'ion-android-cart',
		'ion-android-chat' => 'ion-android-chat',
		'ion-android-checkbox' => 'ion-android-checkbox',
		'ion-android-checkbox-blank' => 'ion-android-checkbox-blank',
		'ion-android-checkbox-outline' => 'ion-android-checkbox-outline',
		'ion-android-checkbox-outline-blank' => 'ion-android-checkbox-outline-blank',
		'ion-android-checkmark-circle' => 'ion-android-checkmark-circle',
		'ion-android-clipboard' => 'ion-android-clipboard',
		'ion-android-close' => 'ion-android-close',
		'ion-android-cloud' => 'ion-android-cloud',
		'ion-android-cloud-circle' => 'ion-android-cloud-circle',
		'ion-android-cloud-done' => 'ion-android-cloud-done',
		'ion-android-cloud-outline' => 'ion-android-cloud-outline',
		'ion-android-color-palette' => 'ion-android-color-palette',
		'ion-android-compass' => 'ion-android-compass',
		'ion-android-contact' => 'ion-android-contact',
		'ion-android-contacts' => 'ion-android-contacts',
		'ion-android-contract' => 'ion-android-contract',
		'ion-android-create' => 'ion-android-create',
		'ion-android-delete' => 'ion-android-delete',
		'ion-android-desktop' => 'ion-android-desktop',
		'ion-android-document' => 'ion-android-document',
		'ion-android-done' => 'ion-android-done',
		'ion-android-done-all' => 'ion-android-done-all',
		'ion-android-download' => 'ion-android-download',
		'ion-android-drafts' => 'ion-android-drafts',
		'ion-android-exit' => 'ion-android-exit',
		'ion-android-expand' => 'ion-android-expand',
		'ion-android-favorite' => 'ion-android-favorite',
		'ion-android-favorite-outline' => 'ion-android-favorite-outline',
		'ion-android-film' => 'ion-android-film',
		'ion-android-folder' => 'ion-android-folder',
		'ion-android-folder-open' => 'ion-android-folder-open',
		'ion-android-funnel' => 'ion-android-funnel',
		'ion-android-globe' => 'ion-android-globe',
		'ion-android-hand' => 'ion-android-hand',
		'ion-android-hangout' => 'ion-android-hangout',
		'ion-android-happy' => 'ion-android-happy',
		'ion-android-home' => 'ion-android-home',
		'ion-android-image' => 'ion-android-image',
		'ion-android-laptop' => 'ion-android-laptop',
		'ion-android-list' => 'ion-android-list',
		'ion-android-locate' => 'ion-android-locate',
		'ion-android-lock' => 'ion-android-lock',
		'ion-android-mail' => 'ion-android-mail',
		'ion-android-map' => 'ion-android-map',
		'ion-android-menu' => 'ion-android-menu',
		'ion-android-microphone' => 'ion-android-microphone',
		'ion-android-microphone-off' => 'ion-android-microphone-off',
		'ion-android-more-horizontal' => 'ion-android-more-horizontal',
		'ion-android-more-vertical' => 'ion-android-more-vertical',
		'ion-android-navigate' => 'ion-android-navigate',
		'ion-android-notifications' => 'ion-android-notifications',
		'ion-android-notifications-none' => 'ion-android-notifications-none',
		'ion-android-notifications-off' => 'ion-android-notifications-off',
		'ion-android-open' => 'ion-android-open',
		'ion-android-options' => 'ion-android-options',
		'ion-android-people' => 'ion-android-people',
		'ion-android-person' => 'ion-android-person',
		'ion-android-person-add' => 'ion-android-person-add',
		'ion-android-phone-landscape' => 'ion-android-phone-landscape',
		'ion-android-phone-portrait' => 'ion-android-phone-portrait',
		'ion-android-pin' => 'ion-android-pin',
		'ion-android-plane' => 'ion-android-plane',
		'ion-android-playstore' => 'ion-android-playstore',
		'ion-android-print' => 'ion-android-print',
		'ion-android-radio-button-off' => 'ion-android-radio-button-off',
		'ion-android-radio-button-on' => 'ion-android-radio-button-on',
		'ion-android-refresh' => 'ion-android-refresh',
		'ion-android-remove' => 'ion-android-remove',
		'ion-android-remove-circle' => 'ion-android-remove-circle',
		'ion-android-restaurant' => 'ion-android-restaurant',
		'ion-android-sad' => 'ion-android-sad',
		'ion-android-search' => 'ion-android-search',
		'ion-android-send' => 'ion-android-send',
		'ion-android-settings' => 'ion-android-settings',
		'ion-android-share' => 'ion-android-share',
		'ion-android-share-alt' => 'ion-android-share-alt',
		'ion-android-star' => 'ion-android-star',
		'ion-android-star-half' => 'ion-android-star-half',
		'ion-android-star-outline' => 'ion-android-star-outline',
		'ion-android-stopwatch' => 'ion-android-stopwatch',
		'ion-android-subway' => 'ion-android-subway',
		'ion-android-sunny' => 'ion-android-sunny',
		'ion-android-sync' => 'ion-android-sync',
		'ion-android-textsms' => 'ion-android-textsms',
		'ion-android-time' => 'ion-android-time',
		'ion-android-train' => 'ion-android-train',
		'ion-android-unlock' => 'ion-android-unlock',
		'ion-android-upload' => 'ion-android-upload',
		'ion-android-volume-down' => 'ion-android-volume-down',
		'ion-android-volume-mute' => 'ion-android-volume-mute',
		'ion-android-volume-off' => 'ion-android-volume-off',
		'ion-android-volume-up' => 'ion-android-volume-up',
		'ion-android-walk' => 'ion-android-walk',
		'ion-android-warning' => 'ion-android-warning',
		'ion-android-watch' => 'ion-android-watch',
		'ion-android-wifi' => 'ion-android-wifi',
		'ion-aperture' => 'ion-aperture',
		'ion-archive' => 'ion-archive',
		'ion-arrow-down-a' => 'ion-arrow-down-a',
		'ion-arrow-down-b' => 'ion-arrow-down-b',
		'ion-arrow-down-c' => 'ion-arrow-down-c',
		'ion-arrow-expand' => 'ion-arrow-expand',
		'ion-arrow-graph-down-left' => 'ion-arrow-graph-down-left',
		'ion-arrow-graph-down-right' => 'ion-arrow-graph-down-right',
		'ion-arrow-graph-up-left' => 'ion-arrow-graph-up-left',
		'ion-arrow-graph-up-right' => 'ion-arrow-graph-up-right',
		'ion-arrow-left-a' => 'ion-arrow-left-a',
		'ion-arrow-left-b' => 'ion-arrow-left-b',
		'ion-arrow-left-c' => 'ion-arrow-left-c',
		'ion-arrow-move' => 'ion-arrow-move',
		'ion-arrow-resize' => 'ion-arrow-resize',
		'ion-arrow-return-left' => 'ion-arrow-return-left',
		'ion-arrow-return-right' => 'ion-arrow-return-right',
		'ion-arrow-right-a' => 'ion-arrow-right-a',
		'ion-arrow-right-b' => 'ion-arrow-right-b',
		'ion-arrow-right-c' => 'ion-arrow-right-c',
		'ion-arrow-shrink' => 'ion-arrow-shrink',
		'ion-arrow-swap' => 'ion-arrow-swap',
		'ion-arrow-up-a' => 'ion-arrow-up-a',
		'ion-arrow-up-b' => 'ion-arrow-up-b',
		'ion-arrow-up-c' => 'ion-arrow-up-c',
		'ion-asterisk' => 'ion-asterisk',
		'ion-at' => 'ion-at',
		'ion-backspace' => 'ion-backspace',
		'ion-backspace-outline' => 'ion-backspace-outline',
		'ion-bag' => 'ion-bag',
		'ion-battery-charging' => 'ion-battery-charging',
		'ion-battery-empty' => 'ion-battery-empty',
		'ion-battery-full' => 'ion-battery-full',
		'ion-battery-half' => 'ion-battery-half',
		'ion-battery-low' => 'ion-battery-low',
		'ion-beaker' => 'ion-beaker',
		'ion-beer' => 'ion-beer',
		'ion-bluetooth' => 'ion-bluetooth',
		'ion-bonfire' => 'ion-bonfire',
		'ion-bookmark' => 'ion-bookmark',
		'ion-bowtie' => 'ion-bowtie',
		'ion-briefcase' => 'ion-briefcase',
		'ion-bug' => 'ion-bug',
		'ion-calculator' => 'ion-calculator',
		'ion-calendar' => 'ion-calendar',
		'ion-camera' => 'ion-camera',
		'ion-card' => 'ion-card',
		'ion-cash' => 'ion-cash',
		'ion-chatbox' => 'ion-chatbox',
		'ion-chatbox-working' => 'ion-chatbox-working',
		'ion-chatboxes' => 'ion-chatboxes',
		'ion-chatbubble' => 'ion-chatbubble',
		'ion-chatbubble-working' => 'ion-chatbubble-working',
		'ion-chatbubbles' => 'ion-chatbubbles',
		'ion-checkmark' => 'ion-checkmark',
		'ion-checkmark-circled' => 'ion-checkmark-circled',
		'ion-checkmark-round' => 'ion-checkmark-round',
		'ion-chevron-down' => 'ion-chevron-down',
		'ion-chevron-left' => 'ion-chevron-left',
		'ion-chevron-right' => 'ion-chevron-right',
		'ion-chevron-up' => 'ion-chevron-up',
		'ion-clipboard' => 'ion-clipboard',
		'ion-clock' => 'ion-clock',
		'ion-close' => 'ion-close',
		'ion-close-circled' => 'ion-close-circled',
		'ion-close-round' => 'ion-close-round',
		'ion-closed-captioning' => 'ion-closed-captioning',
		'ion-cloud' => 'ion-cloud',
		'ion-code' => 'ion-code',
		'ion-code-download' => 'ion-code-download',
		'ion-code-working' => 'ion-code-working',
		'ion-coffee' => 'ion-coffee',
		'ion-compass' => 'ion-compass',
		'ion-compose' => 'ion-compose',
		'ion-connection-bars' => 'ion-connection-bars',
		'ion-contrast' => 'ion-contrast',
		'ion-crop' => 'ion-crop',
		'ion-cube' => 'ion-cube',
		'ion-disc' => 'ion-disc',
		'ion-document' => 'ion-document',
		'ion-document-text' => 'ion-document-text',
		'ion-drag' => 'ion-drag',
		'ion-earth' => 'ion-earth',
		'ion-easel' => 'ion-easel',
		'ion-edit' => 'ion-edit',
		'ion-egg' => 'ion-egg',
		'ion-eject' => 'ion-eject',
		'ion-email' => 'ion-email',
		'ion-email-unread' => 'ion-email-unread',
		'ion-erlenmeyer-flask' => 'ion-erlenmeyer-flask',
		'ion-erlenmeyer-flask-bubbles' => 'ion-erlenmeyer-flask-bubbles',
		'ion-eye' => 'ion-eye',
		'ion-eye-disabled' => 'ion-eye-disabled',
		'ion-female' => 'ion-female',
		'ion-filing' => 'ion-filing',
		'ion-film-marker' => 'ion-film-marker',
		'ion-fireball' => 'ion-fireball',
		'ion-flag' => 'ion-flag',
		'ion-flame' => 'ion-flame',
		'ion-flash' => 'ion-flash',
		'ion-flash-off' => 'ion-flash-off',
		'ion-folder' => 'ion-folder',
		'ion-fork' => 'ion-fork',
		'ion-fork-repo' => 'ion-fork-repo',
		'ion-forward' => 'ion-forward',
		'ion-funnel' => 'ion-funnel',
		'ion-gear-a' => 'ion-gear-a',
		'ion-gear-b' => 'ion-gear-b',
		'ion-grid' => 'ion-grid',
		'ion-hammer' => 'ion-hammer',
		'ion-happy' => 'ion-happy',
		'ion-happy-outline' => 'ion-happy-outline',
		'ion-headphone' => 'ion-headphone',
		'ion-heart' => 'ion-heart',
		'ion-heart-broken' => 'ion-heart-broken',
		'ion-help' => 'ion-help',
		'ion-help-buoy' => 'ion-help-buoy',
		'ion-help-circled' => 'ion-help-circled',
		'ion-home' => 'ion-home',
		'ion-icecream' => 'ion-icecream',
		'ion-image' => 'ion-image',
		'ion-images' => 'ion-images',
		'ion-information' => 'ion-information',
		'ion-information-circled' => 'ion-information-circled',
		'ion-ionic' => 'ion-ionic',
		'ion-ios-alarm' => 'ion-ios-alarm',
		'ion-ios-alarm-outline' => 'ion-ios-alarm-outline',
		'ion-ios-albums' => 'ion-ios-albums',
		'ion-ios-albums-outline' => 'ion-ios-albums-outline',
		'ion-ios-americanfootball' => 'ion-ios-americanfootball',
		'ion-ios-americanfootball-outline' => 'ion-ios-americanfootball-outline',
		'ion-ios-analytics' => 'ion-ios-analytics',
		'ion-ios-analytics-outline' => 'ion-ios-analytics-outline',
		'ion-ios-arrow-back' => 'ion-ios-arrow-back',
		'ion-ios-arrow-down' => 'ion-ios-arrow-down',
		'ion-ios-arrow-forward' => 'ion-ios-arrow-forward',
		'ion-ios-arrow-left' => 'ion-ios-arrow-left',
		'ion-ios-arrow-right' => 'ion-ios-arrow-right',
		'ion-ios-arrow-thin-down' => 'ion-ios-arrow-thin-down',
		'ion-ios-arrow-thin-left' => 'ion-ios-arrow-thin-left',
		'ion-ios-arrow-thin-right' => 'ion-ios-arrow-thin-right',
		'ion-ios-arrow-thin-up' => 'ion-ios-arrow-thin-up',
		'ion-ios-arrow-up' => 'ion-ios-arrow-up',
		'ion-ios-at' => 'ion-ios-at',
		'ion-ios-at-outline' => 'ion-ios-at-outline',
		'ion-ios-barcode' => 'ion-ios-barcode',
		'ion-ios-barcode-outline' => 'ion-ios-barcode-outline',
		'ion-ios-baseball' => 'ion-ios-baseball',
		'ion-ios-baseball-outline' => 'ion-ios-baseball-outline',
		'ion-ios-basketball' => 'ion-ios-basketball',
		'ion-ios-basketball-outline' => 'ion-ios-basketball-outline',
		'ion-ios-bell' => 'ion-ios-bell',
		'ion-ios-bell-outline' => 'ion-ios-bell-outline',
		'ion-ios-body' => 'ion-ios-body',
		'ion-ios-body-outline' => 'ion-ios-body-outline',
		'ion-ios-bolt' => 'ion-ios-bolt',
		'ion-ios-bolt-outline' => 'ion-ios-bolt-outline',
		'ion-ios-book' => 'ion-ios-book',
		'ion-ios-book-outline' => 'ion-ios-book-outline',
		'ion-ios-bookmarks' => 'ion-ios-bookmarks',
		'ion-ios-bookmarks-outline' => 'ion-ios-bookmarks-outline',
		'ion-ios-box' => 'ion-ios-box',
		'ion-ios-box-outline' => 'ion-ios-box-outline',
		'ion-ios-briefcase' => 'ion-ios-briefcase',
		'ion-ios-briefcase-outline' => 'ion-ios-briefcase-outline',
		'ion-ios-browsers' => 'ion-ios-browsers',
		'ion-ios-browsers-outline' => 'ion-ios-browsers-outline',
		'ion-ios-calculator' => 'ion-ios-calculator',
		'ion-ios-calculator-outline' => 'ion-ios-calculator-outline',
		'ion-ios-calendar' => 'ion-ios-calendar',
		'ion-ios-calendar-outline' => 'ion-ios-calendar-outline',
		'ion-ios-camera' => 'ion-ios-camera',
		'ion-ios-camera-outline' => 'ion-ios-camera-outline',
		'ion-ios-cart' => 'ion-ios-cart',
		'ion-ios-cart-outline' => 'ion-ios-cart-outline',
		'ion-ios-chatboxes' => 'ion-ios-chatboxes',
		'ion-ios-chatboxes-outline' => 'ion-ios-chatboxes-outline',
		'ion-ios-chatbubble' => 'ion-ios-chatbubble',
		'ion-ios-chatbubble-outline' => 'ion-ios-chatbubble-outline',
		'ion-ios-checkmark' => 'ion-ios-checkmark',
		'ion-ios-checkmark-empty' => 'ion-ios-checkmark-empty',
		'ion-ios-checkmark-outline' => 'ion-ios-checkmark-outline',
		'ion-ios-circle-filled' => 'ion-ios-circle-filled',
		'ion-ios-circle-outline' => 'ion-ios-circle-outline',
		'ion-ios-clock' => 'ion-ios-clock',
		'ion-ios-clock-outline' => 'ion-ios-clock-outline',
		'ion-ios-close' => 'ion-ios-close',
		'ion-ios-close-empty' => 'ion-ios-close-empty',
		'ion-ios-close-outline' => 'ion-ios-close-outline',
		'ion-ios-cloud' => 'ion-ios-cloud',
		'ion-ios-cloud-download' => 'ion-ios-cloud-download',
		'ion-ios-cloud-download-outline' => 'ion-ios-cloud-download-outline',
		'ion-ios-cloud-outline' => 'ion-ios-cloud-outline',
		'ion-ios-cloud-upload' => 'ion-ios-cloud-upload',
		'ion-ios-cloud-upload-outline' => 'ion-ios-cloud-upload-outline',
		'ion-ios-cloudy' => 'ion-ios-cloudy',
		'ion-ios-cloudy-night' => 'ion-ios-cloudy-night',
		'ion-ios-cloudy-night-outline' => 'ion-ios-cloudy-night-outline',
		'ion-ios-cloudy-outline' => 'ion-ios-cloudy-outline',
		'ion-ios-cog' => 'ion-ios-cog',
		'ion-ios-cog-outline' => 'ion-ios-cog-outline',
		'ion-ios-color-filter' => 'ion-ios-color-filter',
		'ion-ios-color-filter-outline' => 'ion-ios-color-filter-outline',
		'ion-ios-color-wand' => 'ion-ios-color-wand',
		'ion-ios-color-wand-outline' => 'ion-ios-color-wand-outline',
		'ion-ios-compose' => 'ion-ios-compose',
		'ion-ios-compose-outline' => 'ion-ios-compose-outline',
		'ion-ios-contact' => 'ion-ios-contact',
		'ion-ios-contact-outline' => 'ion-ios-contact-outline',
		'ion-ios-copy' => 'ion-ios-copy',
		'ion-ios-copy-outline' => 'ion-ios-copy-outline',
		'ion-ios-crop' => 'ion-ios-crop',
		'ion-ios-crop-strong' => 'ion-ios-crop-strong',
		'ion-ios-download' => 'ion-ios-download',
		'ion-ios-download-outline' => 'ion-ios-download-outline',
		'ion-ios-drag' => 'ion-ios-drag',
		'ion-ios-email' => 'ion-ios-email',
		'ion-ios-email-outline' => 'ion-ios-email-outline',
		'ion-ios-eye' => 'ion-ios-eye',
		'ion-ios-eye-outline' => 'ion-ios-eye-outline',
		'ion-ios-fastforward' => 'ion-ios-fastforward',
		'ion-ios-fastforward-outline' => 'ion-ios-fastforward-outline',
		'ion-ios-filing' => 'ion-ios-filing',
		'ion-ios-filing-outline' => 'ion-ios-filing-outline',
		'ion-ios-film' => 'ion-ios-film',
		'ion-ios-film-outline' => 'ion-ios-film-outline',
		'ion-ios-flag' => 'ion-ios-flag',
		'ion-ios-flag-outline' => 'ion-ios-flag-outline',
		'ion-ios-flame' => 'ion-ios-flame',
		'ion-ios-flame-outline' => 'ion-ios-flame-outline',
		'ion-ios-flask' => 'ion-ios-flask',
		'ion-ios-flask-outline' => 'ion-ios-flask-outline',
		'ion-ios-flower' => 'ion-ios-flower',
		'ion-ios-flower-outline' => 'ion-ios-flower-outline',
		'ion-ios-folder' => 'ion-ios-folder',
		'ion-ios-folder-outline' => 'ion-ios-folder-outline',
		'ion-ios-football' => 'ion-ios-football',
		'ion-ios-football-outline' => 'ion-ios-football-outline',
		'ion-ios-game-controller-a' => 'ion-ios-game-controller-a',
		'ion-ios-game-controller-a-outline' => 'ion-ios-game-controller-a-outline',
		'ion-ios-game-controller-b' => 'ion-ios-game-controller-b',
		'ion-ios-game-controller-b-outline' => 'ion-ios-game-controller-b-outline',
		'ion-ios-gear' => 'ion-ios-gear',
		'ion-ios-gear-outline' => 'ion-ios-gear-outline',
		'ion-ios-glasses' => 'ion-ios-glasses',
		'ion-ios-glasses-outline' => 'ion-ios-glasses-outline',
		'ion-ios-grid-view' => 'ion-ios-grid-view',
		'ion-ios-grid-view-outline' => 'ion-ios-grid-view-outline',
		'ion-ios-heart' => 'ion-ios-heart',
		'ion-ios-heart-outline' => 'ion-ios-heart-outline',
		'ion-ios-help' => 'ion-ios-help',
		'ion-ios-help-empty' => 'ion-ios-help-empty',
		'ion-ios-help-outline' => 'ion-ios-help-outline',
		'ion-ios-home' => 'ion-ios-home',
		'ion-ios-home-outline' => 'ion-ios-home-outline',
		'ion-ios-infinite' => 'ion-ios-infinite',
		'ion-ios-infinite-outline' => 'ion-ios-infinite-outline',
		'ion-ios-information' => 'ion-ios-information',
		'ion-ios-information-empty' => 'ion-ios-information-empty',
		'ion-ios-information-outline' => 'ion-ios-information-outline',
		'ion-ios-ionic-outline' => 'ion-ios-ionic-outline',
		'ion-ios-keypad' => 'ion-ios-keypad',
		'ion-ios-keypad-outline' => 'ion-ios-keypad-outline',
		'ion-ios-lightbulb' => 'ion-ios-lightbulb',
		'ion-ios-lightbulb-outline' => 'ion-ios-lightbulb-outline',
		'ion-ios-list' => 'ion-ios-list',
		'ion-ios-list-outline' => 'ion-ios-list-outline',
		'ion-ios-location' => 'ion-ios-location',
		'ion-ios-location-outline' => 'ion-ios-location-outline',
		'ion-ios-locked' => 'ion-ios-locked',
		'ion-ios-locked-outline' => 'ion-ios-locked-outline',
		'ion-ios-loop' => 'ion-ios-loop',
		'ion-ios-loop-strong' => 'ion-ios-loop-strong',
		'ion-ios-medical' => 'ion-ios-medical',
		'ion-ios-medical-outline' => 'ion-ios-medical-outline',
		'ion-ios-medkit' => 'ion-ios-medkit',
		'ion-ios-medkit-outlin' => 'ion-ios-medkit-outlin',
		'ion-ios-mic' => 'ion-ios-mic',
		'ion-ios-mic-off' => 'ion-ios-mic-off',
		'ion-ios-mic-outline' => 'ion-ios-mic-outline',
		'ion-ios-minus' => 'ion-ios-minus',
		'ion-ios-minus-empty' => 'ion-ios-minus-empty',
		'ion-ios-minus-outline' => 'ion-ios-minus-outline',
		'ion-ios-monitor' => 'ion-ios-monitor',
		'ion-ios-monitor-outline' => 'ion-ios-monitor-outline',
		'ion-ios-moon' => 'ion-ios-moon',
		'ion-ios-moon-outline' => 'ion-ios-moon-outline',
		'ion-ios-more' => 'ion-ios-more',
		'ion-ios-more-outline' => 'ion-ios-more-outline',
		'ion-ios-musical-note' => 'ion-ios-musical-note',
		'ion-ios-musical-notes' => 'ion-ios-musical-notes',
		'ion-ios-navigate' => 'ion-ios-navigate',
		'ion-ios-navigate-outline' => 'ion-ios-navigate-outline',
		'ion-ios-nutrition' => 'ion-ios-nutrition',
		'ion-ios-nutrition-outline' => 'ion-ios-nutrition-outline',
		'ion-ios-paper' => 'ion-ios-paper',
		'ion-ios-paper-outline' => 'ion-ios-paper-outline',
		'ion-ios-paperplane' => 'ion-ios-paperplane',
		'ion-ios-paperplane-outline' => 'ion-ios-paperplane-outline',
		'ion-ios-partlysunny' => 'ion-ios-partlysunny',
		'ion-ios-partlysunny-outline' => 'ion-ios-partlysunny-outline',
		'ion-ios-pause' => 'ion-ios-pause',
		'ion-ios-pause-outline' => 'ion-ios-pause-outline',
		'ion-ios-paw' => 'ion-ios-paw',
		'ion-ios-paw-outline' => 'ion-ios-paw-outline',
		'ion-ios-people' => 'ion-ios-people',
		'ion-ios-people-outline' => 'ion-ios-people-outline',
		'ion-ios-person' => 'ion-ios-person',
		'ion-ios-person-outline' => 'ion-ios-person-outline',
		'ion-ios-personadd' => 'ion-ios-personadd',
		'ion-ios-personadd-outline' => 'ion-ios-personadd-outline',
		'ion-ios-photos' => 'ion-ios-photos',
		'ion-ios-photos-outline' => 'ion-ios-photos-outline',
		'ion-ios-pie' => 'ion-ios-pie',
		'ion-ios-pie-outline' => 'ion-ios-pie-outline',
		'ion-ios-pint' => 'ion-ios-pint',
		'ion-ios-pint-outline' => 'ion-ios-pint-outline',
		'ion-ios-play' => 'ion-ios-play',
		'ion-ios-play-outline' => 'ion-ios-play-outline',
		'ion-ios-plus' => 'ion-ios-plus',
		'ion-ios-plus-empty' => 'ion-ios-plus-empty',
		'ion-ios-plus-outline' => 'ion-ios-plus-outline',
		'ion-ios-pricetag' => 'ion-ios-pricetag',
		'ion-ios-pricetag-outline' => 'ion-ios-pricetag-outline',
		'ion-ios-pricetags' => 'ion-ios-pricetags',
		'ion-ios-pricetags-outline' => 'ion-ios-pricetags-outline',
		'ion-ios-printer' => 'ion-ios-printer',
		'ion-ios-printer-outline' => 'ion-ios-printer-outline',
		'ion-ios-pulse' => 'ion-ios-pulse',
		'ion-ios-pulse-strong' => 'ion-ios-pulse-strong',
		'ion-ios-rainy' => 'ion-ios-rainy',
		'ion-ios-rainy-outline' => 'ion-ios-rainy-outline',
		'ion-ios-recording' => 'ion-ios-recording',
		'ion-ios-recording-outline' => 'ion-ios-recording-outline',
		'ion-ios-redo' => 'ion-ios-redo',
		'ion-ios-redo-outline' => 'ion-ios-redo-outline',
		'ion-ios-refresh' => 'ion-ios-refresh',
		'ion-ios-refresh-empty' => 'ion-ios-refresh-empty',
		'ion-ios-refresh-outline' => 'ion-ios-refresh-outline',
		'ion-ios-reload' => 'ion-ios-reload',
		'ion-ios-reverse-camera' => 'ion-ios-reverse-camera',
		'ion-ios-reverse-camera-outline' => 'ion-ios-reverse-camera-outline',
		'ion-ios-rewind' => 'ion-ios-rewind',
		'ion-ios-rewind-outline' => 'ion-ios-rewind-outline',
		'ion-ios-rose' => 'ion-ios-rose',
		'ion-ios-rose-outline' => 'ion-ios-rose-outline',
		'ion-ios-search' => 'ion-ios-search',
		'ion-ios-search-strong' => 'ion-ios-search-strong',
		'ion-ios-settings' => 'ion-ios-settings',
		'ion-ios-settings-strong' => 'ion-ios-settings-strong',
		'ion-ios-shuffle' => 'ion-ios-shuffle',
		'ion-ios-shuffle-strong' => 'ion-ios-shuffle-strong',
		'ion-ios-skipbackward' => 'ion-ios-skipbackward',
		'ion-ios-skipbackward-outline' => 'ion-ios-skipbackward-outline',
		'ion-ios-skipforward' => 'ion-ios-skipforward',
		'ion-ios-skipforward-outline' => 'ion-ios-skipforward-outline',
		'ion-ios-snowy' => 'ion-ios-snowy',
		'ion-ios-speedometer' => 'ion-ios-speedometer',
		'ion-ios-speedometer-outline' => 'ion-ios-speedometer-outline',
		'ion-ios-star' => 'ion-ios-star',
		'ion-ios-star-half' => 'ion-ios-star-half',
		'ion-ios-star-outline' => 'ion-ios-star-outline',
		'ion-ios-stopwatch' => 'ion-ios-stopwatch',
		'ion-ios-stopwatch-outline' => 'ion-ios-stopwatch-outline',
		'ion-ios-sunny' => 'ion-ios-sunny',
		'ion-ios-sunny-outline' => 'ion-ios-sunny-outline',
		'ion-ios-telephone' => 'ion-ios-telephone',
		'ion-ios-telephone-outline' => 'ion-ios-telephone-outline',
		'ion-ios-tennisball' => 'ion-ios-tennisball',
		'ion-ios-tennisball-outline' => 'ionios-tennisball-outline',
		'ion-ios-thunderstorm' => 'ion-ios-thunderstorm',
		'ion-ios-thunderstorm-outline' => 'ion-ios-thunderstorm-outline',
		'ion-ios-time' => 'ion-ios-time',
		'ion-ios-time-outline' => 'ion-ios-time-outline',
		'ion-ios-timer' => 'ion-ios-timer',
		'ion-ios-timer-outline' => 'ion-ios-timer-outline',
		'ion-ios-toggle' => 'ion-ios-toggle',
		'ion-ios-toggle-outline' => 'ion-ios-toggle-outline',
		'ion-ios-trash' => 'ion-ios-trash',
		'ion-ios-trash-outline' => 'ion-ios-trash-outline',
		'ion-ios-undo' => 'ion-ios-undo',
		'ion-ios-undo-outline' => 'ion-ios-undo-outline',
		'ion-ios-unlocked' => 'ion-ios-unlocked',
		'ion-ios-unlocked-outline' => 'ion-ios-unlocked-outline',
		'ion-ios-upload' => 'ion-ios-upload',
		'ion-ios-upload-outline' => 'ion-ios-upload-outline',
		'ion-ios-videocam' => 'ion-ios-videocam',
		'ion-ios-videocam-outline' => 'ion-ios-videocam-outline',
		'ion-ios-volume-high' => 'ion-ios-volume-high',
		'ion-ios-volume-low' => 'ion-ios-volume-low',
		'ion-ios-wineglass' => 'ion-ios-wineglass',
		'ion-ios-wineglass-outline' => 'ion-ios-wineglass-outline',
		'ion-ios-world' => 'ion-ios-world',
		'ion-ios-world-outline' => 'ion-ios-world-outline',
		'ion-ipad' => 'ion-ipad',
		'ion-iphone' => 'ion-iphone',
		'ion-ipod' => 'ion-ipod',
		'ion-jet' => 'ion-jet',
		'ion-key' => 'ion-key',
		'ion-knife' => 'ion-knife',
		'ion-laptop' => 'ion-laptop',
		'ion-leaf' => 'ion-leaf',
		'ion-levels' => 'ion-levels',
		'ion-lightbulb' => 'ion-lightbulb',
		'ion-link' => 'ion-link',
		'ion-load-a' => 'ion-load-a',
		'ion-load-b' => 'ion-load-b',
		'ion-load-c' => 'ion-load-c',
		'ion-load-d' => 'ion-load-d',
		'ion-location' => 'ion-location',
		'ion-lock-combination' => 'ion-lock-combination',
		'ion-locked' => 'ion-locked',
		'ion-log-in' => 'ion-log-in',
		'ion-log-out' => 'ion-log-out',
		'ion-loop' => 'ion-loop',
		'ion-magnet' => 'ion-magnet',
		'ion-male' => 'ion-male',
		'ion-man' => 'ion-man',
		'ion-map' => 'ion-map',
		'ion-medkit' => 'ion-medkit',
		'ion-medkit' => 'ion-medkit',
		'ion-mic-a' => 'ion-mic-a',
		'ion-mic-b' => 'ion-mic-b',
		'ion-mic-c' => 'ion-mic-c',
		'ion-minus' => 'ion-minus',
		'ion-minus-circled' => 'ion-minus-circled',
		'ion-minus-round' => 'ion-minus-round',
		'ion-model-s' => 'ion-model-s',
		'ion-monitor' => 'ion-monitor',
		'ion-more' => 'ion-more',
		'ion-mouse' => 'ion-mouse',
		'ion-music-note' => 'ion-music-note',
		'ion-navicon' => 'ion-navicon',
		'ion-navicon-round' => 'ion-navicon-round',
		'ion-navigate' => 'ion-navigate',
		'ion-network' => 'ion-network',
		'ion-no-smoking' => 'ion-no-smoking',
		'ion-nuclear' => 'ion-nuclear',
		'ion-outlet' => 'ion-outlet',
		'ion-paintbrush' => 'ion-paintbrush',
		'ion-paintbucket' => 'ion-paintbucket',
		'ion-paper-airplane' => 'ion-paper-airplane',
		'ion-paperclip' => 'ion-paperclip',
		'ion-pause' => 'ion-pause',
		'ion-person' => 'ion-person',
		'ion-person-add' => 'ion-person-add',
		'ion-person-stalker' => 'ion-person-stalker',
		'ion-pie-graph' => 'ion-pie-graph',
		'ion-pin' => 'ion-pin',
		'ion-pinpoint' => 'ion-pinpoint',
		'ion-pizza' => 'ion-pizza',
		'ion-plane' => 'ion-plane',
		'ion-planet' => 'ion-planet',
		'ion-play' => 'ion-play',
		'ion-playstation' => 'ion-playstation',
		'ion-plus' => 'ion-plus',
		'ion-plus-circled' => 'ion-plus-circled',
		'ion-plus-round' => 'ion-plus-round',
		'ion-podium' => 'ion-podium',
		'ion-pound' => 'ion-pound',
		'ion-power' => 'ion-power',
		'ion-pricetag' => 'ion-pricetag',
		'ion-pricetags' => 'ion-pricetags',
		'ion-printer' => 'ion-printer',
		'ion-pull-request' => 'ion-pull-request',
		'ion-qr-scanner' => 'ion-qr-scanner',
		'ion-quote' => 'ion-quote',
		'ion-radio-waves' => 'ion-radio-waves',
		'ion-record' => 'ion-record',
		'ion-refresh' => 'ion-refresh',
		'ion-reply' => 'ion-reply',
		'ion-reply-all' => 'ion-reply-all',
		'ion-ribbon-a' => 'ion-ribbon-a',
		'ion-ribbon-b' => 'ion-ribbon-b',
		'ion-sad' => 'ion-sad',
		'ion-sad-outline' => 'ion-sad-outline',
		'ion-scissors' => 'ion-scissors',
		'ion-search' => 'ion-search',
		'ion-settings' => 'ion-settings',
		'ion-share' => 'ion-share',
		'ion-shuffle' => 'ion-shuffle',
		'ion-skip-backward' => 'ion-skip-backward',
		'ion-skip-forward' => 'ion-skip-forward',
		'ion-social-android' => 'ion-social-android',
		'ion-social-android-outline' => 'ion-social-android-outline',
		'ion-social-angular' => 'ion-social-angular',
		'ion-social-angular-outline' => 'ion-social-angular-outline',
		'ion-social-appl' => 'ion-social-appl',
		'ion-social-apple-outline' => 'ion-social-apple-outline',
		'ion-social-bitcoin' => 'ion-social-bitcoin',
		'ion-social-bitcoin-outline' => 'ion-social-bitcoin-outline',
		'ion-social-buffer' => 'ion-social-buffer',
		'ion-social-buffer-outline' => 'ion-social-buffer-outline',
		'ion-social-chrome' => 'ion-social-chrome',
		'ion-social-chrome-outline' => 'ion-social-chrome-outline',
		'ion-social-codepen' => 'ion-social-codepen',
		'ion-social-codepen-outline' => 'ion-social-codepen-outline',
		'ion-social-css3' => 'ion-social-css3',
		'ion-social-css3-outline' => 'ion-social-css3-outline',
		'ion-social-designernews' => 'ion-social-designernews',
		'ion-social-designernews-outline' => 'ion-social-designernews-outline',
		'ion-social-dribbble' => 'ion-social-dribbble',
		'ion-social-dribbble-outline' => 'ion-social-dribbble-outline',
		'ion-social-dropbox' => 'ion-social-dropbox',
		'ion-social-dropbox-outline' => 'ion-social-dropbox-outline',
		'ion-social-euro' => 'ion-social-euro',
		'ion-social-euro-outline' => 'ion-social-euro-outline',
		'ion-social-facebook' => 'ion-social-facebook',
		'ion-social-facebook-outline' => 'ion-social-facebook-outline',
		'ion-social-foursquare' => 'ion-social-foursquare',
		'ion-social-foursquare-outline' => 'ion-social-foursquare-outline',
		'ion-social-freebsd-devil' => 'ion-social-freebsd-devil',
		'ion-ion-social-github' => 'ion-social-github',
		'ion-social-github-outline' => 'ion-social-github-outline',
		'ion-social-google' => 'ion-social-google',
		'ion-social-google-outline' => 'ion-social-google-outline',
		'ion-social-googleplus' => 'ion-social-googleplus',
		'ion-social-googleplus-outline' => 'ion-social-googleplus-outline',
		'ion-social-hackernews' => 'ion-social-hackernews',
		'ion-social-hackernews-outline' => 'ion-social-hackernews-outline',
		'ion-social-html5' => 'ion-social-html5',
		'ion-social-html5-outline' => 'ion-social-html5-outline',
		'ion-social-instagram' => 'ion-social-instagram',
		'ion-social-instagram-outline' => 'ion-social-instagram-outline',
		'ion-social-javascript' => 'ion-social-javascript',
		'ion-social-javascript-outline' => 'ion-social-javascript-outline',
		'ion-social-linkedin' => 'ion-social-linkedin',
		'ion-social-linkedin-outline' => 'ion-social-linkedin-outline',
		'ion-social-markdown' => 'ion-social-markdown',
		'ion-social-nodejs' => 'ion-social-nodejs',
		'ion-social-octocat' => 'ion-social-octocat',
		'ion-social-pinterest' => 'ion-social-pinterest',
		'ion-social-pinterest-outline' => 'ion-social-pinterest-outline',
		'ion-social-python' => 'ion-social-python',
		'ion-social-reddit' => 'ion-social-reddit',
		'ion-social-reddit-outline' => 'ion-social-reddit-outline',
		'ion-social-rss' => 'ion-social-rss',
		'ion-social-rss-outline' => 'ion-social-rss-outline',
		'ion-social-sass' => 'ion-social-sass',
		'ion-social-skype' => 'ion-social-skype',
		'ion-social-skype-outline' => 'ion-social-skype-outline',
		'ion-social-snapchat' => 'ion-social-snapchat',
		'ion-social-snapchat-outline' => 'ion-social-snapchat-outline',
		'ion-social-tumblr' => 'ion-social-tumblr',
		'ion-social-tumblr-outline' => 'ion-social-tumblr-outline',
		'ion-social-tux' => 'ion-social-tux',
		'ion-social-twitch' => 'ion-social-twitch',
		'ion-social-twitch-outline' => 'ion-social-twitch-outline',
		'ion-social-twitter' => 'ion-social-twitter',
		'ion-social-twitter-outline' => 'ion-social-twitter-outline',
		'ion-social-usd' => 'ion-social-usd',
		'ion-social-usd-outline' => 'ion-social-usd-outline',
		'ion-social-vimeo' => 'ion-social-vimeo',
		'ion-social-vimeo-outline' => 'ion-social-vimeo-outline',
		'ion-social-whatsapp' => 'ion-social-whatsapp',
		'ion-social-whatsapp-outline' => 'ion-social-whatsapp-outline',
		'ion-social-windows' => 'ion-social-windows',
		'ion-social-windows-outline' => 'ion-social-windows-outline',
		'ion-social-wordpress' => 'ion-social-wordpress',
		'ion-social-wordpress-outline' => 'ion-social-wordpress-outline',
		'ion-social-yahoo' => 'ion-social-yahoo',
		'ion-social-yahoo-outline' => 'ion-social-yahoo-outline',
		'ion-social-yen' => 'ion-social-yen',
		'ion-social-yen-outline' => 'ion-social-yen-outline',
		'ion-social-youtube' => 'ion-social-youtube',
		'ion-social-youtube-outline' => 'ion-social-youtube-outline',
		'ion-soup-can' => 'ion-soup-can',
		'ion-soup-can-outline' => 'ion-soup-can-outline',
		'ion-speakerphone' => 'ion-speakerphone',
		'ion-speedometer' => 'ion-speedometer',
		'ion-spoon' => 'ion-spoon',
		'ion-star' => 'ion-star',
		'ion-stats-bars' => 'ion-stats-bars',
		'ion-steam' => 'ion-steam',
		'ion-stop' => 'ion-stop',
		'ion-thermometer' => 'ion-thermometer',
		'ion-thumbsdown' => 'ion-thumbsdown',
		'ion-thumbsup' => 'ion-thumbsup',
		'ion-toggle' => 'ion-toggle',
		'ion-toggle-filled' => 'ion-toggle-filled',
		'ion-transgender' => 'ion-transgender',
		'ion-trash-a' => 'ion-trash-a',
		'ion-trash-b' => 'ion-trash-b',
		'ion-trophy' => 'ion-trophy',
		'ion-tshirt' => 'ion-tshirt',
		'ion-tshirt-outline' => 'ion-tshirt-outline',
		'ion-umbrella' => 'ion-umbrella',
		'ion-university' => 'ion-university',
		'ion-unlocked' => 'ion-unlocked',
		'ion-upload' => 'ion-upload',
		'ion-usb' => 'ion-usb',
		'ion-videocamera' => 'ion-videocamera',
		'ion-volume-high' => 'ion-volume-high',
		'ion-volume-low' => 'ion-volume-low',
		'ion-volume-medium' => 'ion-volume-medium',
		'ion-volume-mute' => 'ion-volume-mute',
		'ion-wand' => 'ion-wand',
		'ion-waterdrop' => 'ion-waterdrop',
		'ion-wifi' => 'ion-wifi',
		'ion-wineglass' => 'ion-wineglass',
		'ion-woman' => 'ion-woman',
		'ion-wrench' => 'ion-wrench',
		'ion-xbox' => 'ion-xbox',
		

		);
	
			
			$output  = '<input id="ion-icon-preview" type="hidden" name="'.$settings['param_name'].'" class="wpb_vc_param_value '.$settings['param_name'].'" value="'.$value.'" />
			<div class="ion-icon-preview icon-preview"><i class="'.$value.'"></i></div>';
			$output .= '<input class="ion-search-icon" type="text" placeholder="Search for a suitable icon.." />';
			$output  .='<div id="icon_block" >';
			$output .= '<ul class="ion-icon-list icon-list">';
			$n = 1;
			foreach($icons as $icon)
			{
				$selected = ($icon == $value) ? 'class="selected"' : '';
				
				$output .= '<li '.$selected.' data-icon="'.$icon.'"><i class="icon '.$icon.'"></i><label class="icon">'.$icon.'</label></li>';
				$n++;
			}
			$output .='</ul>';
			$output .='</div>';
			
			$output .= '<script type="text/javascript">	
			
			
						jQuery(".ion-search-icon").keyup(function(){
						jQuery(".fonts-count").hide();
						// Retrieve the input field text and reset the count to zero
						var filter = jQuery(this).val(), count = 0;
				 
						// Loop through the icon list
						jQuery(".ion-icon-list li").each(function(){
				 
							// If the list item does not contain the text phrase fade it out
							if (jQuery(this).attr("data-icon").search(new RegExp(filter, "i")) < 0) {
								jQuery(this).fadeOut();
							} else {
								jQuery(this).show();
								count++;
							}
							if(count == 0)
								jQuery(".search-count").html(" Can\'t find the icon? <a href=\'#smile_upload_icon\' class=\'add-new-h2 smile_upload_icon\' data-target=\'iconfont_upload\' data-title=\'Upload/Select Fontello Font Zip\' data-type=\'application/octet-stream, application/zip\' data-button=\'Insert Fonts Zip File\' data-trigger=\'smile_insert_zip\' data-class=\'media-frame\'>Click here to upload</a>");
							else
								jQuery(".search-count").html(count+" Icons found.");
							if(filter == "")
								jQuery(".fonts-count").show();
						});
					});
					
					
					
					jQuery(".ion-icon-list li").click(function() {
						jQuery(this).attr("class","selected").siblings().removeAttr("class");
						var icon = jQuery(this).attr("data-icon");
						jQuery("#ion-icon-preview").val(icon);
						jQuery(".ion-icon-preview").html("<i class=\'icon "+icon+"\'></i>");
					});
			</script>';
				 
				 return $output;
		}
		
		


$social_icons_array = array(
	'' => '',
	'Facebook'=>'facebook',
	'Twitter'=>'twitter',
	'Google Plus'=>'googleplus',
	'Linked in'=>'linkedin',
	'Youtube'=>'youtube',
	'Behance'=>'behance',
	'Blogger'=>'blogger',
	'Delicious'=>'delicious',
	'Deviantart'=>'deviantart',
	'Digg'=>'digg',
	'Dribbble'=>'dribbble',
	'Dropbox'=>'dropbox',
	'Flickr'=>'flickr',
	'Github'=>'github',
	'Google'=>'google',
	'Instagram'=>'instagram-outline',
	'Pinterest'=>'pinterest',
	'Rss'=>'rss',
	'Skype'=>'skype',
	'Tumblr'=>'tumblr',
	'Vimeo'=>'vimeo',
	'Wordpress'=>'wordpress',
	'Yahoo'=>'yahoo',
	'Weibo'=>'weibo',
	'Whatsapp'=>'whatsapp-outline',
	'Soundcloud'=>'soundcloud',
);


// Css Animation
$css_animation_arr =  array(
esc_html__("No Animation",'santos-core') => "",								
esc_html__("Fade Up",'santos-core') => "fade-up",			
esc_html__("Fade Down",'santos-core') => "fade-down",		
esc_html__("Fade to Left",'santos-core') => "fade-left",		
esc_html__("Fade to Right",'santos-core') => "fade-right",		
);

		
		vc_remove_param("vc_section", "full_width");
		vc_remove_param("vc_section", "css_animation");
		vc_remove_param("vc_section", "el_class");
		
		vc_add_param( 'vc_section', array(
			'type' => 'dropdown',
			'heading' => esc_html__( 'Santos Section Padding', 'santos-core' ),
			'param_name' => 'santos_section_padding',
			 "value" => array(
                    "None" => "",
                    "Padding 150" => "padding-150",
                    "Padding 100" => "padding-100",
                ),
			'admin_label' => true,
			"description" => esc_html__( 'That will set deafault Santos section padding', 'santos-core' ),
			) );	
			
			
		
		vc_add_param( 'vc_section', array(  
		"type" => "dropdown",  
		"heading" => esc_html__("CSS Animation", 'santos-core'),  
		"param_name" => "animation",  
		"admin_label" => true,  
		"value" => $css_animation_arr,  
		"description" => esc_html__("Select animation type if you want this element to be animated when it enters into the browsers viewport. Note: Works only in modern browsers.", 'santos-core'),
		)  );	

		vc_add_param( 'vc_section', array(
			'type' => 'textfield',
			'heading' => esc_html__( 'Extra class name', 'santos-core' ),
			'param_name' => 'el_class',
			'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'santos-core' ),
		
      ) );	
	  
	  
 
 	
	vc_add_param( 'vc_section', array(
			'type' => 'colorpicker',
			'heading' => esc_html__( 'Overlay Color', 'santos-core' ),
			'param_name' => 'overlay_color',
			'group' => esc_html__( 'Effects', 'santos-core' ),
      ) );
	  
	vc_add_param( 'vc_section', array(
	'type' => 'attach_image',
	'heading' => esc_html__( 'Seperator Image', 'santos-core' ),
	'param_name' => 'sep_img',
	"value" => "",
	"description" => esc_html__("Image will be used as a middle seperator between this row and the next one",  'santos-core'),
	'group' => esc_html__( 'Effects', 'santos-core' ),
	) );	
	
	
	vc_add_param( 'vc_section', array(
	'type' => 'santos_range',
	'heading' => esc_html__( 'Seperator Image % width', 'santos-core' ),
	'param_name' => 'sep_img_width',
	"min" => 0,
	"max" => 100,
	"step" => 1,
	"value" => 100,
	"unit" => "%",
	"description" => esc_html__("Image Height will be auto according to width Default:100%",  'santos-core'),
	'group' => esc_html__( 'Effects', 'santos-core' ),
	) );	

	
	  vc_add_param( 'vc_section', array(
			'type' => 'santos_toggle',
			'heading' => esc_html__( 'Enable Seperator Image animation', 'santos-core' ),
			'param_name' => 'enable_sep_animation',
			'group' => esc_html__( 'Effects', 'santos-core' ),
      ) );	
	  
	  
		
	/*			
	vc_remove_param("vc_row", "parallax");
	vc_remove_param("vc_row", "parallax_image");
	vc_remove_param("vc_row", "parallax_speed_bg");
	vc_remove_param("vc_row", "video_bg_parallax");
	vc_remove_param("vc_row", "parallax_speed_video");
	*/

	
	
	vc_remove_param("vc_custom_heading", "css_animation");
	vc_remove_param("vc_separator", "css_animation");
	vc_remove_param("vc_text_separator", "css_animation");
	vc_remove_param("vc_single_image", "css_animation");
	
	
	
	vc_remove_param("vc_row", "full_width");
	vc_remove_param("vc_row", "full_height");
	vc_remove_param("vc_row", "columns_placement");
	vc_remove_param("vc_row", "equal_height");
	vc_remove_param("vc_row", "content_placement");
	vc_remove_param("vc_row", "full_height");
	vc_remove_param("vc_row", "gap");
	
	
	
	vc_remove_param("vc_row", "video_bg");
	vc_remove_param("vc_row", "video_bg_url");
	vc_remove_param("vc_row", "video_bg_parallax");
	vc_remove_param("vc_row", "parallax");
	vc_remove_param("vc_row", "parallax_image");
	vc_remove_param("vc_row", "parallax_speed_video");
	vc_remove_param("vc_row", "parallax_speed_bg");
	vc_remove_param("vc_row", "disable_element");
	vc_remove_param("vc_row", "el_id");
	vc_remove_param("vc_row", "css");
	
	
	
	
	
	vc_remove_param("vc_row", "css_animation");
	vc_remove_param("vc_row", "el_class");
	
	
		vc_add_param( 'vc_row', array(
			'type' => 'dropdown',
			'heading' => esc_html__( 'Content Container', 'santos-core' ),
			'param_name' => 'row_container',
			 "value" => array(
                    "Container" => "container",
                    "Full Width" => "container-fluid",
					"Full Width with no Padding" => "container-fullwidth",
                ),
			'admin_label' => true,
			"description" => esc_html__( 'Select your row container width', 'santos-core' ),
			) );	
	
		vc_add_param( 'vc_row', array(
			'type' => 'checkbox',
			'heading' => esc_html__( 'Full height row?', 'santos-core' ),
			'param_name' => 'row_full_height',
			'admin_label' => true,
			"description" => esc_html__( 'If checked row will be set to full height.', 'santos-core' ),
			'value' => array( __( 'Yes', 'santos-core' ) => 'yes' ),
			) );	
		

		vc_add_param( 'vc_row', array(
			'type' => 'dropdown',
			'heading' => __( 'Full Height % Percent', 'js_composer' ),
			'param_name' => 'row_fullheight_percent',
			'value' => array(
				__( '100%', 'js_composer' ) => '100',
				__( '90%', 'js_composer' ) => '90',
				__( '80%', 'js_composer' ) => '80',
			),
			'description' => __( 'Select columns position within row.', 'js_composer' ),
			'dependency' => array(
				'element' => 'row_full_height',
				'not_empty' => true,
			),
		) );	
		
		
		
		vc_add_param( 'vc_row', array(
			'type' => 'dropdown',
			'heading' => __( 'Columns position', 'js_composer' ),
			'param_name' => 'row_columns_placement',
			'value' => array(
				__( 'Middle', 'js_composer' ) => 'middle',
				__( 'Top', 'js_composer' ) => 'top',
				__( 'Bottom', 'js_composer' ) => 'bottom',
			),
			'description' => __( 'Select columns position within row.', 'js_composer' ),
			'dependency' => array(
				'element' => 'row_full_height',
				'not_empty' => true,
			),
		) );
		
		
		
			
	
			vc_add_param( 'vc_row', array(
			'type' => 'checkbox',
			'heading' => esc_html__( 'Equal height?', 'santos-core' ),
			'param_name' => 'row_equal_height',
			'admin_label' => true,
			"description" => esc_html__( 'If checked columns will be set to equal height.', 'santos-core' ),
			'value' => array( __( 'Yes', 'santos-core' ) => 'yes' ),
			) );






			vc_add_param( 'vc_row', array(
			'type' => 'checkbox',
			'heading' => __( 'Use video background?', 'js_composer' ),
			'param_name' => 'video_bg',
			'description' => __( 'If checked, video will be used as row background.', 'js_composer' ),
			'value' => array( __( 'Yes', 'js_composer' ) => 'yes' ),
			) );
			
			vc_add_param( 'vc_row', array(
			'type' => 'textfield',
			'heading' => __( 'YouTube link', 'js_composer' ),
			'param_name' => 'video_bg_url',
			'value' => 'https://www.youtube.com/watch?v=lMJXxhRFO1k',
			// default video url
			'description' => __( 'Add YouTube link.', 'js_composer' ),
			'dependency' => array(
				'element' => 'video_bg',
				'not_empty' => true,
			),
			) );
			
			vc_add_param( 'vc_row', array(
			'type' => 'dropdown',
			'heading' => __( 'Parallax', 'js_composer' ),
			'param_name' => 'video_bg_parallax',
			'value' => array(
				__( 'None', 'js_composer' ) => '',
				__( 'Simple', 'js_composer' ) => 'content-moving',
				__( 'With fade', 'js_composer' ) => 'content-moving-fade',
			),
			'description' => __( 'Add parallax type background for row.', 'js_composer' ),
			'dependency' => array(
				'element' => 'video_bg',
				'not_empty' => true,
			),
			) );
			
			vc_add_param( 'vc_row', array(
			'type' => 'dropdown',
			'heading' => __( 'Parallax', 'js_composer' ),
			'param_name' => 'parallax',
			'value' => array(
				__( 'None', 'js_composer' ) => '',
				__( 'Simple', 'js_composer' ) => 'content-moving',
				__( 'With fade', 'js_composer' ) => 'content-moving-fade',
			),
			'description' => __( 'Add parallax type background for row (Note: If no image is specified, parallax will use background image from Design Options).', 'js_composer' ),
			'dependency' => array(
				'element' => 'video_bg',
				'is_empty' => true,
			),
			) );
			
			vc_add_param( 'vc_row', array(
			'type' => 'attach_image',
			'heading' => __( 'Image', 'js_composer' ),
			'param_name' => 'parallax_image',
			'value' => '',
			'description' => __( 'Select image from media library.', 'js_composer' ),
			'dependency' => array(
				'element' => 'parallax',
				'not_empty' => true,
			),
			) );
			
			vc_add_param( 'vc_row', array(
			'type' => 'textfield',
			'heading' => __( 'Parallax speed', 'js_composer' ),
			'param_name' => 'parallax_speed_video',
			'value' => '1.5',
			'description' => __( 'Enter parallax speed ratio (Note: Default value is 1.5, min value is 1)', 'js_composer' ),
			'dependency' => array(
				'element' => 'video_bg_parallax',
				'not_empty' => true,
			),
			) );
			
			vc_add_param( 'vc_row', array(
			'type' => 'textfield',
			'heading' => __( 'Parallax speed', 'js_composer' ),
			'param_name' => 'parallax_speed_bg',
			'value' => '1.5',
			'description' => __( 'Enter parallax speed ratio (Note: Default value is 1.5, min value is 1)', 'js_composer' ),
			'dependency' => array(
				'element' => 'parallax',
				'not_empty' => true,
			),
			) );






			
		
			vc_add_param( 'vc_row', array(
			'type' => 'santos_toggle',
			'heading' => esc_html__( 'Stick Column', 'santos-core' ),
			'param_name' => 'row_stick_col',
			'admin_label' => true,
			"description" => esc_html__( 'If Enabled columns default padding will be removed.', 'santos-core' ),
			) );		
		
		vc_add_param( 'vc_row', array(
			'type' => 'dropdown',
			'heading' => esc_html__( 'Santos Section Padding', 'santos-core' ),
			'param_name' => 'santos_section_padding',
			 "value" => array(
                    "None" => "",
                    "Padding 150" => "padding-150",
                    "Padding 100" => "padding-100",
                ),
			'admin_label' => true,
			"description" => esc_html__( 'That will set deafault Santos section padding', 'santos-core' ),
			) );			
			
			
			
		vc_add_param( 'vc_row', array(
			'type' => 'el_id',
			'heading' => __( 'Row ID', 'js_composer' ),
			'param_name' => 'el_id',
			'description' => sprintf( __( 'Enter row ID (Note: make sure it is unique and valid according to <a href="%s" target="_blank">w3c specification</a>).', 'js_composer' ), 'http://www.w3schools.com/tags/att_global_id.asp' ),
		) );
		
		vc_add_param( 'vc_row', array(
			'type' => 'checkbox',
			'heading' => __( 'Disable row', 'js_composer' ),
			'param_name' => 'disable_element',
			// Inner param name.
			'description' => __( 'If checked the row won\'t be visible on the public side of your website. You can switch it back any time.', 'js_composer' ),
			'value' => array( __( 'Yes', 'js_composer' ) => 'yes' ),
		) );
		
	

	vc_add_param( 'vc_row', array(  
		"type" => "dropdown",  
		"heading" => esc_html__("CSS Animation", 'santos-core'),  
		"param_name" => "animation",  
		"admin_label" => true,  
		"value" => $css_animation_arr,  
		"description" => esc_html__("Select animation type if you want this element to be animated when it enters into the browsers viewport. Note: Works only in modern browsers.", 'santos-core'),
		)  );	
		
		
		vc_add_param( 'vc_row', array(
			'type' => 'textfield',
			'heading' => esc_html__( 'Extra class name', 'santos-core' ),
			'param_name' => 'el_class',
			'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'santos-core' ),
		
      ) );	
	
	
	vc_add_param( 'vc_row', array(
			'type' => 'colorpicker',
			'heading' => esc_html__( 'Overlay Color', 'santos-core' ),
			'param_name' => 'overlay_color',
			'group' => esc_html__( 'Effects', 'santos-core' ),
      ) );
	  
	  /*
	  	vc_add_param( 'vc_row', array(
			'type' => 'santos_toggle',
			'heading' => esc_html__( 'Enable Parallax', 'santos-core' ),
			'param_name' => 'enable_parallax',
			'group' => esc_html__( 'Effects', 'santos-core' ),
      ) );
	  */
	
	  vc_add_param( 'vc_row', array(
			'type' => 'santos_toggle',
			'heading' => esc_html__( 'Enable Scroll Icon', 'santos-core' ),
			'param_name' => 'enable_scroll_icon',
			'group' => esc_html__( 'Effects', 'santos-core' ),
      ) );	
	  
	  
	vc_add_param( 'vc_row', array(
				'type' => 'textfield',
				'heading' => esc_html__( 'Scroll to Row ID', 'santos-core' ),
				'param_name' => 'scroll_row_id',
				'std' => '',
				'description' => esc_html__( 'Enter Target Row ID that will be used in Scroll Icon (Example : #about)', 'santos-core' ),
				'group' => esc_html__( 'Effects', 'santos-core' ),
		) );	
		
	  
	vc_add_param( 'vc_row', array(
	'type' => 'attach_image',
	'heading' => esc_html__( 'Seperator Image', 'santos-core' ),
	'param_name' => 'sep_img',
	"value" => "",
	"description" => esc_html__("Image will be used as a middle seperator between this row and the next one",  'santos-core'),
	'group' => esc_html__( 'Effects', 'santos-core' ),
	) );	
	
	
	vc_add_param( 'vc_row', array(
	'type' => 'santos_range',
	'heading' => esc_html__( 'Seperator Image % width', 'santos-core' ),
	'param_name' => 'sep_img_width',
	"min" => 0,
	"max" => 100,
	"step" => 1,
	"value" => 100,
	"unit" => "%",
	"description" => esc_html__("Image Height will be auto according to width Default:100%",  'santos-core'),
	'group' => esc_html__( 'Effects', 'santos-core' ),
	) );	

	
	  vc_add_param( 'vc_row', array(
			'type' => 'santos_toggle',
			'heading' => esc_html__( 'Enable Seperator Image animation', 'santos-core' ),
			'param_name' => 'enable_sep_animation',
			'group' => esc_html__( 'Effects', 'santos-core' ),
      ) );	
	
	
	  /*
	  vc_add_param( 'vc_row', array(
			'type' => 'checkbox',
			'heading' => esc_html__( 'Enable Framed Overlay', 'santos-core' ),
			'param_name' => 'framed_overlay',
			"value" => "",
			'group' => esc_html__( 'Effects', 'santos-core' ),
			) ); 

	vc_add_param( 'vc_row', array(
	'type' => 'attach_image',
	'heading' => esc_html__( 'Interactive Background Image', 'santos-core' ),
	'param_name' => 'interactive_img',
	"value" => "",
	"description" => esc_html__("Stylish hover Image effect.",  'santos-core'),
	'group' => esc_html__( 'Effects', 'santos-core' ),
	) );			
	  
		*/
		
		
			vc_add_param( 'vc_row', array(
			'type' => 'css_editor',
			'heading' => __( 'CSS box', 'js_composer' ),
			'param_name' => 'css',
			'group' => __( 'Design Options', 'js_composer' ),
			) );
		
		
	

	vc_remove_param("vc_row_inner", "css_animation");
	vc_remove_param("vc_row_inner", "el_class");
	
	vc_add_param( 'vc_row_inner', array(
			'type' => 'dropdown',
			'heading' => esc_html__( 'Row Container', 'santos-core' ),
			'param_name' => 'santos_row_container',
			 "value" => array(
                    "None" => "",
                    "Container" => "container",
                    "Container Fluid" => "container-fluid",
                ),
			'admin_label' => true,
			"description" => esc_html__( 'Surround Row with Container', 'santos-core' ),
			) );			
			
	vc_add_param( 'vc_row_inner', array(
			'type' => 'textfield',
			'heading' => esc_html__( 'Extra class name', 'santos-core' ),
			'param_name' => 'el_class',
			'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'santos-core' ),
		
      ) );		
			
	vc_add_param( 'vc_row_inner', array(
			'type' => 'colorpicker',
			'heading' => esc_html__( 'Overlay Color', 'santos-core' ),
			'param_name' => 'overlay_color',
			'group' => esc_html__( 'Effects', 'santos-core' ),
      ) );
	  
	  /*
	  
	  	  vc_add_param( 'vc_row_inner', array(
			'type' => 'checkbox',
			'heading' => esc_html__( 'Enable Framed Overlay', 'santos-core' ),
			'param_name' => 'framed_overlay',
			"value" => "",
			'group' => esc_html__( 'Effects', 'santos-core' ),
		) ); 

	*/
	
		

	  
	  
	  
	  
		
		vc_remove_param("vc_column", "css_animation");
		vc_remove_param("vc_column", "el_class");
		
		
		vc_add_param( 'vc_column', array(
			'type' => 'dropdown',
			'heading' => esc_html__( 'Santos Column Padding', 'santos-core' ),
			'param_name' => 'santos_column_padding',
			 "value" => array(
                    "None" => "",
					"Padding 100" => "padding-100",
					"Padding 150" => "padding-150",
                    "Padding 200" => "padding-200",
                ),
			'admin_label' => true,
			"description" => esc_html__( 'That will set padding to column content', 'santos-core' ),
			) );
			
			
		vc_add_param( 'vc_column', array(
			'type' => 'dropdown',
			'heading' => esc_html__( 'Padding Behaviour', 'santos-core' ),
			'param_name' => 'padding_behaviour',
			 "value" => array(
                    "Alway Show" => "",
                    "Remove Padding on Mobile View" => "mobile_remove_padding",
                    "Add Padding on Mobile View" => "mobile_add_padding",
                ),
			'admin_label' => true,
			"description" => "",
			) );
			
		vc_add_param( 'vc_column', array(  
		"type" => "dropdown",  
		"heading" => esc_html__("CSS Animation", 'santos-core'),  
		"param_name" => "animation",  
		"admin_label" => true,  
		"value" => $css_animation_arr,  
		"description" => esc_html__("Select animation type if you want this element to be animated when it enters into the browsers viewport. Note: Works only in modern browsers.", 'santos-core'),
		)  );	

		vc_add_param( 'vc_column', array(
			'type' => 'textfield',
			'heading' => esc_html__( 'Extra class name', 'santos-core' ),
			'param_name' => 'el_class',
			'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'santos-core' ),
		
      ) );		

	vc_add_param( 'vc_column', array(
			'type' => 'textfield',
			'heading' => esc_html__( 'Order in Mobile View', 'santos-core' ),
			'param_name' => 'mobile_order',
			'group' => __( 'Responsive Options', 'js_composer' ),
			'description' => esc_html__( 'Change Column Display order in mobiel screen size. Please choose Number From min1 and Max 10 (Note: This work only with Full Height Row or Equal Height Column at row setting.', 'santos-core' ),
		
      ) );					  

										


	/*
		vc_add_param( 'vc_column_inner', array(  
		"type" => "dropdown",  
		"heading" => esc_html__("CSS Animation", 'santos-core'),  
		"param_name" => "animation",  
		"admin_label" => true,  
		"value" => $css_animation_arr,  
		"description" => esc_html__("Select animation type if you want this element to be animated when it enters into the browsers viewport. Note: Works only in modern browsers.", 'santos-core'),
		'group' => esc_html__( 'Effects', 'santos-core' ),
		)  );			
	*/
										
	
			

	vc_remove_param("vc_column_text", "css_animation");		
	vc_remove_param("vc_column_text", "el_class");
	  
	  vc_add_param( 'vc_column_text', array(
			'type' => 'dropdown',
			'heading' => esc_html__( 'Remove Padding from screen size', 'santos-core' ),
			'param_name' => 'remove_padding_screen',
			 "value" => array(
					"None" => "",
                    "600 px" => "600",
                    "768 px" => "768",
                    "1024 px" => "1024",
                ),
			'admin_label' => false,
			"description" => "",
			) );
	  
	vc_add_param( 'vc_column_text', array(
			'type' => 'textfield',
			'heading' => esc_html__( 'Extra class name', 'santos-core' ),
			'param_name' => 'el_class',
			'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'santos-core' ),
      ) );		
	
	/*
	vc_add_param( 'vc_column_text', array(
				 "type" => "textfield",
				 "heading" => esc_html__("Max width", 'santos-core'),
				 "param_name" => "width",
				 "description" => esc_html__("Just write a Number (ex: 450)", 'santos-core')
	) );
					
	*/					
	  
	vc_add_param( 'vc_empty_space', array(
			'type' => 'dropdown',
			'heading' => esc_html__( 'Behaviour', 'santos-core' ),
			'param_name' => 'behaviour',
			 "value" => array(
                    "Alway Show" => "",
                    "Remove Space on Mobile View" => "mobile_remove_space",
                    "Add Space on Mobile View" => "mobile_add_space",
                ),
			'admin_label' => true,
			"description" => "",
			) );
			

			


			
// Button
class WPBakeryShortCode_santos_button extends WPBakeryShortCode{}
vc_map( array(
		"name" => "Button",
		"base" => "santos_button",
		"category" => 'Santos '. esc_html__('Elements', 'santos-core'),
		"icon" => "santos_button",
		"description" => esc_html__('Add a button', 'santos-core'),
		"allowed_container_element" => 'vc_row',
		"params" => array(
					array(
							"type" => "textfield",
							"heading" => esc_html__("Text", 'santos-core'),
							"param_name" => "title",
							'value' => esc_html__( 'Text on the button', 'santos-core' ),
						),
					array(
					'type' => 'vc_link',
					'heading' => __( 'URL (Link)', 'santos-core' ),
					'param_name' => 'link',
					'description' => esc_html__( 'Add link to button.', 'santos-core' ),
					),
					
					array(			
						'type' => 'dropdown',	
						'heading' => esc_html__( 'Style', 'santos-core' ),	
						'param_name' => 'style',		
						"value" => array(
								"Default" => "default",
								"Outlined" => "outlined",
							),			
						'description' => esc_html__( 'Button style.', 'santos-core' )		
						),
						
					array(
							"type" => "colorpicker",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("Button Text Color", 'santos-core'),
							"param_name" => "text_color",
							"description" => "",
							 'std' => '#333',
						),
					array(
							"type" => "colorpicker",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("Button Background or Outlined Border Color", 'santos-core'),
							"param_name" => "bg_color",
							"description" => "",
							'std' => '',
						),	
						
					array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("Align", 'santos-core'),
							"param_name" => "align",
							"value" => array(
								"Left" => "left",
								"Center" => "center",
								"Right" => "right"
							),
							'save_always' => true,
							"description" => ""
						),
					array(
						'type' => 'textfield',
						'heading' => __( 'Extra class name', 'santos-core' ),
						'param_name' => 'el_class',
						'description' => __( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'santos-core' ),
					),

		)
));

// Separator
class WPBakeryShortCode_santos_separator extends WPBakeryShortCode{}
vc_map( array(
		"name" => "Santos Separator",
		"base" => "santos_separator",
		"category" => 'Santos '. esc_html__('Elements', 'santos-core'),
		"icon" => "santos_separator",
		"class" => "wpb_vc_separator",
		"description" => esc_html__('Horizontal Separator Line', 'santos-core'),
		"allowed_container_element" => 'vc_row',
		"params" => array(

					
					array(			
						'type' => 'dropdown',	
						'heading' => esc_html__( 'Color Style', 'santos-core' ),	
						'param_name' => 'color_style',		
						"value" => array(
								"Theme Color" => "theme_color",
								"Custom" => "custom",
							),				
						),
						
						array(
							"type" => "colorpicker",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("Separator Custom Color", 'santos-core'),
							"param_name" => "custom_color",
							"description" => "",
							 'std' => '#333',
							 "dependency" => array("element" => "color_style", "value" => array("custom")),
						),	
						
					array(	
						"type" => "dropdown",
						"class" => "",
						"heading" => "Separator Width",
						"param_name" => "sep_width",
						"value" => array(
							"Normal"		=>	"normal",
							"Small"			=>	"small"
						),
						"description" => ""
						),	
						

						
					array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("Align", 'santos-core'),
							"param_name" => "align",
							"value" => array(
								"Left" => "left",
								"Center" => "center",
								"Right" => "right"
							),
							'save_always' => true,
							"description" => ""
						),
					array(
						'type' => 'textfield',
						'heading' => __( 'Extra class name', 'santos-core' ),
						'param_name' => 'el_class',
						'description' => __( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'santos-core' ),
					),

		)
));



// Call to Action Button
class WPBakeryShortCode_santos_cta_btn extends WPBakeryShortCode{}
vc_map( array(
		"name" => "Call to Action",
		"base" => "santos_cta_btn",
		"category" => 'Santos '. esc_html__('Elements', 'santos-core'),
		"icon" => "santos_cta_btn",
		"description" => esc_html__('Add call to action button', 'santos-core'),
		"allowed_container_element" => 'vc_row',
		"params" => array(
					array(
							"type" => "textfield",
							"heading" => esc_html__("Title", 'santos-core'),
							"param_name" => "title",
							'value' => esc_html__( 'Call To Action Heading', 'santos-core' ),
						),
						
						array(
							"type" => "dropdown",
							"heading" => esc_html__("Markup", 'santos-core'),
							"param_name" => "title_tag",
							"value" => array(
								esc_html__("H1", 'santos-core') => "h1",
								esc_html__("H2", 'santos-core') => "h2",
								esc_html__("H3", 'santos-core') => "h3",
								esc_html__("H4", 'santos-core') => "h4",
								esc_html__("H5", 'santos-core') => "h5",
								esc_html__("H6", 'santos-core') => "h6",
								),
							'std' => 'h4',
						),
						array(
							"type" => "colorpicker",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("Title Color", 'santos-core'),
							"param_name" => "title_color",
							"description" => "",
							 'std' => '',
						),
					array(
							"type" => "textfield",
							"heading" => esc_html__("Button Title", 'santos-core'),
							"param_name" => "btn_title",
							'value' => esc_html__( 'Button Text', 'santos-core' ),
						),
					array(
					'type' => 'vc_link',
					'heading' => __( 'URL (Link)', 'santos-core' ),
					'param_name' => 'link',
					'description' => esc_html__( 'Add link to button.', 'santos-core' ),
					),
					
					array(			
						'type' => 'dropdown',	
						'heading' => esc_html__( 'Style', 'santos-core' ),	
						'param_name' => 'btn_style',		
						"value" => array(
								"Default" => "default",
								"Outlined" => "outlined",
							),			
						'description' => esc_html__( 'Button style.', 'santos-core' )		
						),
				
						
					array(
							"type" => "colorpicker",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("Button Text Color", 'santos-core'),
							"param_name" => "btn_title_color",
							"description" => "",
							 'std' => '',
						),
						
						array(
							"type" => "colorpicker",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("Button Background or Outlined Border Color", 'santos-core'),
							"param_name" => "btn_bg_color",
							"description" => "",
							 'std' => '',
						),
						
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("Button Position", 'santos-core'),
							"param_name" => "btn_position",
							"value" => array(
								"Default" => "default",
								"Bottom" => "bottom",
							),
							'save_always' => true,
							"description" => ""
						),
						
					/*	
					array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("Align", 'santos-core'),
							"param_name" => "align",
							"value" => array(
								"Left" => "left",
								"Center" => "center",
								"Right" => "right"
							),
							'save_always' => true,
							"description" => ""
						),
						*/
					array(
						'type' => 'textfield',
						'heading' => __( 'Extra class name', 'santos-core' ),
						'param_name' => 'el_class',
						'description' => __( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'santos-core' ),
					),
					
					array(
							"type" => "santos_toggle",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("Enable Second Button",  'santos-core'),
							"param_name" => "enable_btn_2",
							'group' => esc_html__( 'Second Button', 'santos-core' ),
							"admin_label" => false, 
					),
						
						
						
						array(
							"type" => "textfield",
							"heading" => esc_html__("Button Title", 'santos-core'),
							"param_name" => "btn_2_title",
							'group' => esc_html__( 'Second Button', 'santos-core' ),
							'value' => esc_html__( 'Button Text', 'santos-core' ),
						),
						array(
						'type' => 'vc_link',
						'heading' => __( 'URL (Link)', 'santos-core' ),
						'param_name' => 'btn_2_link',
						'group' => esc_html__( 'Second Button', 'santos-core' ),
						'description' => esc_html__( 'Add link to button.', 'santos-core' ),
						),
						
						array(			
						'type' => 'dropdown',	
						'heading' => esc_html__( 'Style', 'santos-core' ),	
						'param_name' => 'btn_2_style',		
						"value" => array(
								"Default" => "default",
								"Outlined" => "outlined",
							),			
						'group' => esc_html__( 'Second Button', 'santos-core' ),	
						'description' => esc_html__( 'Button style.', 'santos-core' )		
						),
						
						
						array(
							"type" => "colorpicker",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("Button Text Color", 'santos-core'),
							"param_name" => "btn_2_title_color",
							"description" => "",
							'group' => esc_html__( 'Second Button', 'santos-core' ),
							 'std' => '',
						),
						
						array(
							"type" => "colorpicker",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("Button Background or Outlined Border Color", 'santos-core'),
							"param_name" => "btn_2_bg_color",
							"description" => "",
							'group' => esc_html__( 'Second Button', 'santos-core' ),
							 'std' => '',
						),
						
						
						
						array(
							"type" => "santos_toggle",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("Enable Video Button",  'santos-core'),
							"param_name" => "enable_video",
							'group' => esc_html__( 'Video', 'santos-core' ),
							"admin_label" => false, 
						),
					
				 array(
						  "type" => "textfield",
						  "heading" => esc_html__("Video URL", 'santos-core'),
						  "param_name" => "video_url",
						  "description" => esc_html__("YouTube video URL", 'santos-core'),
						  'group' => esc_html__( 'Video', 'santos-core' ),
						  "admin_label" => false,
						),
						array(
						  "type" => "textfield",
						  "heading" => esc_html__("Video Title", 'santos-core'),
						  "param_name" => "video_title",
						  'group' => esc_html__( 'Video', 'santos-core' ),
						  "admin_label" => false,
						),							

		)
));


// info Box
class WPBakeryShortCode_santos_info_box extends WPBakeryShortCode{}
vc_map( array(
		"name" => "Info Box",
		"base" => "santos_info_box",
		"category" => 'Santos '. esc_html__('Elements', 'santos-core'),
		"icon" => "santos_info_box",
	    "description" => esc_html__('Display information attractive', 'santos-core'),
		"allowed_container_element" => 'vc_row',
		"params" => array(
					
					array(
							"type" => "textfield",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("Subtitle", 'santos-core'),
							"param_name" => "subtitle",
							"value" => "",
						),
													
						array(
							"type" => "colorpicker",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("Subtitle Color", 'santos-core'),
							"param_name" => "subtitle_color",
							"description" => "",
							 'std' => '#999',
						),
			
					array(
							"type" => "textfield",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("Title", 'santos-core'),
							"param_name" => "title",
							"value" => "",
						),
						
						array(
							"type" => "textarea",
							"class" => "",
							"heading" => esc_html__("Description", 'santos-core'),
							"param_name" => "content",
							"value" => "",
							"description" => esc_html__("Enter the Description here.", 'santos-core'),
							),
							
						array(
							"type" => "colorpicker",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("Text Color", 'santos-core'),
							"param_name" => "text_color",
							"description" => "",
							 'std' => '#333',
						),
						
						array(
							"type" => "checkbox",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("Enable Button", 'santos-core'),
							"param_name" => "enable_button",
							"value" => '',
							"description" => "",
							),
						
						array(
							"type" => "textfield",
							"heading" => esc_html__("Text", 'santos-core'),
							"param_name" => "btn_title",
							'value' => esc_html__( 'Text on the button', 'santos-core' ),
							'group' => esc_html__( 'Button', 'santos-core' ),
							"dependency" => array("element" => "enable_button", "value" => array("true"))
						),
						array(
						'type' => 'vc_link',
						'heading' => __( 'URL (Link)', 'santos-core' ),
						'param_name' => 'link',
						'description' => esc_html__( 'Add link to button.', 'santos-core' ),
						'group' => esc_html__( 'Button', 'santos-core' ),
						"dependency" => array("element" => "enable_button", "value" => array("true"))
						),
						array(
								"type" => "colorpicker",
								"holder" => "div",
								"class" => "",
								"heading" => esc_html__("Button Text Color", 'santos-core'),
								"param_name" => "btn_text_color",
								"description" => "",
								 'std' => '#333',
								'group' => esc_html__( 'Button', 'santos-core' ),
								"dependency" => array("element" => "enable_button", "value" => array("true")) 
							),
							
						
						array(  
						"type" => "dropdown", 
						"heading" => esc_html__("CSS Animation", 'santos-core'),
						"param_name" => "animation",
						"admin_label" => true, 
						"value" => $css_animation_arr, 
						"description" => esc_html__("Select animation type if you want this element to be animated when it enters into the browsers viewport. Note: Works only in modern browsers.", 'santos-core')
						),

						array(
						"type" => "textfield",
						"heading" => esc_html__( "Animation Delay", "santos-core" ),
						"param_name" => 'animation_delay',
						'std' => '.3',
						"description" => esc_html__( "Time to wait then start the animation (Default .3 Sec).", "santos-core" ),
						),	
						array(
							'type' => 'textfield',
							'heading' => __( 'Extra class name', 'santos-core' ),
							'param_name' => 'el_class',
							'description' => __( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'santos-core' ),
						),

	

		)
));




// Image Box
class WPBakeryShortCode_santos_image_box extends WPBakeryShortCode{}
vc_map( array(
		"name" => "Image Box",
		"base" => "santos_image_box",
		"category" => 'Santos '. esc_html__('Elements', 'santos-core'),
		"icon" => "santos_image_box",
		"description" => esc_html__('Display information with attractive image', 'santos-core'),
		"allowed_container_element" => 'vc_row',
		"params" => array(

					array(
						"type" => "attach_image",
						"holder" => "div",
						"class" => "",
						"heading" => esc_html__("Image",  'santos-core'),
						"param_name" => "image"
					),
								
					array(
							"type" => "textfield",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("Title", 'santos-core'),
							"param_name" => "title",
							"value" => "",
						),
						
						array(
							"type" => "colorpicker",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("Title Color", 'santos-core'),
							"param_name" => "title_color",
							"description" => "",
							 'std' => '',
						),	
						array(
							"type" => "textarea",
							"class" => "",
							"heading" => esc_html__("Description", 'santos-core'),
							"param_name" => "content",
							"value" => "",
							"description" => esc_html__("Enter the Description here.", 'santos-core'),
							),
							
						array(
							"type" => "colorpicker",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("Text Color", 'santos-core'),
							"param_name" => "text_color",
							"description" => "",
							 'std' => '',
						),
						
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("Box Align", 'santos-core'),
							"param_name" => "align",
							"value" => array(
								"Left" => "left",
								"Center" => "center",
								"Right" => "right"
							),
							'save_always' => true,
							"description" => ""
						),
					
					array(  
					"type" => "dropdown", 
					"heading" => esc_html__("CSS Animation", 'santos-core'),
					"param_name" => "animation",
					"admin_label" => true, 
					"value" => $css_animation_arr, 
					"description" => esc_html__("Select animation type if you want this element to be animated when it enters into the browsers viewport. Note: Works only in modern browsers.", 'santos-core')
					),
		
					array(
						'type' => 'textfield',
						'heading' => __( 'Extra class name', 'santos-core' ),
						'param_name' => 'el_class',
						'description' => __( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'santos-core' ),
					),

				

			

				

			

		)
));			

// Icon Box
class WPBakeryShortCode_santos_icon_box extends WPBakeryShortCode{}
vc_map( array(
		"name" => "Icon Box",
		"base" => "santos_icon_box",
		"category" => 'Santos '. esc_html__('Elements', 'santos-core'),
		"icon" => "santos_icon_box",
		"description" => esc_html__('Icon with Text', 'santos-core'),
		"allowed_container_element" => 'vc_row',
		"params" => array(

						array( 
							'type' => 'santos_ion_icons',
							'heading' => esc_html__( 'Icon', 'santos-core' ),
							'param_name' => 'icon_ion',
							'value' => 'ion-pizza',
							'description' => esc_html__( 'Select icon from library.', 'santos-core' ),
						),
						array(
							"type" => "colorpicker",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("Icon Color", 'santos-core'),
							"param_name" => "icon_color",
							"description" => "",
							 'std' => '',
						),
						array(
							"type" => "santos_number",
							"class" => "",
							"heading" => esc_html__("Icon Size", 'santos-core'),
							"param_name" => "icon_size",
							"value" => 0,
							"min" => 30,
							"max" => 300,
							"suffix" => "px",
							 'std' => '60',
							),
							
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("Icon Position", 'santos-core'),
							"param_name" => "icon_position",
							"value" => array(
								"Left" => "left",
								"Top" => "top",
							),
							'save_always' => true,
							"description" => ""
						),
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("Icon Align", 'santos-core'),
							"param_name" => "icon_align",
							"value" => array(
								"Left" => "left",
								"Center" => "center",
								"Right" => "right"
							),
							'save_always' => true,
							"dependency" => array("element" => "icon_position", "value" => array("top")) 
						),
			
					array(
							"type" => "textfield",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("Title", 'santos-core'),
							"param_name" => "title",
							"value" => "",
						),
						
						array(
							"type" => "colorpicker",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("Title Color", 'santos-core'),
							"param_name" => "title_color",
							"description" => "",
							 'std' => '',
						),	
						array(
							"type" => "textarea",
							"class" => "",
							"heading" => esc_html__("Description", 'santos-core'),
							"param_name" => "content",
							"value" => "",
							"description" => esc_html__("Enter the Description here.", 'santos-core'),
							),
							
						array(
							"type" => "colorpicker",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("Text Color", 'santos-core'),
							"param_name" => "text_color",
							"description" => "",
							 'std' => '',
						),
						
						array(
							"type" => "colorpicker",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("Background Color", 'santos-core'),
							"param_name" => "bg_color",
							"description" => "",
							 'std' => '',
						),
						
						
						array(
							"type" => "attach_image",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("Background Image",  'santos-core'),
							"param_name" => "image"
						),
						
						array(
							"type" => "santos_toggle",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("Enable Hover Effect",  'santos-core'),
							"param_name" => "enable_hover",
							"admin_label" => false,
						),
					
					array(
						"type" => "colorpicker",
						"holder" => "div",
						"class" => "",
						"heading" => esc_html__("Hover Background Color", 'santos-core'),
						"param_name" => "hover_bg_color",
						"description" => "",
						 'std' => '#FFF',
						 "admin_label" => false, 
						),
						
					array(  
					"type" => "dropdown", 
					"heading" => esc_html__("CSS Animation", 'santos-core'),
					"param_name" => "animation",
					"admin_label" => true, 
					"value" => $css_animation_arr, 
					"description" => esc_html__("Select animation type if you want this element to be animated when it enters into the browsers viewport. Note: Works only in modern browsers.", 'santos-core')
					),
		
					array(
						'type' => 'textfield',
						'heading' => __( 'Extra class name', 'santos-core' ),
						'param_name' => 'el_class',
						'description' => __( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'santos-core' ),
					),

				

			

				

			

		)
));





// Santos Icons
class WPBakeryShortCode_santos_icons extends WPBakeryShortCode{}
vc_map( array(
		"name" => "Icon",
		"base" => "santos_icons",
		"category" => 'Santos '. esc_html__('Elements', 'santos-core'),
		"icon" => "santos_icon",
		"description" => esc_html__('Add font line icon', 'santos-core'),
		"allowed_container_element" => 'vc_row',
		"params" => array(
						array( 
							'type' => 'santos_ion_icons',
							'heading' => esc_html__( 'Icon', 'santos-core' ),
							'param_name' => 'icon_ion',
							'value' => 'ion-pizza',
							'description' => esc_html__( 'Select icon from library.', 'santos-core' ),
						),
						array(
							"type" => "colorpicker",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("Icon Color", 'santos-core'),
							"param_name" => "icon_color",
							"description" => "",
							 'std' => '#333',
						),
						array(
							"type" => "santos_number",
							"class" => "",
							"heading" => esc_html__("Icon Size", 'santos-core'),
							"param_name" => "icon_size",
							"value" => 0,
							"min" => 10,
							"max" => 300,
							"suffix" => "px",
							'std' => '30',
						),
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("Icon Align", 'santos-core'),
							"param_name" => "icon_align",
							"value" => array(
								"Center" => "center",
								"Left" => "left",
								"Right" => "right"
							),
							'save_always' => true,
							"description" => ""
						),

		)
));



// price Box
class WPBakeryShortCode_santos_price_box extends WPBakeryShortCode{}
vc_map( array(
		"name" => "Price Box",
		"base" => "santos_price_box",
		"category" => 'Santos '. esc_html__('Elements', 'santos-core'),
		"icon" => "santos_price_box",
		"description" => esc_html__('Stylish Price Table', 'santos-core'),
		"allowed_container_element" => 'vc_row',
		"params" => array(
					array(
							"type" => "checkbox",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("Featured", 'santos-core'),
							"param_name" => "featured",
							"value" => '',
							"description" => "",
					),
					
						array(
							"type" => "colorpicker",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("Box Background Color", 'santos-core'),
							"param_name" => "bg_color",
							 'std' => '#FFF',
						),
					
					array(
							"type" => "textfield",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("Price", 'santos-core'),
							"param_name" => "price",
							"value" => "",
						),
						
						array(
							"type" => "textfield",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("Currency Symbol", 'santos-core'),
							"param_name" => "symbol",
							"value" => "",
						),
						
						array(
							"type" => "colorpicker",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("Price Color", 'santos-core'),
							"param_name" => "price_color",
							 'std' => '',
						),
													

			
					array(
							"type" => "textfield",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("Title", 'santos-core'),
							"param_name" => "title",
							"value" => "",
						),
						array(
							"type" => "colorpicker",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("Title Color", 'santos-core'),
							"param_name" => "title_color",
							 'std' => '',
						),
						
						array(
							"type" => "santos_toggle",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("Disable Title Separator",  'santos-core'),
							"param_name" => "disable_title_sep"
						),
						
						array(
							"type" => "textarea",
							"class" => "",
							"heading" => esc_html__("Description", 'santos-core'),
							"param_name" => "content",
							"value" => "",
							"description" => esc_html__("Enter the Description here.", 'santos-core'),
							),
						
						array(
							"type" => "colorpicker",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("Description Color", 'santos-core'),
							"param_name" => "desc_color",
							 'std' => '',
						),
						array(
						'type' => 'textarea',
						'heading' => esc_html__( 'Options',  'santos-core' ),
						'param_name' => 'options',
						'description' => esc_html__('Enter each option on a new line', 'santos-core'),
						'admin_label' => true
						),	

						array(
							"type" => "colorpicker",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("Options Color", 'santos-core'),
							"param_name" => "options_color",
							'std' => '',
						),						
						
						array(
							"type" => "colorpicker",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("Options seperator Color", 'santos-core'),
							"param_name" => "options_sep_color",
							'std' => '#eee',
						),
						
						array(
							"type" => "textfield",
							"heading" => esc_html__("Button Title", 'santos-core'),
							"param_name" => "btn_title",
							'value' => esc_html__( 'Order Now', 'santos-core' ),
						),
						
						array(
						'type' => 'vc_link',
						'heading' => __( 'URL (Link)', 'santos-core' ),
						'param_name' => 'link',
						'description' => esc_html__( 'Add link to button.', 'santos-core' ),
						),
							
						array(
							"type" => "colorpicker",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("Button Title Color", 'santos-core'),
							"param_name" => "btn_text_color",
							 'std' => '',
						),
						
						array(
							"type" => "colorpicker",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("Button Background Or Outlined Border Color", 'santos-core'),
							"param_name" => "btn_bg_color",
							 'std' => '',
						),

						array(
							"type" => "santos_toggle",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("Disable Hover Effect",  'santos-core'),
							"param_name" => "disable_hover"
						),	
						
						array(  
						"type" => "dropdown", 
						"heading" => esc_html__("CSS Animation", 'santos-core'),
						"param_name" => "animation",
						"admin_label" => true, 
						"value" => $css_animation_arr, 
						"description" => esc_html__("Select animation type if you want this element to be animated when it enters into the browsers viewport. Note: Works only in modern browsers.", 'santos-core')
						),

						
						array(
							'type' => 'textfield',
							'heading' => __( 'Extra class name', 'santos-core' ),
							'param_name' => 'el_class',
							'description' => __( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'santos-core' ),
						),

	

		)
));

// Santos Portfolio 
class WPBakeryShortCode_santos_portfolio extends WPBakeryShortCode{}
vc_map( array(
		"name" => "Portfolio",
		"base" => "santos_portfolio",
		"category" => 'Santos '. esc_html__('Elements', 'santos-core'),
		"icon" => "santos_portfolio",
		"description" => esc_html__('Add portfolio element', 'santos-core'),
		"allowed_container_element" => 'vc_row',
		"params" => array(
						array(
							"type" => "checkbox",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("Enable Filter", 'santos-core'),
							"param_name" => "enable_filter",
							'value' => array( __( 'Yes', 'santos-core' ) => 'yes' ),
							"description" => "",
							'admin_label' => true,
							),
						array(
							"heading" => esc_html__("Style", 'santos-core'),
							"param_name" => "style",
							"value" => array(
								esc_html__("Default", 'santos-core') => "default",
								esc_html__("Grid", 'santos-core') => "grid",
								esc_html__("Masonry", 'santos-core') => "masonry"

							),
							'admin_label' => true,
							"type" => "dropdown"
						),	
						
						array(
							"type" => "dropdown",
							"heading" => esc_html__("Column", 'santos-core'),
							"param_name" => "column",
							"admin_label" => true,
							"value" => array(
							"4 Columns" => "3",
							"3 Columns" => "4",
							"2 Columns" => "6", 
							),
							"std" => "4",
							"description" => esc_html__("Please select the column you would like for your portfolio ", 'santos-core'),
							"dependency" => Array('element' => "style", 'value' => array('default','grid'))
							),
							
						array(
						"type" => 'checkbox',
						"heading" => esc_html__("Enable Spacing", 'santos-core'),
						"param_name" => "enable_spacing",
						"description" => esc_html__("If you need to show spacing between Portfolio .", 'santos-core'),
						"value" => Array(esc_html__("Yes, please", 'santos-core') => 'true'),
						"dependency" => Array('element' => "style", 'value' => array('masonry','grid'))
						),

						array(
							"heading" => esc_html__("Order", 'santos-core'),
							"description" => esc_html__("Designates the ascending or descending order of the 'orderby' parameter.", 'santos-core'),
							"param_name" => "order",
							"value" => array(
								esc_html__("DESC (descending order)", 'santos-core') => "DESC",
								esc_html__("ASC (ascending order)", 'santos-core') => "ASC"

							),
							'admin_label' => true,
							"type" => "dropdown"
						),
						array(
							"heading" => esc_html__("Orderby", 'santos-core'),
							"description" => esc_html__("Sort retrieved Portfolio items by parameter.", 'santos-core'),
							"param_name" => "orderby",
							"value" => array(
								esc_html__("Date", 'santos-core') => "date",
								esc_html__('Menu Order', 'santos-core') => 'menu_order',
								esc_html__("post id", 'santos-core') => "id",
								esc_html__("title", 'santos-core') => "title",
								esc_html__("Comment Count", 'santos-core') => "comment_count",
								esc_html__("Random", 'santos-core') => "rand",
								esc_html__("Author", 'santos-core') => "author",
								esc_html__("No order", 'santos-core') => "none"
							),
							'admin_label' => true,
							"type" => "dropdown"
						),
					 array(
						  "type" => "textfield",
						  "heading" => esc_html__("How many Posts?", 'santos-core'),
						  "param_name" => "items_per_page",
						  "description" => esc_html__("How many Posts would you like to show? (-1 means unlimited)", 'santos-core')
						),
						
						array(
						"type" => "dropdown",
						"class" => "hover_style",
						"heading" => esc_html__("Hover Color Style", 'santos-core'),
						"param_name" => "hover_color_style",
						"value" => array(
								esc_html__("Theme Color", 'santos-core') => "theme_color",
								esc_html__("Custom", 'santos-core') => "custom_color"

							),
						"description" => "Single Hover Color Option Should be selected for each Single Portfolio page",
						"std" => "theme_color",
						),
						
				
						array(
							"type" => "santos_number",
							"class" => "",
							"heading" => esc_html__("Hover Color Opacity", 'santos-core'),
							"param_name" => "hover_opacity",
							"value" => 0.9,
							"min" => 0.0,
							"max" => 1.0,
							"step" => 0.1,
							"suffix" => "",
							'std' => '0.9',
							"dependency" => Array('element' => "hover_color_style", 'value' => array('theme_color')),
						),
						
						array(
						"type" => "colorpicker",
						"class" => "",
						"heading" => esc_html__("Hover Custom Color", 'santos-core'),
						"param_name" => "hover_custom_color",
						"value" => "",
						"description" => "",
						"dependency" => Array('element' => "hover_color_style", 'value' => array('custom_color')),
						),
						
						
						array(
						"type" => "dropdown",
						"class" => "pagination_style",
						"heading" => esc_html__("Pagination", 'santos-core'),
						"param_name" => "pagination",
						"value" => array(
								esc_html__("None", 'santos-core') => "",
								esc_html__("Load More", 'santos-core') => "load_more"

							),
						"std" => "",
						),
						
						array(
						"type" => "colorpicker",
						"class" => "",
						"heading" => esc_html__("Filter Background Color", 'santos-core'),
						"param_name" => "filter_bg_color",
						"value" => "",
						"description" => "",
						"group" => "Filter Style",
						'dependency' => array(
						'element' => 'enable_filter',
						'not_empty' => true,
						),
						),
						
						


		)
));




// Santos Portfolio Carousel
class WPBakeryShortCode_santos_portfolio_carousel extends WPBakeryShortCode{}
vc_map( array(
		"name" => "Portfolio Carousel",
		"base" => "santos_portfolio_carousel",
		"category" => 'Santos '. esc_html__('Elements', 'santos-core'),
		"icon" => "santos_portfolio",
	   "description" => esc_html__('Display portfolio item as carousel', 'santos-core'),
		"allowed_container_element" => 'vc_row',
		"params" => array(
						array(
							"heading" => esc_html__("Order", 'santos-core'),
							"description" => esc_html__("Designates the ascending or descending order of the 'orderby' parameter.", 'santos-core'),
							"param_name" => "order",
							"value" => array(
								esc_html__("DESC (descending order)", 'santos-core') => "DESC",
								esc_html__("ASC (ascending order)", 'santos-core') => "ASC"

							),
							'admin_label' => true,
							"type" => "dropdown"
						),
						array(
							"heading" => esc_html__("Orderby", 'santos-core'),
							"description" => esc_html__("Sort retrieved Portfolio items by parameter.", 'santos-core'),
							"param_name" => "orderby",
							"value" => array(
								esc_html__("Date", 'santos-core') => "date",
								esc_html__('Menu Order', 'santos-core') => 'menu_order',
								esc_html__("post id", 'santos-core') => "id",
								esc_html__("title", 'santos-core') => "title",
								esc_html__("Comment Count", 'santos-core') => "comment_count",
								esc_html__("Random", 'santos-core') => "rand",
								esc_html__("Author", 'santos-core') => "author",
								esc_html__("No order", 'santos-core') => "none"
							),
							'admin_label' => true,
							"type" => "dropdown"
						),
					 array(
						  "type" => "textfield",
						  "heading" => esc_html__("How many Posts?", 'santos-core'),
						  "param_name" => "items_per_page",
						  "description" => esc_html__("How many Posts would you like to show? (-1 means unlimited)", 'santos-core')
						),


		)
));


// Santos Team 
class WPBakeryShortCode_santos_team extends WPBakeryShortCode{}
vc_map( array(
  "name" => esc_html__("Team", 'santos-core'),
  "base" => "santos_team",
    "icon"		=> "santos_team",
	"class"	   => "santos_team",
	"category" => 'Santos '. esc_html__('Elements', 'santos-core'),
  "description" => esc_html__('Display Team Member Item', 'santos-core'),
  "params" => array(

			array(
				"type" => "attach_image",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Image",  'santos-core'),
				"param_name" => "image"
			),

			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Name",  'santos-core'),
				"param_name" => "name",
				'admin_label' => true,
			),
			array(
				"type" => "colorpicker",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Name Color", 'santos-core'),
				"param_name" => "name_color",
				"description" => "",
				 'std' => '',
			),
			
            array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Position",  'santos-core'),
				"param_name" => "position",
				'admin_label' => true,
			),
			
			array(
				"type" => "colorpicker",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Position Color", 'santos-core'),
				"param_name" => "position_color",
				"description" => "",
				 'std' => '',
			),
		
						
			array(
				"type" => "dropdown",
				"class" => "",
				"heading" => esc_html__("Social Icon 1", 'santos-core'),
				"param_name" => "team_social_icon_1",
				"value" =>$social_icons_array,
				'admin_label' => true,
			),
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Social Icon 1 Link", 'santos-core'),
				"param_name" => "team_social_icon_1_link"
			),
			array(
                "type" => "dropdown",
                "holder" => "div",
                "class" => "",
                "heading" => esc_html__("Social Icon 1 Target", 'santos-core'),
                "param_name" => "team_social_icon_1_target",
                "value" => array(
                    "Blank" => "_blank",
                    "Self" => "_self",
                    "Parent" => "_parent"
                ),
                "description" => ""
            ),
			array(
				"type" => "dropdown",
				"class" => "",
				"heading" => esc_html__("Social Icon 2", 'santos-core'),
				"param_name" => "team_social_icon_2",
				"value" =>$social_icons_array,
				'admin_label' => true,
			),
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Social Icon 2 Link", 'santos-core'),
				"param_name" => "team_social_icon_2_link"
			),
			array(
                "type" => "dropdown",
                "holder" => "div",
                "class" => "",
                "heading" => esc_html__("Social Icon 2 Target", 'santos-core'),
                "param_name" => "team_social_icon_2_target",
                "value" => array(
                    "Blank" => "_blank",
                    "Self" => "_self",
                    "Parent" => "_parent"
                ),
                "description" => ""
            ),
			array(
				"type" => "dropdown",
				"class" => "",
				"heading" => esc_html__("Social Icon 3", 'santos-core'),
				"param_name" => "team_social_icon_3",
				"value" =>$social_icons_array,
				'admin_label' => true,
			),
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Social Icon 3 Link", 'santos-core'),
				"param_name" => "team_social_icon_3_link"
			),
			array(
                "type" => "dropdown",
                "holder" => "div",
                "class" => "",
                "heading" => esc_html__("Social Icon 3 Target", 'santos-core'),
                "param_name" => "team_social_icon_3_target",
                "value" => array(
                    "Blank" => "_blank",
                    "Self" => "_self",
                    "Parent" => "_parent"
                ),
                "description" => ""
            ),
			array(
				"type" => "dropdown",
				"class" => "",
				"heading" => esc_html__("Social Icon 4", 'santos-core'),
				"param_name" => "team_social_icon_4",
				"value" =>$social_icons_array,
				'admin_label' => true,
			),
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Social Icon 4 Link", 'santos-core'),
				"param_name" => "team_social_icon_4_link"
			),
			array(
                "type" => "dropdown",
                "holder" => "div",
                "class" => "",
                "heading" => esc_html__("Social Icon 4 Target", 'santos-core'),
                "param_name" => "team_social_icon_4_target",
                "value" => array(
                    "Blank" => "_blank",
                    "Self" => "_self",
                    "Parent" => "_parent"
                ),
                "description" => ""
            ),
			array(
				"type" => "dropdown",
				"class" => "",
				"heading" => esc_html__("Social Icon 5", 'santos-core'),
				"param_name" => "team_social_icon_5",
				"value" =>$social_icons_array,
				'admin_label' => true,
			),
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Social Icon 5 Link", 'santos-core'), 
				"param_name" => "team_social_icon_5_link"
			),
			array(
                "type" => "dropdown",
                "holder" => "div",
                "class" => "",
                "heading" => esc_html__("Social Icon 5 Target", 'santos-core'),
                "param_name" => "team_social_icon_5_target",
                "value" => array(
                    "Blank" => "_blank",
                    "Self" => "_self",
                    "Parent" => "_parent"
                ),
                "description" => ""
            ),
			
			array(
				"type" => "colorpicker",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Social Icon Color", 'santos-core'),
				"param_name" => "icon_color",
				"description" => "",
				'std' => '#FFF',
			),
			array(  
				"type" => "dropdown", 
				"heading" => esc_html__("CSS Animation", "santos-core"),
				"param_name" => "animation",
				"admin_label" => true, 
				"value" => $css_animation_arr, 
				"description" => esc_html__("Select animation type if you want this element to be animated when it enters into the browsers viewport. Note: Works only in modern browsers.", 'santos-core')
			),

						
			array(
				'type' => 'textfield',
				'heading' => __( 'Extra class name', 'santos-core' ),
				'param_name' => 'el_class',
				'description' => __( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'santos-core' ),
			),			

  )
));





/* --------------------------------------------------------------------------------*/
/* Team Carousel
/*--------------------------------------------------------------------------------*/

class WPBakeryShortCode_santos_team_carousel  extends WPBakeryShortCodesContainer {}
vc_map( array(
    "name" => "Team Carousel",
    "base" => "santos_team_carousel",
    "as_parent" => array('only' => 'santos_team_carousel_item'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
    "content_element" => true,
    "category" => 'Santos '. esc_html__('Elements', 'santos-core'),
    "icon" => "santos_team_carousel",
	"description" => esc_html__('Display Team Member items', 'santos-core'),
    "show_settings_on_create" => false,
    "params" => array(
			
		array(
		'type' => 'textfield',
		'heading' => esc_html__( 'Extra class name', 'santos-core' ),
		'param_name' => 'el_class',
		'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'santos-core' )
		)

    ),
    "js_view" => 'VcColumnView'
) );

class WPBakeryShortCode_santos_team_carousel_item  extends WPBakeryShortCode {}
// screenshot slide shortcode
vc_map( array(
		"name" => "Team Item",
		"base" => "santos_team_carousel_item",
		"icon" => "santos_team_carousel_item",
		"category" => 'Santos '. esc_html__('Elements', 'santos-core'),
		"allowed_container_element" => 'vc_row',
        "as_child" => array('only' => 'santos_team_carousel'), // Use only|except attributes to limit parent (separate multiple values with comma)
		"params" => array(
			array(
				"type" => "attach_image",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Image",  'santos-core'),
				"param_name" => "image"
			),

			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Name",  'santos-core'),
				"param_name" => "name",
				'admin_label' => true,
			),
			array(
				"type" => "colorpicker",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Name Color", 'santos-core'),
				"param_name" => "name_color",
				"description" => "",
				 'std' => '',
			),
			
            array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Position",  'santos-core'),
				"param_name" => "position",
				'admin_label' => true,
			),
			
			array(
				"type" => "colorpicker",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Position Color", 'santos-core'),
				"param_name" => "position_color",
				"description" => "",
				 'std' => '',
			),
		
						
			array(
				"type" => "dropdown",
				"class" => "",
				"heading" => esc_html__("Social Icon 1", 'santos-core'),
				"param_name" => "team_social_icon_1",
				"value" =>$social_icons_array,
				'admin_label' => true,
			),
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Social Icon 1 Link", 'santos-core'),
				"param_name" => "team_social_icon_1_link"
			),
			array(
                "type" => "dropdown",
                "holder" => "div",
                "class" => "",
                "heading" => esc_html__("Social Icon 1 Target", 'santos-core'),
                "param_name" => "team_social_icon_1_target",
                "value" => array(
                    "Blank" => "_blank",
                    "Self" => "_self",
                    "Parent" => "_parent"
                ),
                "description" => ""
            ),
			array(
				"type" => "dropdown",
				"class" => "",
				"heading" => esc_html__("Social Icon 2", 'santos-core'),
				"param_name" => "team_social_icon_2",
				"value" =>$social_icons_array,
				'admin_label' => true,
			),
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Social Icon 2 Link", 'santos-core'),
				"param_name" => "team_social_icon_2_link"
			),
			array(
                "type" => "dropdown",
                "holder" => "div",
                "class" => "",
                "heading" => esc_html__("Social Icon 2 Target", 'santos-core'),
                "param_name" => "team_social_icon_2_target",
                "value" => array(
                    "Blank" => "_blank",
                    "Self" => "_self",
                    "Parent" => "_parent"
                ),
                "description" => ""
            ),
			array(
				"type" => "dropdown",
				"class" => "",
				"heading" => esc_html__("Social Icon 3", 'santos-core'),
				"param_name" => "team_social_icon_3",
				"value" =>$social_icons_array,
				'admin_label' => true,
			),
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Social Icon 3 Link", 'santos-core'),
				"param_name" => "team_social_icon_3_link"
			),
			array(
                "type" => "dropdown",
                "holder" => "div",
                "class" => "",
                "heading" => esc_html__("Social Icon 3 Target", 'santos-core'),
                "param_name" => "team_social_icon_3_target",
                "value" => array(
                    "Blank" => "_blank",
                    "Self" => "_self",
                    "Parent" => "_parent"
                ),
                "description" => ""
            ),
			array(
				"type" => "dropdown",
				"class" => "",
				"heading" => esc_html__("Social Icon 4", 'santos-core'),
				"param_name" => "team_social_icon_4",
				"value" =>$social_icons_array,
				'admin_label' => true,
			),
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Social Icon 4 Link", 'santos-core'),
				"param_name" => "team_social_icon_4_link"
			),
			array(
                "type" => "dropdown",
                "holder" => "div",
                "class" => "",
                "heading" => esc_html__("Social Icon 4 Target", 'santos-core'),
                "param_name" => "team_social_icon_4_target",
                "value" => array(
                    "Blank" => "_blank",
                    "Self" => "_self",
                    "Parent" => "_parent"
                ),
                "description" => ""
            ),
			array(
				"type" => "dropdown",
				"class" => "",
				"heading" => esc_html__("Social Icon 5", 'santos-core'),
				"param_name" => "team_social_icon_5",
				"value" =>$social_icons_array,
				'admin_label' => true,
			),
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Social Icon 5 Link", 'santos-core'), 
				"param_name" => "team_social_icon_5_link"
			),
			array(
                "type" => "dropdown",
                "holder" => "div",
                "class" => "",
                "heading" => esc_html__("Social Icon 5 Target", 'santos-core'),
                "param_name" => "team_social_icon_5_target",
                "value" => array(
                    "Blank" => "_blank",
                    "Self" => "_self",
                    "Parent" => "_parent"
                ),
                "description" => ""
            ),
			
			array(
				"type" => "colorpicker",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Social Icon Color", 'santos-core'),
				"param_name" => "icon_color",
				"description" => "",
				'std' => '#FFF',
			),
			

		)
) );


/* --------------------------------------------------------------------------------*/
/* Santos Progress Bar
/*--------------------------------------------------------------------------------*/
class WPBakeryShortCode_santos_progress_bar extends WPBakeryShortCode{}
vc_map( array(
'name' => esc_html__( 'Progress Bar', 'santos-core' ),
'base' => 'santos_progress_bar',
'icon' => 'santos_progress_bar',
"category" => 'Santos '. esc_html__('Elements', 'santos-core'),
'description' => esc_html__( 'Animated progress bar', 'santos-core' ),
'params' => array(

	array(
	'type' => 'exploded_textarea',
	'heading' => esc_html__( 'Graphic values', 'santos-core' ),
	'param_name' => 'values',
	'description' => esc_html__( 'Input graph values, titles and color here. Divide values with linebreaks (Enter). Example: 90|Development|#e75956', 'santos-core' ),
	'value' => "90|Development,80|Design,70|Marketing"
	),
	array(
	'type' => 'colorpicker',
	'heading' => esc_html__( 'Title color', 'santos-core' ),
	'param_name' => 'title_color',
	'description' => esc_html__( 'Select custom color for Titles & Unit .', 'santos-core' ),
	'value' => '#444',
	),
	array(
	'type' => 'textfield',
	'heading' => esc_html__( 'Units', 'santos-core' ),
	'param_name' => 'units',
	'description' => esc_html__( 'Enter measurement units (if needed) Eg. %, px, points, etc. Graph value and unit will be appended to the graph title.', 'santos-core' )
	),

	array(
	'type' => 'colorpicker',
	'heading' => esc_html__( 'Bar color', 'santos-core' ),
	'param_name' => 'bar_color',
	'description' => esc_html__( 'Select color for bars.', 'santos-core' ),
	'value' => '#333',
	),
	array(
	'type' => 'textfield',
	'heading' => esc_html__( 'Extra class name', 'santos-core' ),
	'param_name' => 'el_class',
	'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'santos-core' )
	)
)
) );




// Santos Blog 
class WPBakeryShortCode_santos_recent_posts extends WPBakeryShortCode{}
vc_map( array(
		"name" => "Recent Posts",
		"base" => "santos_recent_posts",
		"category" => 'Santos '. esc_html__('Elements', 'santos-core'),
		"icon" => "santos_blog",
		"description" => esc_html__('Display blog posts', 'santos-core'),
		"allowed_container_element" => 'vc_row',
		"params" => array(

						array(
							"heading" => esc_html__("Order", 'santos-core'),
							"description" => esc_html__("Designates the ascending or descending order of the 'orderby' parameter.", 'santos-core'),
							"param_name" => "order",
							"value" => array(
								esc_html__("DESC (descending order)", 'santos-core') => "DESC",
								esc_html__("ASC (ascending order)", 'santos-core') => "ASC"

							),
							'admin_label' => true,
							"type" => "dropdown"
						),
						array(
							"heading" => esc_html__("Orderby", 'santos-core'),
							"description" => esc_html__("Sort retrieved Posts items by parameter.", 'santos-core'),
							"param_name" => "orderby",
							"value" => array(
								esc_html__("Date", 'santos-core') => "date",
								esc_html__('Menu Order', 'santos-core') => 'menu_order',
								esc_html__("post id", 'santos-core') => "id",
								esc_html__("title", 'santos-core') => "title",
								esc_html__("Comment Count", 'santos-core') => "comment_count",
								esc_html__("Random", 'santos-core') => "rand",
								esc_html__("Author", 'santos-core') => "author",
								esc_html__("No order", 'santos-core') => "none"
							),
							'admin_label' => true,
							"type" => "dropdown"
						),
					 array(
						  "type" => "textfield",
						  "heading" => esc_html__("How many Posts?", 'santos-core'),
						  "param_name" => "items_per_page",
						  "description" => esc_html__("How many Posts would you like to show? (-1 means unlimited)", 'santos-core')
						),
						
						array(
						"type" => "textfield",
						"heading" => esc_html__("Text length", 'santos-core'),
						"param_name" => "post_excerpt_length",
						"description" => esc_html__("Number of words to display", 'santos-core')
						),
						
						array(
							"type" => "santos_toggle",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("ignore Post Format",  'santos-core'),
							"param_name" => "ignore_post_format",
							'admin_label' => true,
						),
						
					array(
						"type" => "colorpicker",
						"holder" => "div",
						"class" => "",
						"heading" => esc_html__("Content Background", 'santos-core'),
						"param_name" => "content_bg",
						'std' => '',
						"description" => "",
						),
						


		)
));


// Santos Milestone 
class WPBakeryShortCode_santos_milestone extends WPBakeryShortCode{}
vc_map( array(
		"name" => "Milestone",
		"base" => "santos_milestone",
		"category" => 'Santos '. esc_html__('Elements', 'santos-core'),
		"icon" => "santos_milestone",
	  "description" => esc_html__('Add animated milestone', 'santos-core'),
		"allowed_container_element" => 'vc_row',
		"params" => array(
	
					array(
						  "type" => "textfield",
						  "heading" => esc_html__("Section Number", 'santos-core'),
						  "param_name" => "number",
						),
						
					array(
						"type" => "colorpicker",
						"holder" => "div",
						"class" => "",
						"heading" => esc_html__("Number Color", 'santos-core'),
						"param_name" => "number_color",
						"description" => "",
						),
					array(
							"type" => "santos_number",
							"class" => "",
							"heading" => esc_html__("Number Size", 'santos-core'),
							"param_name" => "number_size",
							"value" => 0,
							"min" => 10,
							"max" => 300,
							"suffix" => "px",
							 'std' => '40',
						),

					 array(
						  "type" => "textfield",
						  "heading" => esc_html__("Title", 'santos-core'),
						  "param_name" => "title",
						),
		
						array(
						"type" => "colorpicker",
						"holder" => "div",
						"class" => "",
						"heading" => esc_html__("Title Color", 'santos-core'),
						"param_name" => "title_color",
						"description" => "",
						),
						
						array(
						'type' => 'textarea',
						'heading' => esc_html__( 'Description',  'santos-core' ),
						'param_name' => 'content',
						'admin_label' => false
						),
						
						array(
						"type" => "colorpicker",
						"holder" => "div",
						"class" => "",
						"heading" => esc_html__("Description Color", 'santos-core'),
						"param_name" => "text_color",
						"description" => "",
						),
						
						array(
						"type" => "dropdown",
						"holder" => "div",
						"class" => "",
						"heading" => esc_html__("Align", 'santos-core'),
						"param_name" => "align",
						"value" => array(
							"Center" => "center",
							"Left" => "left",
							"Right" => "right"
						),
						"description" => ""
					),
			


		)
));

// Santos section number 
class WPBakeryShortCode_santos_step_box extends WPBakeryShortCode{}
vc_map( array(
		"name" => "Step Box",
		"base" => "santos_step_box",
		"category" => 'Santos '. esc_html__('Elements', 'santos-core'),
		"icon" => "santos_step_box",
		"description" => esc_html__('Add stylish steps information', 'santos-core'),
		"allowed_container_element" => 'vc_row',
		"params" => array(
						array(
						  "type" => "textfield",
						  "heading" => esc_html__("Step Number", 'santos-core'),
						  "param_name" => "number",
						),
					 array(
						  "type" => "textfield",
						  "heading" => esc_html__("Step Title", 'santos-core'),
						  "param_name" => "title",
						),
						
						array(
						'type' => 'textarea',
						'heading' => esc_html__( 'Description',  'santos-core' ),
						'param_name' => 'content',
						'admin_label' => false
						),
						
						array(
						"type" => "colorpicker",
						"holder" => "div",
						"class" => "",
						"heading" => esc_html__("Text Color", 'santos-core'),
						"param_name" => "text_color",
						"description" => "",
						),
						
	  					array(
							"type" => "santos_toggle",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("Enable Background Image",  'santos-core'),
							"param_name" => "enable_bg"
						),
						array(
							"type" => "attach_image",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("Background Image",  'santos-core'),
							"param_name" => "image"
						),


		)
));



// Santos Signature 
class WPBakeryShortCode_santos_signature extends WPBakeryShortCode{}
vc_map( array(
		"name" => "Signature",
		"base" => "santos_signature",
		"category" => 'Santos '. esc_html__('Elements', 'santos-core'),
		"icon" => "santos_signature",
		"allowed_container_element" => 'vc_row',
		"description" => esc_html__('Add signature image', 'santos-core'),
		"params" => array(
		
						array(
							"type" => "attach_image",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("Image",  'santos-core'),
							"param_name" => "image"
						),

					 array(
						  "type" => "santos_number",
						  "heading" => esc_html__("Image width", 'santos-core'),
						  "param_name" => "width",
						  "description" => esc_html__("Just right a Number (ex: 150) , Image Height will be auto according to width", 'santos-core')
						),
						
					array(
						"type" => "dropdown",
						"holder" => "div",
						"class" => "",
						"heading" => esc_html__("Signature Align", 'santos-core'),
						"param_name" => "align",
						"value" => array(
							"" => "",
							"Left" => "left",
							"Center" => "center",
							"Right" => "right"
						),
						"description" => ""
					),
						



		)
));



// Santos Lightbox Video
class WPBakeryShortCode_santos_lightbox_video extends WPBakeryShortCode{}
vc_map( array(
		"name" => "Lightbox Video",
		"base" => "santos_lightbox_video",
		"category" => 'Santos '. esc_html__('Elements', 'santos-core'),
		"icon" => "santos_lightbox_video",
		"allowed_container_element" => 'vc_row',
		"description" => esc_html__('Display video in lightbox', 'santos-core'),
		"params" => array(

					 array(
						  "type" => "textfield",
						  "heading" => esc_html__("Video URL", 'santos-core'),
						  "param_name" => "url",
						  "description" => esc_html__("YouTube video URL", 'santos-core')
						),
						
						
						array(
						"type" => "dropdown",
						"holder" => "div",
						"class" => "",
						"heading" => esc_html__("Style", 'santos-core'),
						"param_name" => "style",
						"value" => array(
							"Button" => "btn",
							"Image Box" => "img",
						),
						"description" => ""
					),
					
					 array(
						  "type" => "textfield",
						  "heading" => esc_html__("Title", 'santos-core'),
						  "param_name" => "title",
						  "dependency" => Array('element' => "style", 'value' => array('btn')),
						),
						
						array(
							"type" => "attach_image",
							"holder" => "div",
							"class" => "",
							"heading" => esc_html__("Image",  'santos-core'),
							"param_name" => "image",
							"dependency" => Array('element' => "style", 'value' => array('img')),
						),
						

		)
));


// Santos Contact us 
class WPBakeryShortCode_santos_contact_info extends WPBakeryShortCode{}
vc_map( array(
		"name" => "Contact Info",
		"base" => "santos_contact_info",
		"category" => 'Santos '. esc_html__('Elements', 'santos-core'),
		"icon" => "santos_contact_info",
		"description" => esc_html__('Display contact information', 'santos-core'),
		"allowed_container_element" => 'vc_row',
		"params" => array(

					 array(
						  "type" => "textfield",
						  "heading" => esc_html__("Address", 'santos-core'),
						  "param_name" => "address",
						),
						
						array(
						  "type" => "textfield",
						  "heading" => esc_html__("Phone", 'santos-core'),
						  "param_name" => "phone",
						),
						
						array(
						  "type" => "textfield",
						  "heading" => esc_html__("Fax", 'santos-core'),
						  "param_name" => "fax",
						),
						
						array(
						  "type" => "textfield",
						  "heading" => esc_html__("Email", 'santos-core'),
						  "param_name" => "email",
						),


		)
));



// Santos Contact Form 
class WPBakeryShortCode_santos_contact_form extends WPBakeryShortCode{}
vc_map( array(
		"name" => "Contact Form",
		"base" => "santos_contact_form",
		"category" => 'Santos '. esc_html__('Elements', 'santos-core'),
		"icon" => "santos_contact_form",
		  "description" => esc_html__('Add simple contact form', 'santos-core'),
		"allowed_container_element" => 'vc_row',
		"params" => array(

					 array(
						  "type" => "textfield",
						  "heading" => esc_html__("Name Label", 'santos-core'),
						  "param_name" => "name_label",
						  'std' => 'First Name',
						),
						
						array(
						  "type" => "textfield",
						  "heading" => esc_html__("Email Label", 'santos-core'),
						  "param_name" => "email_label",
						  'std' => 'Email',
						),
						
						array(
						  "type" => "textfield",
						  "heading" => esc_html__("Subject Label", 'santos-core'),
						  "param_name" => "subject_label",
						  'std' => 'subject',
						),
						
						array(
						  "type" => "textfield",
						  "heading" => esc_html__("Message Label", 'santos-core'),
						  "param_name" => "message_label",
						  'std' => 'Message',
						),
						
						array(
						"type" => "colorpicker",
						"holder" => "div",
						"class" => "",
						"heading" => esc_html__("Text Color", 'santos-core'),
						"param_name" => "text_color",
						"description" => "",
						 'std' => '#fff',
						),
						
						array(
						  "type" => "textfield",
						  "heading" => esc_html__("Submit Label", 'santos-core'),
						  "param_name" => "submit_label",
						  'std' => 'Send',
						),
												 
						array(
						"type" => "colorpicker",
						"holder" => "div",
						"class" => "",
						"heading" => esc_html__("Button Text Color", 'santos-core'),
						"param_name" => "btn_text_color",
						"description" => "",
						 'std' => '',
						),
						
						array(
						"type" => "colorpicker",
						"holder" => "div",
						"class" => "",
						"heading" => esc_html__("Button Background Color", 'santos-core'),
						"param_name" => "btn_bg_color",
						"description" => "",
						 'std' => '',
						),
						
						array(
						'type' => 'santos_toggle',
						'heading' => esc_html__( 'Animate Place Holder in active state', 'santos-core' ),
						'param_name' => 'placeholder_animate',
						),
						array(
						"type" => "colorpicker",
						"holder" => "div",
						"class" => "",
						"heading" => esc_html__("Animate Placeholder Text Color", 'santos-core'),
						"param_name" => "placeholder_animate_color",
						"description" => "",
						 'std' => '',
						),
						array(
						"type" => "colorpicker",
						"holder" => "div",
						"class" => "",
						"heading" => esc_html__("Animate Placeholder Background Color", 'santos-core'),
						"param_name" => "placeholder_animate_bg",
						"description" => "",
						 'std' => '#fff',
						),
						


		)
));


// Santos Down Count 
class WPBakeryShortCode_santos_down_count extends WPBakeryShortCode{}
vc_map( array(
		"name" => "Down Count",
		"base" => "santos_down_count",
		"category" => 'Santos '. esc_html__('Elements', 'santos-core'),
		"icon" => "santos_down_count",
		"description" => esc_html__('Display Down Count Timer', 'santos-core'),
		"allowed_container_element" => 'vc_row',
		"params" => array(
					 array(
						  "type" => "textfield",
						  "heading" => esc_html__("Day", 'santos-core'),
						  "param_name" => "day",
						  "description" => esc_html__("Example: 05", 'santos-core')
						),
						
						array(
						  "type" => "textfield",
						  "heading" => esc_html__("Month", 'santos-core'),
						  "param_name" => "month",
						  "description" => esc_html__("Example: 10", 'santos-core')
						),
						
						array(
						  "type" => "textfield",
						  "heading" => esc_html__("Year", 'santos-core'),
						  "param_name" => "year",
						  "description" => esc_html__("Example: 2017", 'santos-core')
						),
						
						
						array(
						"type" => "colorpicker",
						"heading" => esc_html__("Count Color", 'santos-core'),
						"param_name" => "count_color",
						'std' => '#FFF',
						),
						
						array(
							"type" => "santos_number",
							"class" => "",
							"heading" => esc_html__("Count Size", 'santos-core'),
							"param_name" => "count_size",
							"value" => 0,
							"min" => 20,
							"max" => 300,
							"suffix" => "px",
							 'std' => '65',
						),

		)
));



/* Fancy Text
---------------------------------------------------------- */
class WPBakeryShortCode_santos_fancy_text extends WPBakeryShortCode{}
vc_map(
array(
"name" => esc_html__("Fancy Text", 'santos-core'),
"base" => "santos_fancy_text",
"class" => "vc_santos-core_fancytext",
"icon" => "santos_fancytext",
"category" => 'Santos '. esc_html__('Elements', 'santos-core'),
"description" => esc_html__("Fancy lines with animation effects.", 'santos-core'),
"params" => array(
	array(
	"type" => "textfield",
	"param_name" => "fancytext_prefix",
	"heading" => esc_html__("Prefix", 'santos-core'),
	"value" => "",
	),
	
	array(
	"type" => "colorpicker",
	"heading" => esc_html__("Prefix Text Color", 'santos-core'),
	"param_name" => "prefixtext_color",
	),
	
	array(
	'type' => 'textarea',
	'heading' => esc_html__( 'Fancy Text',  'santos-core' ),
	'param_name' => 'fancytext_strings',
	'description' => esc_html__('Enter each string on a new line', 'santos-core'),
	'admin_label' => true
	),
	
	array(
	"type" => "colorpicker",
	"heading" => esc_html__("Fancy Text Color", 'santos-core'),
	"param_name" => "fancytext_color",
	),

	
	array(
	"type" => "dropdown",
	"heading" => esc_html__("Alignment",  'santos-core'),
	"param_name" => "fancytext_align",
	"value" => array(
		esc_html__("Center", 'santos-core') => "center",
		esc_html__("Left", 'santos-core') => "left",
		esc_html__("Right", 'santos-core') => "right"
		)
	),
	
	

	array(
	"type" => "dropdown",
	"heading" => esc_html__("Markup", 'santos-core'),
	"param_name" => "fancytext_tag",
	"value" => array(
		esc_html__("H1", 'santos-core') => "h1",
		esc_html__("H2", 'santos-core') => "h2",
		esc_html__("H3", 'santos-core') => "h3",
		esc_html__("H4", 'santos-core') => "h4",
		esc_html__("H5", 'santos-core') => "h5",
		esc_html__("H6", 'santos-core') => "h6",
		),
	),
	
	array(
		"type" => "santos_number",
		"class" => "",
		"heading" => esc_html__("Text Size", 'santos-core'),
		"param_name" => "text_size",
		"value" => 0,
		"min" => 30,
		"max" => 300,
		"suffix" => "px",
		'std' => '',
	),	
	
	array(
	"type" => "textfield",
	"heading" => esc_html__("Extra Class", 'santos-core'),
	"param_name" => "ex_class"
	),


)
)
);





/* --------------------------------------------------------------------------------*/
/* Testimonial Box
/*--------------------------------------------------------------------------------*/
class WPBakeryShortCode_santos_testimonial_box  extends WPBakeryShortCode {}
// screenshot slide shortcode
vc_map( array(
		"name" => "Testimonial Box",
		"base" => "santos_testimonial_box",
		"icon" => "santos_testimonial_box",
		"category" => 'Santos '. esc_html__('Elements', 'santos-core'),
		 "description" => esc_html__('Display Testimonial in a box', 'santos-core'),
		"allowed_container_element" => 'vc_row',
		"params" => array(
		
		array(
				"type" => "colorpicker",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Background Color", 'santos-core'),
				"param_name" => "bg_color",
				"description" => "",
				'std' => '#eee',
			),
			
		array(
			"type" => "textarea",
			"holder" => "div",
			"class" => "",
			"heading" => esc_html__("Quote", 'santos-core'),
			"param_name" => "quote",
			"description" => ""
		),
		
		array(
				"type" => "colorpicker",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Quote Color", 'santos-core'),
				"param_name" => "quote_color",
				"description" => "",
				 'std' => '',
			),
			
		array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Name",  'santos-core'),
				"param_name" => "name",
				'admin_label' => true,
			),
			array(
				"type" => "colorpicker",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Name Color", 'santos-core'),
				"param_name" => "name_color",
				"description" => "",
				'std' => '',
			),
			
            array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Position",  'santos-core'),
				"param_name" => "position",
				'admin_label' => true,
			),
			
			array(
				"type" => "colorpicker",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Position Color", 'santos-core'),
				"param_name" => "position_color",
				"description" => "",
				'std' => '',
			),
			
			array(
				"type" => "attach_image",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Image",  'santos-core'),
				"param_name" => "image"
			),			
			

		)
) );
				
/* --------------------------------------------------------------------------------*/
/* Testimonial Carousel
/*--------------------------------------------------------------------------------*/

class WPBakeryShortCode_santos_testimonial_carousel  extends WPBakeryShortCodesContainer {}
vc_map( array(
    "name" => "Testimonial Carousel",
    "base" => "santos_testimonial_carousel",
    "as_parent" => array('only' => 'santos_testimonial_carousel_item'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
    "content_element" => true,
    "category" => 'Santos '. esc_html__('Elements', 'santos-core'),
    "icon" => "santos_testimonial_carousel",
	"description" => esc_html__('Display testimonial Item as carousel', 'santos-core'),
    "show_settings_on_create" => false,
    "params" => array(
	
					array(
						"type" => "dropdown",
						"holder" => "div",
						"class" => "",
						"heading" => esc_html__("Carousel Align", 'santos-core'),
						"param_name" => "align",
						"value" => array(
							"" => "",
							"Left" => "left",
							"Center" => "center",
							"Right" => "right"
						),
						"description" => ""
					),	
		array(
				"type" => "colorpicker",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Pagination Color", 'santos-core'),
				"param_name" => "pagination_color",
				"description" => "",
				'std' => '',
		),
		
		array(
		'type' => 'textfield',
		'heading' => esc_html__( 'Extra class name', 'santos-core' ),
		'param_name' => 'el_class',
		'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'santos-core' )
		)

    ),
    "js_view" => 'VcColumnView'
) );

class WPBakeryShortCode_santos_testimonial_carousel_item  extends WPBakeryShortCode {}
// screenshot slide shortcode
vc_map( array(
		"name" => "Testimonial Item",
		"base" => "santos_testimonial_carousel_item",
		"icon" => "santos_testimonial_carousel_item",
		"category" => 'Santos '. esc_html__('Elements', 'santos-core'),
		"allowed_container_element" => 'vc_row',
        "as_child" => array('only' => 'santos_testimonial_carousel'), // Use only|except attributes to limit parent (separate multiple values with comma)
		"params" => array(
		array(
			"type" => "textarea",
			"holder" => "div",
			"class" => "",
			"heading" => esc_html__("Quote", 'santos-core'),
			"param_name" => "quote",
			"description" => ""
		),
		
		array(
				"type" => "colorpicker",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Quote Color", 'santos-core'),
				"param_name" => "quote_color",
				"description" => "",
				 'std' => '',
			),
		array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Name",  'santos-core'),
				"param_name" => "name",
				'admin_label' => true,
			),
			array(
				"type" => "colorpicker",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Name Color", 'santos-core'),
				"param_name" => "name_color",
				"description" => "",
				'std' => '',
			),
			
            array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Position",  'santos-core'),
				"param_name" => "position",
				'admin_label' => true,
			),
			
			array(
				"type" => "colorpicker",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Position Color", 'santos-core'),
				"param_name" => "position_color",
				"description" => "",
				'std' => '',
			),
			

		)
) );


	
/* --------------------------------------------------------------------------------*/
/* Hero Heading
/*--------------------------------------------------------------------------------*/
 class WPBakeryShortCode_santos_hero extends WPBakeryShortCodesContainer {}
	vc_map( 
		array(
			"icon" => 'santos_hero',
			"name" => esc_html__("Hero Header", 'santos-core'),
			"base" => "santos_hero",
			"category" => 'Santos '. esc_html__('Elements', 'santos-core'),
			"description" => esc_html__('Add hero banner to the top of your page', 'santos-core'),
			'as_parent'               => array('except' => 'vc_section'),
			'content_element'         => true,
			'show_settings_on_create' => true,
			"js_view" => 'VcColumnView',
			"params" => array(

				array(
					"type" => "attach_image",
					"heading" => esc_html__("Background Image", 'santos-core'),
					"param_name" => "image"
				),
				array(
					"type" => "dropdown",
					"heading" => __("Hero Height", 'santos-core'),
					"param_name" => "hero_height",
					"value" => array(
						'100vh' => '100',
						'90vh' => '90',
						'80vh' => '80',
						'70vh' => '70',
					)
				),
				array(
					'type' => 'colorpicker',
					'heading' => esc_html__( 'Overlay Color', 'santos-core' ),
					'param_name' => 'overlay_color',
				),

				array(
					"type" => "dropdown",
					"heading" => esc_html__("Use Parallax Scrolling on this element?", 'santos-core'),
					"param_name" => "parallax",
					"value" => array(
						'Parallax On' => 'parallax',
						'Parallax Off' => 'parallax-off'
					),
					
				),
				
			array(
			'type' => 'santos_toggle',
			'heading' => esc_html__( 'Enable Scroll Icon', 'santos-core' ),
			'param_name' => 'enable_scroll_icon',
			),
	  
	  
			array(
				'type' => 'textfield',
				'heading' => esc_html__( 'Scroll to Row ID', 'santos-core' ),
				'param_name' => 'scroll_row_id',
				'std' => '',
				'description' => esc_html__( 'Enter Target Row ID that will be used in Scroll Icon (Example : #about)', 'santos-core' ),
			),
				
			array(
			"type" => "textfield",
			"heading" => esc_html__("Extra class name", 'santos-core'),
			"param_name" => "el_class",
			"description" => esc_html__("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'santos-core')
			),

			)
		) 
	);
	
	
/* --------------------------------------------------------------------------------*/
/* Hero Slider
/*--------------------------------------------------------------------------------*/

class WPBakeryShortCode_santos_hero_slider  extends WPBakeryShortCodesContainer {}
vc_map( array(
    "name" => "Hero Slider",
    "base" => "santos_hero_slider",
    "as_parent" => array('only' => 'santos_hero_slide'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
    "content_element" => true,
    "category" => 'Santos '. esc_html__('Elements', 'santos-core'),
    "icon" => "santos_hero_slider",
	"description" => esc_html__('Add hero slider to the top of your page', 'santos-core'),
    "show_settings_on_create" => false,
    "params" => array(
	
		array(
			"type" => "dropdown",
			"heading" => esc_html__("Style", 'santos-core'),
			"param_name" => "style",
			"value" => array(
				'Style 1' => 'style_1',
				'Style 2' => 'style_2'
				),
					
		),
		
		array(
			"type" => "dropdown",
			"heading" => esc_html__("Use Parallax Scrolling on this element?", 'santos-core'),
			"param_name" => "parallax",
			"value" => array(
				'Parallax On' => 'parallax',
				'Parallax Off' => 'parallax-off'
				),
					
		),
			
		array(
			"type" => "colorpicker",
			"holder" => "div",
			"class" => "",
			"heading" => esc_html__("Background Color", 'santos-core'),
			"param_name" => "bg_color",
			"description" => "",
			 'std' => '#444',
			 'admin_label' => false,
		),
		array(
			"type" => "colorpicker",
			"holder" => "div",
			"class" => "",
			"heading" => esc_html__("Button Text Color", 'santos-core'),
			"param_name" => "btn_title_color",
			"description" => "",
			'std' => '',
			),

			array(
			"type" => "colorpicker",
			"holder" => "div",
			"class" => "",
			"heading" => esc_html__("Button Background Color", 'santos-core'),
			"param_name" => "btn_bg_color",
			"description" => "",
			'std' => '',
			),	
			
			 array(
					  "type" => "santos_number",
					  "heading" => esc_html__("Title and text Area width", 'santos-core'),
					  "param_name" => "text_width",
					  'std' => '600',
					  "description" => esc_html__("Just right a Number (ex: 600)", 'santos-core')
				),
						
		/*
		array(
			"type" => "colorpicker",
			"holder" => "div",
			"class" => "",
			"heading" => esc_html__("Pagination Color", 'santos-core'),
			"param_name" => "pagination_color",
			"description" => "",
			'std' => '#ddd',
			'admin_label' => false,
		),	
		*/

    ),
    "js_view" => 'VcColumnView'
) );

class WPBakeryShortCode_santos_hero_slide extends WPBakeryShortCode {}
// screenshot slide shortcode
vc_map( array(
		"name" => "Hero Slide",
		"base" => "santos_hero_slide",
		"icon" => "santos_hero_slide",
		"category" => 'Santos '. esc_html__('Elements', 'santos-core'),
		"allowed_container_element" => 'vc_row',
        "as_child" => array('only' => 'santos_hero_slider'), 
		"params" => array(
		
			array(
				"type" => "attach_image",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Slide Image",  'santos-core'),
				"param_name" => "image"
			),
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Title",  'santos-core'),
				"param_name" => "title",
				"description" => "First Line Title",
				'admin_label' => true,
			),
			array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Title",  'santos-core'),
				"param_name" => "title_2",
				"description" => "Second Line Title",
				'admin_label' => true,
			),
			array(
				"type" => "colorpicker",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Title Color", 'santos-core'),
				"param_name" => "title_color",
				"description" => "",
				 'std' => '#fff',
				 'admin_label' => false,
			),
								
			array(
			"type" => "textarea",
			"holder" => "div",
			"class" => "",
			"heading" => esc_html__("Description", 'santos-core'),
			"param_name" => "description",
			"description" => ""
		),
		array(
				"type" => "colorpicker",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Description Color", 'santos-core'),
				"param_name" => "description_color",
				"description" => "",
				 'std' => '#fff',
				 'admin_label' => false,
			),

		array(
			"type" => "santos_toggle",
			"holder" => "div",
			"class" => "",
			"heading" => esc_html__("Enable Button",  'santos-core'),
			"param_name" => "enable_button",
			'group' => esc_html__( 'Button', 'santos-core' ),
			"admin_label" => false, 
			),

			array(
			"type" => "textfield",
			"heading" => esc_html__("Button Title", 'santos-core'),
			"param_name" => "btn_title",
			'group' => esc_html__( 'Button', 'santos-core' ),
			'value' => esc_html__( 'Button Text', 'santos-core' ),
			),
			array(
			'type' => 'vc_link',
			'heading' => __( 'URL (Link)', 'santos-core' ),
			'param_name' => 'link',
			'group' => esc_html__( 'Button', 'santos-core' ),
			'description' => esc_html__( 'Add link to button.', 'santos-core' ),
			),
		

			
		array(
			"type" => "santos_toggle",
			"holder" => "div",
			"class" => "",
			"heading" => esc_html__("Enable Video Button",  'santos-core'),
			"param_name" => "enable_video",
			'group' => esc_html__( 'Video', 'santos-core' ),
			"admin_label" => false, 
			),

		array(
			"type" => "textfield",
			"heading" => esc_html__("Video URL", 'santos-core'),
			"param_name" => "video_url",
			"description" => esc_html__("YouTube video URL", 'santos-core'),
			'group' => esc_html__( 'Video', 'santos-core' ),
			"admin_label" => false,
			),
		array(
			"type" => "textfield",
			"heading" => esc_html__("Video Title", 'santos-core'),
			"param_name" => "video_title",
			'group' => esc_html__( 'Video', 'santos-core' ),
			"admin_label" => false,
			),		
			

			



		)
) );




	

/* Icon Tabs */
class WPBakeryShortCode_santos_icon_tabs  extends WPBakeryShortCodesContainer {}
vc_map( array(
		"name" => esc_html__("Icon Tabs", 'santos-core'),
		"base" => "santos_icon_tabs",
		"class" => "santos_icon_tabs",
		"icon" => "santos_icon_tabs",
		"category" => 'Santos '. esc_html__('Elements', 'santos-core'),
		"as_parent" => array('only' => 'santos_icon_tab'),
		"description" => esc_html__('Stylish Tabs with icons', 'santos-core'),		
		"content_element" => true,
		"show_settings_on_create" => false,
		"params" => array(

			array(
			"type" => "textfield",
			"heading" => esc_html__("Extra class name", 'santos-core'),
			"param_name" => "el_class",
			"description" => esc_html__("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'santos-core')
			),


		),
"js_view" => 'VcColumnView'
) );

class WPBakeryShortCode_santos_icon_tab extends WPBakeryShortCode {}

vc_map( array(
		"name" => esc_html__("Icon Tab", 'santos-core'),
		"base" => "santos_icon_tab",
		"class" => "santos_icon_tab",
		"icon" => "santos_icon_tab",
		"content_element" => true,
		"as_child" => array('only' => 'santos_icon_tabs'), 
		"params" => array(
		
		array( 
		'type' => 'santos_ion_icons',
		'heading' => esc_html__( 'Icon', 'santos-core' ),
		'param_name' => 'icon_ion',
		'value' => 'ion-ios-infinite-outline',
		'description' => esc_html__( 'Select icon from library.', 'santos-core' ),
		),
		
		array(
		"type" => "textfield",
		"heading" => esc_html__("Icon Subtitle", 'santos-core'),
		"param_name" => "icon_title",
		),

		array(
		"type" => "textfield",
		"heading" => esc_html__("Section Title", 'santos-core'),
		"param_name" => "tab_title",
		),

		array(
		"type" => "textarea",
		"heading" => esc_html__("Section Content", 'santos-core'),
		"param_name" => "content",
		),
		
		array(
			'type' => 'el_id',
			'param_name' => 'tab_id',
			'settings' => array(
				'auto_generate' => true,
			),
			'heading' => __( 'Tab ID', 'js_composer' ),
			'description' => __( 'Enter Tab ID (Note: make sure it is unique and valid according to <a href="%s" target="_blank">w3c specification</a>).', 'santos-core' ),
		),
	

)
) );



/* --------------------------------------------------------------------------------*/
/* Timeline Events
/*--------------------------------------------------------------------------------*/

class WPBakeryShortCode_santos_timeline_event  extends WPBakeryShortCodesContainer {}
vc_map( array(
    "name" => "Timeline Event",
    "base" => "santos_timeline_event",
    "as_parent" => array('only' => 'santos_timeline_event_item'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
    "content_element" => true,
    "category" => 'Santos '. esc_html__('Elements', 'santos-core'),
	"description" => esc_html__('Display events as timeline', 'santos-core'),
    "icon" => "santos_timeline_event",
    "show_settings_on_create" => false,
    "params" => array(
	
		array(
				"type" => "colorpicker",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Title Color", 'santos-core'),
				"param_name" => "title_color",
				"description" => "",
				'std' => '',
		),
		
		array(
				"type" => "colorpicker",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Subtitle Color", 'santos-core'),
				"param_name" => "subtitle_color",
				"description" => "",
				'std' => '',
		),
		
		array(
				"type" => "colorpicker",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Description Color", 'santos-core'),
				"param_name" => "description_color",
				"description" => "",
				'std' => '',
		),
			
		array(
		'type' => 'textfield',
		'heading' => esc_html__( 'Extra class name', 'santos-core' ),
		'param_name' => 'el_class',
		'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'santos-core' )
		)

    ),
    "js_view" => 'VcColumnView'
) );

class WPBakeryShortCode_santos_timeline_event_item  extends WPBakeryShortCode {}
// Timeline Item shortcode
vc_map( array(
		"name" => "Timeline Item",
		"base" => "santos_timeline_event_item",
		"icon" => "santos_timeline_event_item",
		"category" => 'Santos '. esc_html__('Elements', 'santos-core'),
		"allowed_container_element" => 'vc_row',
        "as_child" => array('only' => 'santos_timeline_event'), // Use only|except attributes to limit parent (separate multiple values with comma)
		"params" => array(
		array(
			"type" => "textfield",
			"holder" => "div",
			"class" => "",
			"heading" => esc_html__("Date", 'santos-core'),
			"param_name" => "date",
			"description" => ""
		),
		
		array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Title",  'santos-core'),
				"param_name" => "title",
				'admin_label' => true,
			),

			
            array(
				"type" => "textfield",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Subtitle",  'santos-core'),
				"param_name" => "subtitle",
				'admin_label' => false,
			),
			
			 array(
				"type" => "textarea",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Description",  'santos-core'),
				"param_name" => "content",
				'admin_label' => false,
			),
			

			

		)
) );



/* --------------------------------------------------------------------------------*/
/* Gallery
/*--------------------------------------------------------------------------------*/

class WPBakeryShortCode_santos_gallery  extends WPBakeryShortCodesContainer {}
vc_map( array(
    "name" => "Gallery",
    "base" => "santos_gallery",
	"as_parent" => array('only' => 'santos_gallery_item'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
    "content_element" => true,
    "category" => 'Santos '. esc_html__('Elements', 'santos-core'),
    "icon" => "santos_gallery",
	 "description" => esc_html__('Add gallery images with lightbox', 'santos-core'),
    "show_settings_on_create" => false,
    "params" => array(
	
		array(
			"type" => "dropdown",
			"holder" => "div",
		    "class" => "",
			"heading" => esc_html__("Column", 'santos-core'),
			"param_name" => "col",
			"value" => array(
				"Three Column" => "three_col",
				"Two Column" => "two_col",
			),
			"description" => ""
		),	
		
			array(
			"type" => "santos_toggle",
			"holder" => "div",
			"class" => "",
			"heading" => esc_html__("Disable Item Radius",  'santos-core'),
			"param_name" => "disable_radius",
			"admin_label" => false, 
			),
			
		array(
		'type' => 'textfield',
		'heading' => esc_html__( 'Extra class name', 'santos-core' ),
		'param_name' => 'el_class',
		'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'santos-core' )
		)

    ),
 "js_view" => 'VcColumnView'
) );


class WPBakeryShortCode_santos_gallery_item  extends WPBakeryShortCode {}
// Timeline Item shortcode
vc_map( array(
		"name" => "Gallery Item",
		"base" => "santos_gallery_item",
		"icon" => "santos_gallery_item",
		"category" => 'Santos '. esc_html__('Elements', 'santos-core'),
		"allowed_container_element" => 'vc_row',
        "as_child" => array('only' => 'santos_gallery'), // Use only|except attributes to limit parent (separate multiple values with comma)
		"params" => array(
		
		array(
				"type" => "attach_image",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Image",  'santos-core'),
				"param_name" => "image"
			),
		array(
			"type" => "textfield",
			"holder" => "div",
			"class" => "",
			"heading" => esc_html__("Title", 'santos-core'),
			"param_name" => "title",
		),
		array(
			"type" => "textfield",
			"holder" => "div",
			"class" => "",
			"heading" => esc_html__("Date", 'santos-core'),
			"param_name" => "date",
		),
		
		)
) );



/* --------------------------------------------------------------------------------*/
/* One Page Navigator
/*--------------------------------------------------------------------------------*/
/*
class WPBakeryShortCode_santos_onepage_navigator  extends WPBakeryShortCode {}
vc_map( array(
    "name" => "One Page Navigator",
    "base" => "santos_onepage_navigator",
    "content_element" => true,
    "category" => 'Santos '. esc_html__('Elements', 'santos-core'),
    "icon" => "santos_onepage_navigator",
    "show_settings_on_create" => false,
    "params" => array(
	
		array(
				"type" => "colorpicker",
				"holder" => "div",
				"class" => "",
				"heading" => esc_html__("Icon Color", 'santos-core'),
				"param_name" => "icon_color",
				"description" => "",
				'std' => '',
		),
			
		array(
		'type' => 'textfield',
		'heading' => esc_html__( 'Extra class name', 'santos-core' ),
		'param_name' => 'el_class',
		'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'santos-core' )
		)

    ),

) );


class WPBakeryShortCode_santos_onepage_navigator_item  extends WPBakeryShortCode {}
// Timeline Item shortcode
vc_map( array(
		"name" => "One Page Navigator Item",
		"base" => "santos_onepage_navigator_item",
		"icon" => "santos_onepage_navigator_item",
		"category" => 'Santos '. esc_html__('Elements', 'santos-core'),
		"allowed_container_element" => 'vc_row',
        "as_child" => array('only' => 'santos_onepage_navigator'), // Use only|except attributes to limit parent (separate multiple values with comma)
		"params" => array(
		array(
			"type" => "textfield",
			"holder" => "div",
			"class" => "",
			"heading" => esc_html__("Link to the Row with ID", 'santos-core'),
			"param_name" => "row_id",
			'description' => esc_html__( 'Example - #YourID', 'santos-core' )
		),
		
		)
) );

*/


class WPBakeryShortCode_santos_google_map  extends WPBakeryShortCode {}
vc_map( array(
	"name" => esc_html__("Google Map", 'santos-core'),
	"base" => "santos_google_map",
	"class" => "vc_google_map",
	"controls" => "full",
	"show_settings_on_create" => true,
	"icon" => "santos_google_map",
	"description" => esc_html__("Display Google Maps to indicate your location.", 'santos-core'),
	"category" => 'Santos '. esc_html__('Elements', 'santos-core'),
		"params" => array(
		
						array(
							'type' => 'textfield',
                            'param_name' => 'map_latitude',
							'heading' => esc_html__("Latitude",  'santos-core'),
                            'admin_label' => true,
                        ),
						array(
							'type' => 'textfield',
                            'param_name' => 'map_longitude',
							'heading' => esc_html__("Longitude",  'santos-core'),                          
                            'admin_label' => true,
                        ),
                        array(
							'type' => 'textfield',                           
						   'param_name' => 'map_height',
							'heading' => esc_html__("Height",  'santos-core'),
                            'admin_label' => false,
                            'value'=>'400px',
                        ),
						array(
						    'type' => 'textfield',
                            'param_name' => 'map_width',
							'heading' => esc_html__("Width",  'santos-core'),
                            'admin_label' => false,
                            'value'=>'100%',
                            'description' => esc_html__('ex: 100% or 600px, default: 100%', 'santos-core'),
                        ),
					 array(
							"type" => "dropdown",
							"heading" => esc_html__("Map Zoom", 'santos-core'),
							"param_name" => "map_zoom",
							"value" => array(
							esc_html__("14 - Default", 'santos-core') => 14, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 14, 15, 16, 17, 18, 19, 20
							),
							),
                        array(
							'type' => 'attach_image',
                            'param_name' => 'map_marker',
							'heading' => esc_html__("Marker",  'santos-core'),                            
                            'admin_label' => false,
                        ),
						
                	/*
                        array(
							'type' => 'textfield',
                            'param_name' => 'map_key',
							'heading' => esc_html__("API Key",  'santos-core'),
                            'admin_label' => false,
                        ),
						
				array(
				"type" => "textarea_raw_html",
				"class" => "",
				"heading" => esc_html__("Google Styled Map JSON",'santos-core'),
				"param_name" => "map_style",
				"value" => "",
				"description" => "<a target='_blank' href='https://snazzymaps.com/'>".esc_html__("Click here",'santos-core')."</a> ".esc_html__("to get the style JSON code for styling your map.",'santos-core'),
				"group" => "Styling",
				),
				*/
				array(
				"type" => "textfield",
				"heading" => esc_html__("Extra class name", 'santos-core'),
				"param_name" => "el_class",
				"description" => esc_html__("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'santos-core'),
				),
						



		)
));








/* --------------------------------------------------------------------------------*/
/* Showcase Carousel
/*--------------------------------------------------------------------------------*/

class WPBakeryShortCode_santos_showcase_carousel  extends WPBakeryShortCodesContainer {}
vc_map( array(
    "name" => "Showcase Carousel",
    "base" => "santos_showcase_carousel",
    "as_parent" => array('only' => 'santos_showcase_carousel_item'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
    "content_element" => true,
	"description" => esc_html__('Display Showcase Images as carousel', 'santos-core'),
	"category" => 'Santos '. esc_html__('Elements', 'santos-core'),
    "icon" => "santos_showcase_carousel",
    "show_settings_on_create" => false,
    "params" => array(
	
		 array(
					  "type" => "santos_number",
					  "heading" => esc_html__("Number of items per slide", 'santos-core'),
					  "param_name" => "slide_items",
					  'std' => '3',
					  "description" => esc_html__("Just right a Number (ex: 3)", 'santos-core')
				),

    ),
    "js_view" => 'VcColumnView'
) );

class WPBakeryShortCode_santos_showcase_carousel_item  extends WPBakeryShortCode {}
// showcase item shortcode
vc_map( array(
		"name" => "Showcase Item",
		"base" => "santos_showcase_carousel_item",
		"icon" => "santos_showcase_carousel_item",
		"category" => 'Santos '. esc_html__('Elements', 'santos-core'),
		"allowed_container_element" => 'vc_row',
        "as_child" => array('only' => 'santos_showcase_carousel'), // Use only|except attributes to limit parent (separate multiple values with comma)
		"params" => array(
		array(
			"type" => "attach_image",
			"holder" => "div",
			"class" => "",
			"heading" => esc_html__("Item Image", 'santos'),
			"param_name" => "image",
			"description" => "Upload Item image"
		),
		)
) );




// Santos Mail Chimp
class WPBakeryShortCode_santos_mail_chimp extends WPBakeryShortCode{}
vc_map( array(
		"name" => "Mail Chimp",
		"base" => "santos_mail_chimp",
		"category" => 'Santos '. esc_html__('Elements', 'santos-core'),
		"icon" => "santos_mailchimp",
		 "description" => esc_html__('Display Mailchimp subscription widget', 'santos-core'),
		"allowed_container_element" => 'vc_row',
		"params" => array(
				array(
					"type" => "textfield",
					"holder" => "div",
					"class" => "",
					"heading" => __("Mailchimp URL", 'santos-core'),
					"param_name" => "url",
					"value" => "",
					"description" => "Just go to your mailchimp account. Then your list. Then Signup forms. Select  Embedded forms. You will find form action URL in this page"
				),
				
				array(
					"type" => "textfield",
					"holder" => "div",
					"class" => "",
					"heading" => __("submit Message", 'santos-core'),
					"param_name" => "submit_msg",
					"value" => "Submitting...",
					'admin_label' => false,
					"description" => ""
				),
				
				array(
					"type" => "textfield",
					"holder" => "div",
					"class" => "",
					"heading" => __("Success Message", 'santos-core'),
					"param_name" => "success_msg",
					"value" => "We have sent you a confirmation email",
					'admin_label' => false,
					"description" => ""
				),
								
				array(
					"type" => "textfield",
					"holder" => "div",
					"class" => "",
					"heading" => __("Error for no value", 'santos-core'),
					"param_name" => "error_invalid_value",
					"value" => "Please enter a value",
					'admin_label' => false,
					"description" => ""
				),
				
				array(
					"type" => "textfield",
					"holder" => "div",
					"class" => "",
					"heading" => __("Error for no @ sign", 'santos-core'),
					"param_name" => "error_invalid_sign",
					"value" => "An email address must contain a single @",
					'admin_label' => false,
					"description" => ""
				),
				
				array(
					"type" => "textfield",
					"holder" => "div",
					"class" => "",
					"heading" => __("Error for invalid domain", 'santos-core'),
					"param_name" => "error_invalid_domain",
					"value" => "The domain portion of the email address is invalid",
					'admin_label' => false,
					"description" => ""
				),
	
				array(
					"type" => "textfield",
					"holder" => "div",
					"class" => "",
					"heading" => __("Error for invalid username", 'santos-core'),
					"param_name" => "error_invalid_username",
					"value" => "The username portion of the email address is invalid",
					'admin_label' => false,
					"description" => ""
				),
				
				array(
					"type" => "textfield",
					"holder" => "div",
					"class" => "",
					"heading" => __("Error for invalid email", 'santos-core'),
					"param_name" => "error_invalid_email",
					"value" => "This email address looks fake or invalid. Please enter a real email address",
					'admin_label' => false,
					"description" => ""
				),

		)
));



?>