<?php
/*
Plugin Name: Santos Core
Plugin URI: http://www.uxcode.net
Description: Santos Core Plugin for UXcode Santos Themes
Version: 1.1
Author: UXcode
Author URI: http://www.uxcode.net
*/

// Blocking direct access
if( ! function_exists( 'santos_core_block_direct_access' ) ) {
	function santos_core_block_direct_access() {
		if( ! defined( 'ABSPATH' ) ) {
			exit( 'Direct access denied.' );
		}
	}
}

if( ! class_exists( 'Santos_Core_Plugin' ) ) {
	class Santos_Core_Plugin {

		const VERSION = '1.1';
		protected static $instance = null;

		private function __construct() {
			
			define('SANTOS_CORE_URI', plugin_dir_url( __FILE__ ) );
			define('SANTOS_CORE_DIR', plugin_dir_path( __FILE__ ));
			
			
			add_action('init', array(&$this, 'init'));
			add_action('admin_init', array(&$this, 'admin_init'));
			add_action('after_setup_theme', array(&$this, 'load_santos_core_text_domain'));
		}

		function init() {

		}

		function admin_init() {
		
		wp_enqueue_style('santos_vc', SANTOS_CORE_URI .'/css/admin.css', false, Santos_Core_Plugin::VERSION, 'all');
		
		}
		
		
		
		/**
		 * Register the plugin text domain
		**/		
		function load_santos_core_text_domain() {
			load_plugin_textdomain( 'santos-core', false, dirname( plugin_basename(__FILE__) ) . '/languages' );
		}
		
		

		public static function get_instance() {

			if ( null == self::$instance ) {
				self::$instance = new self;
			}

			return self::$instance;
		}
	}
}

// Init the plugin
add_action( 'plugins_loaded', array( 'Santos_Core_Plugin', 'get_instance' ) );

/**
* Custom posts type.
*/
require_once dirname(__FILE__) . '/custom-post-types/portfolio.php';
require_once dirname(__FILE__) . '/custom-post-types/slider.php';




#-----------------------------------------------------------------#
# Custom widgets
#-----------------------------------------------------------------#
require_once dirname(__FILE__) . '/custom-widgets/author-widget.php';
require_once dirname(__FILE__) . '/custom-widgets/recent-posts-extra-widget.php';
require_once dirname(__FILE__) . '/custom-widgets/social-networks-widget.php';




add_action('admin_enqueue_scripts', 'santos_widget_scripts');
	function santos_widget_scripts($hook) {
		
	
	 if ( 'widgets.php' != $hook ) 
        return;


	wp_enqueue_script('santos-chosen-script', SANTOS_CORE_URI . '/js/chosen.min.js', 'jquery', '1.3', true);	
	wp_enqueue_style('chosen-css', SANTOS_CORE_URI . '/css/chosen.css');
	wp_enqueue_script( 'santos-widgets-script', SANTOS_CORE_URI . '/js/widgets.js', array( 'jquery' ), '1.0', true );
	// Add the color picker css/js files      
	wp_enqueue_style( 'wp-color-picker' );
	wp_enqueue_script('wp-color-picker');
	
}




/**
* Custom JS for contact form.
*/
require_once dirname(__FILE__) . '/js/custom-js.php' ;




// theme demo importer 
$theme = wp_get_theme(); // gets the current theme
if ('Santos' == $theme->name || 'Santos' == $theme->parent_theme) {
    // if you're here Santos Theme is the active theme or is
    // the current theme's parent theme
require_once dirname(__FILE__) . '/install-demos.php' ;
}


	
		

/**
* Sets Visual Composer
*/
function santos_set_visual_composer() {
	
	   vc_set_as_theme($disable_updater = true);
	
	   $temp_dir = plugin_dir_path( __FILE__ ).'/vc_templates/';
       vc_set_shortcodes_templates_dir($temp_dir);	   	    
	   $list = array(    	   
	   'page', 	   
	   'post',
	   'santos-portfolio',
	   'santos-slider',
	   );	   	   
	   vc_set_default_editor_post_types( $list );
	   
	/**
	* Extend Visual Composer Map
	*/
	require_once dirname(__FILE__) . '/extendvc/extend-vc.php';	 
	 
  
}
add_action( 'vc_before_init', 'santos_set_visual_composer' );


/**
* Extend Visual Composer Map
*/
add_action( 'vc_before_init', 'santos_vc_remove_all_pointers' );
function santos_vc_remove_all_pointers() {
   remove_action( 'admin_enqueue_scripts', 'vc_pointer_load' );
}


function santos_vc_library_cat_list() {
	return array( __('All','santos-core') => 'all', 
		__('About','santos-core') => 'about', 
		__('Blog','santos-core') => 'blog',  
		__('General','santos-core') => 'general',  
		__('Icons','santos-core') => 'icons', 
		__('Hero Section','santos-core') => 'hero', 
		__('Project','santos-core') => 'portfolio',
		__('Pricing','santos-core') => 'pricing',
		__('Services','santos-core') => 'services',
		__('Team','santos-core') => 'team',
		__('Testimonials','santos-core') => 'testimonials');
}	


if(!function_exists('santos_add_content_block_to_vc')) {
	function santos_add_content_block_to_vc() {

			require_once dirname(__FILE__) . '/extendvc/vc-content-block.php';
	}
}
santos_add_content_block_to_vc();
	
	


function santos_custom_vc_map() {
	if (class_exists('WPBakeryVisualComposerAbstract')) {
	
	
	
/* --------------------------------------------------------------------------------*/
/* Home Slider
/*--------------------------------------------------------------------------------*/

class WPBakeryShortCode_santos_slider extends WPBakeryShortCode{}


	$slider_cat = get_terms(  array('taxonomy' => 'santos-sliders','hide_empty' => false) );
	//$slider_cat = get_categories('title_li=&orderby=name&hide_empty=1&taxonomy=santos-sliders');
	
	$list_sliders = array("Select Slider" => "");

	if ( ! empty( $slider_cat ) && ! is_wp_error( $slider_cat ) ){
	foreach ($slider_cat as $type) {
	$list_sliders[$type->name] = $type->slug;
	}
	}


	vc_map( array(
			"name" => "Home Slider",
			"base" => "santos_slider",
			"category" => 'Santos '. esc_html__('Elements', 'santos-core'),
			"icon" => "santos_slider",
			"description" => esc_html__("Add creative slider to your home page.", 'santos-core'),
			"allowed_container_element" => 'vc_row',
			"params" => array(
			
									
			array(
					"type" => "dropdown",
					"holder" => "div",
					"class" => "",
					"heading" => esc_html__("Slider Type", 'santos-core'),
					"param_name" => "type",
					"value" => array(
						"Multiscroll Slider" => "multiscroll",
					),
					"description" => ""
			),
			
				array(
				"type" => "dropdown",
				"heading" => esc_html__("Select Slider.", 'santos-core'),
				"param_name" => "slider",
				"admin_label" => true,
				"value" => $list_sliders,
			),
			
			array(
							"type" => "santos_number",
							"class" => "",
							"heading" => esc_html__("Mobile Overlay Color Opacity", 'santos-core'),
							"param_name" => "mobile_overlay_opacity",
							"value" => 0.9,
							"min" => 0.0,
							"max" => 1.0,
							"step" => 0.1,
							"suffix" => "",
							'std' => '0.9',
							"dependency" => Array('element' => "type", 'value' => array('multiscroll')),
				),
						
						
		

			)
	));
	
	

	
	
	
	}
}
add_action( 'init', 'santos_custom_vc_map' );





#-----------------------------------------------------------------#
# social share
#-----------------------------------------------------------------#
if (!function_exists('santos_single_sharing_buttons')) {
function santos_single_sharing_buttons() {
	


		global $post;
		$santos_options = get_option('santos_options');
		
		?>
		
				<div class="h-20"></div>
                <hr/>
                <div class="h-30"></div>

                <div id="shareDiv" class="text-center">
                    <h4>Share This Post :</h4>

                    <a class="share-facebook single-facebook-share btn btn-blue" href="#"><i class="ion-social-facebook"></i> Share on Facebook</a>
                    <a class="share-twitter single-twitter-share btn btn-blue" href="#"><i class="ion-social-twitter"></i> Share on twitter</a>
                    <a class="share-googleplus single-googleplus-share btn btn-blue" href="#"><i class="ion-social-googleplus"></i> Share on googleplus</a>


                </div>

                <div class="h-20"></div>
                
				
		<?php
				
}
}




#-----------------------------------------------------------------#
# CUSTOM LOGIN LOGO
#-----------------------------------------------------------------#
if (!function_exists('santos_custom_login_logo')) {
 function santos_custom_login_logo() {
			$santos_options = get_option('santos_options'); 
			$custom_logo = "";
			if (isset($santos_options['admin_login_logo'])) {
			$custom_logo = $santos_options['admin_login_logo']['url'];
			}
			if ($custom_logo) {		
			echo '<style type="text/css">
			    .login h1 a { background-image:url('. $custom_logo .') !important; height: 95px!important; width: 100%!important; background-size: auto!important; }
			</style>';
			} else {
			echo '<style type="text/css">
			    .login h1 a { background-image:url('. get_template_directory_uri() .'/img/logo.png) !important; height: 60px!important; width: 100%!important; background-size: 180px auto!important; }
			</style>';
	}
}
 add_action('login_head', 'santos_custom_login_logo');
}
	

	


/* ------------------------------------------------------------------------ */
/* Year , copy rights shortcode
/* ------------------------------------------------------------------------ */
add_shortcode('santos_get_year', 'santos_shortcode_year');
function santos_shortcode_year( $atts, $content = null ) {
	extract(shortcode_atts(array(
	    ), $atts));
	
	$content = '';
	$content =  date("Y");

	return $content;
}

add_shortcode('santos_copyrights_symbol', 'santos_shortcode_copyrights_symbol');
function santos_shortcode_copyrights_symbol( $atts, $content = null ) {
	extract(shortcode_atts(array(
	    ), $atts));
	
	$content = '';
	$content =  '&copy;';

	return $content;
}



/*-----------------------------------------------------------------------------------*/
/*	Css Minifier/
*-----------------------------------------------------------------------------------*/

if (!function_exists('santos_quick_css_minify')) {	
function santos_quick_css_minify( $css ) {	
$css = preg_replace( '/\s+/', ' ', $css );		
$css = preg_replace( '/\/\*[^\!](.*?)\*\//', '', $css );	
	$css = preg_replace( '/(,|:|;|\{|}) /', '$1', $css );	
	$css = preg_replace( '/ (,|;|\{|})/', '$1', $css );		
	$css = preg_replace( '/(:| )0\.([0-9]+)(%|em|ex|px|in|cm|mm|pt|pc)/i', '${1}.${2}${3}', $css );		
	$css = preg_replace( '/(:| )(\.?)0(%|em|ex|px|in|cm|mm|pt|pc)/i', '${1}0', $css );	
	return trim( $css );
	
}
}


/*-----------------------------------------------------------------------------------*//*	
Global Dynamic Style
/*-----------------------------------------------------------------------------------*/
	
function santos_create_global_styles() {
$app_styles = array();   
global $app_styles;
}
santos_create_global_styles();


function santos_add_to_global_styles($style) {
global $app_styles;	
$app_styles[] = $style;
}

function santos_append_global_dynamic_styles() {

	global $app_styles;
	$app_dynamic_styles = '';
	$app_styles_length = count($app_styles);


if ($app_styles_length > 0) {

	foreach ($app_styles as $app_style) { 
	$app_dynamic_styles .= $app_style;
	};

}

?>

<!-- Custom content and shortcodes styles applied to head -->
<script type="text/javascript">

	var dynamic_styles = '<?php echo santos_quick_css_minify($app_dynamic_styles); ?>';

	

	if(dynamic_styles){

     var styleTag = document.createElement('style'),

	 head = document.head || document.getElementsByTagName('head')[0];



	styleTag.type = 'text/css';

	styleTag.innerHTML = dynamic_styles;

	head.appendChild(styleTag);

	}


</script>

<?php	
}




