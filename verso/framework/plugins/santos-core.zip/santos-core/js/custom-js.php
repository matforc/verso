<?php
if ( !function_exists( 'santos_contact_us_javascript' ) ) {
function santos_contact_us_javascript() {
$templateUrl = get_template_directory_uri();
$santos_options = get_option('santos_options');
$admin_email = 'webmaster@yourdomain.com';
if ( isset($santos_options['contact-email']) && $santos_options['contact-email'] != "") {
 $admin_email =  $santos_options['contact-email'];
}
// JavaScript Document
?>
<script type="text/javascript">
jQuery(document).ready(function($) {
   'use strict';



/* Contact Form
================================================== */ 

function santos_validateEmail(email) {
	
  var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  return re.test(email);
}
		
 $("#contact_form #submit_btn").click(function () {
	 
	
        //get input field values
        var user_name = $('#contact_form input[name=name]').val();
        var user_email = $('#contact_form input[name=email]').val();
        var user_message = $('#contact_form textarea[name=message]').val();
		
		var admin_email = '<?php echo sanitize_email($admin_email); ?>';
		var site_name = '<?php echo get_bloginfo( 'name' ); ?>';

        //simple validation at client's end
        //we simply change border color to red if empty field using .css()
        var proceed = true;
        if (user_name == "") {
			$('#contact_form input[name=name]').parent().addClass('error');
            proceed = false;
        }else{
		$('#contact_form input[name=name]').parent().removeClass('error');
		}
        
		if (santos_validateEmail(user_email)) {
			$('#contact_form input[name=email]').parent().removeClass('error');
        }else{
		$('#contact_form input[name=email]').parent().addClass('error');
          proceed = false;	
		}

        // if(user_phone=="") {    
        //     $('input[name=phone]').css('border-color','red'); 
        //     proceed = false;
        // }
        if (user_message == "") {
			$('#contact_form textarea[name=message]').parent().addClass('error');
            proceed = false;
        }else{
		$('#contact_form textarea[name=message]').parent().removeClass('error');
		}


        //everything looks good! proceed...
        if (proceed) {
            //data to be sent to server
            var post_data = {
                'userName': user_name,
                'userEmail': user_email,
                'userMessage': user_message,
				'adminEmail': admin_email,
				'siteName': site_name
            };
            var output;
            //Ajax post data to server
			$.post('<?php echo SANTOS_CORE_URI ?>/includes/contact_me.php', post_data, function(response){ 

                //load json data from server and output message     
                if (response.type == 'error') {
                    output = '<div class="error">' + response.text + '</div>';
                } else {
                    output = '<div class="success">' + response.text + '</div>';

                    //reset values in all input fields
                    $('#contact_form input').val('');
                    $('#contact_form textarea').val('');
                }

                $("#result").hide().html(output).slideDown();
            }, 'json');

        }
    });

    //reset previously set border colors and hide all message on .keyup()
    $("#contact_form input, #contact_form textarea").keyup(function () {
        $("#contact_form input, #contact_form textarea").css('border-color', '');
        $("#result").slideUp();
    });

	
		
});
//End Document.ready   
</script>
<?php } } //function end ?>