<?php

/*
 * Demo Importer
 * by www.uxcode.net
  */

defined( 'ABSPATH' ) or die( 'You cannot access this script directly' );


/*
|--------------------------------------------------------------------------
| Demo Importer Menu Item
|--------------------------------------------------------------------------
*/
add_action('admin_menu', 'santos_demo_importer_menu');

if ( !function_exists( 'santos_demo_importer_menu' ) ) {
	
	function santos_demo_importer_menu() {
	
		add_theme_page ( 'Santos Install Demos', 'Install Demos', 'manage_options', 'santos-demos', 'santos_install_demos' );
	}
	
}


/*
|--------------------------------------------------------------------------
| Demo Importer Styles
|--------------------------------------------------------------------------
*/
if ( !function_exists( 'santos_importer_admin_add_scripts' ) ) {

	function santos_importer_admin_add_scripts() {
			
		wp_enqueue_style('santos-importer', SANTOS_CORE_URI. 'css/importer.css', false);
		wp_enqueue_script( 'santos-importer', SANTOS_CORE_URI . 'js/importer.js' );
					
	}
	
}

if ( isset($_GET['page']) && $_GET['page'] == 'santos-demos' ) {	
	add_action( 'admin_enqueue_scripts', 'santos_importer_admin_add_scripts' );
}


/*
|--------------------------------------------------------------------------
| Check if wp-content is writeable for demo images
|--------------------------------------------------------------------------
*/
if ( !function_exists( 'santos_is_writable' ) ) {
	
	function santos_is_writable( $path ) {
	
		if ( $path{strlen($path)-1}=='/' ) {
			return santos_is_writable($path.uniqid(mt_rand()).'.tmp');
		}
		
		if (file_exists($path)) {
			if (!($f = @fopen($path, 'r+')))
				return false;
			fclose($f);
			return true;
		}
		
		if (!($f = @fopen($path, 'w')))
			return false;
		fclose($f);
		unlink($path);
		return true;
		
	}
	
}


/*
|--------------------------------------------------------------------------
| Demo Importer Interface
|--------------------------------------------------------------------------
*/

if ( !function_exists( 'santos_install_demos' ) ) {
	
	function santos_install_demos() { ?>
	
	
<div class="wrap santos-page-welcome about-wrap santos-wrap">

	<h1><?php echo esc_html__( "Welcome to ", "santos" ) . '<span class="santos-name">'.SANTOS_NAME.'</span> !'; ?></h1>

	<div class="about-text">
		<?php printf(wp_kses(__( "%s is up and running! Get ready to build beautiful site. We hope you enjoy a free imagination with the most powerfull theme for WordPress! ", "santos" ), array( 'br' => '')), SANTOS_NAME); ?>
	</div>
	<div class="wp-badge santos-page-logo">	Version <?php echo SANTOS_VERSION; ?>	</div>
	<h2 class="nav-tab-wrapper">
	<?php
			printf( '<a href="%s" class="nav-tab">%s</a>', admin_url('themes.php?page=santos-welcome'), esc_html__( "Welcome", "santos" ) );

			printf( '<a href="%s" class="nav-tab nav-tab-active">%s</a>', admin_url( 'themes.php?page=santos-demos' ), esc_html__( "Install Demo", "santos" ) );
		
			printf( '<a href="%s" class="nav-tab">%s</a>', admin_url( 'themes.php?page=santos-system-status' ), esc_html__( "System Status", "santos" ) );
	
		?>
	</h2>
	
	
		
		<div id="santos-importer" class="wrap">
		
           
            
			<?php 
			
			/*
			|--------------------------------------------------------------------------
			| Notifications
			|--------------------------------------------------------------------------
			*/
			if( file_exists( ABSPATH . 'wp-content/uploads/' ) ) {
				
				/* wp-content upload folder not writeable  */ 
				if( !santos_is_writable( ABSPATH . 'wp-content/uploads/' ) ) :
				
					echo '<div class="error" style="display:block!important;"><p>';
						
						echo '<strong>' .esc_html__('Your upload folder is not writeable! The importer won\'t be able to import the placeholder images. Please check the folder permissions', 'santos-core').'</strong><br />';
						echo ABSPATH . 'wp-content/uploads/';
						
					echo '</p></div>';
					
				endif;
				
			
			} else {
			
				/* wp-content folder not writeable  */ 
				if( !santos_is_writable( ABSPATH . 'wp-content/uploads/' ) ) :
					
					echo '<div class="error" style="display:block!important;"><p>';
					
						echo '<strong>' .esc_html__('Your wp-content folder is not writeable! The importer won\'t be able to import the placeholder images. Please check the folder permissions', 'santos-core').'</strong><br />';
						echo ABSPATH . 'wp-content/';
					
					echo '</p></div>';
					
				endif;
			
			}
			
	
	
			/* import was successful */
			if( isset($_GET['santosimport']) && $_GET['santosimport'] == 'success' ) : 
				
				echo '<div class="updated" style="display:block!important;"><p>'.esc_html__('Import was successful, have fun!', 'santos-core').'</p></div>';
			
			endif; 
			
			/* importer has been used before */
			if( get_option('santos_import_loaded') == 'active' ) :
				
				echo '<div class="error" style="display:block!important;"><p>'.esc_html__('You already have imported the demo content before. Running this operation twice will result in double content!', 'santos-core').'</p></div>';
			
			endif;
			
			?>
            
            <form id="santos-importer-form" method="POST" action="?page=santos-demos" class="form-horizontal">
			  
			   <div class="form_items">
			  <div class="loading_screen" style="display:none;">
					<div class="showbox">
						<svg class="circular" viewBox="25 25 50 50">
							<circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10"/>
						</svg>
					</div>
					
					<h3><?php esc_html_e( 'Please Set Back and Relax while santos demo install!', 'santos-core' ); ?></h3>
				</div>
				
			 <div class="xml">
			 
                <input type="radio" id="demo_default" name="santos_demo_file" value="demo_default" checked class="santos-choose-demo-radio">
                <label class="santos-choose-demo-img" for="demo_default">
                    <img src="<?php echo SANTOS_CORE_URI; ?>/img/import/default.jpg" />                    
                </label>
                <h3 class="xml-name">Default</h3>
                <div class="xml-actions">
                	<a target="_blank" href="http://www.uxcode.net/themes/santos/" class="button button-primary"><?php esc_html_e('Preview' , 'santos-core'); ?></a>
                </div>
            </div>
			
			
			
            
            <div class="clear"></div>
			
			</div>
			
			 <div class="clear"></div>
			
			<div class="santos-import-notes">
			<table class="form-table">
            	<tbody>
			 
                    <tr valign="top">
                    	
                        <th scope="row">
							<?php esc_html_e('Important Notes:' , 'santos-core'); ?>
                        </th>
                      	
                        <td>
                            <ol>
                                <li><?php esc_html_e('We recommend to run this importer on a clean WordPress installation. Demo import process should take less than 5 Min depending on your server and internet speed. runing the importer multiple times may result double content.' , 'santos-core'); ?></li>
								<li> <?php esc_html_e('Memory limit at least 128MB is required please check systm status Tab to check your current WP Memory Limit Recommendation.' , 'santos-core'); ?></li>
                                <li><?php esc_html_e('If you have toubles using our Demo import process you may also try the manual WordPress import through Tools Menu. We have attached XML demo files at Theme Package Folder' , 'santos-core'); ?></li>
								<li><?php esc_html_e('To reset your installation we can recommend this plugin here:' , 'santos-core'); ?> <a href="http://wordpress.org/plugins/wordpress-database-reset/">Wordpress Database Reset</a></li>
                            </ol>
                        </td>                       
                    
                    </tr>  
                                        
            	</tbody>
            </table>
			
			</div>
			
			<div class="clear"></div>
            
            <div class="santos-import-button">
                
                <input type="hidden" name="santos_import_demo_content" value="true" />
                <input type="submit" value="<?php esc_html_e( 'Import' , 'santos-core' ); ?>" class="button button-primary" id="submit" name="submit">
                
            </div>
            
            </form>
		
		</div>
		
		</div><!-- wrap-->
		
	<?php }
	
}

/*
|--------------------------------------------------------------------------
| Demo Importer
|--------------------------------------------------------------------------
*/

add_action( 'admin_init', 'santos_demo_importer' );
if ( !function_exists( 'santos_demo_importer' ) ) {
	function santos_demo_importer() {
		
		global $wpdb;
		
		/* add option flag to wordpress */
		add_option('santos_import_loaded');
		
		/* security array for valid filenames */
		$santos_recognized_file_names = apply_filters( 'santos_recognized_file_names', array( 
		   'demo_default'
		));
			
		if ( current_user_can( 'manage_options' ) && isset( $_POST['santos_import_demo_content'] ) && !empty( $_POST['santos_demo_file'] ) ) {
			if ( !defined('WP_LOAD_IMPORTERS') ) define('WP_LOAD_IMPORTERS', true);
			
			if ( ! class_exists( 'WP_Importer' ) ) {
				$class_wp_importer = ABSPATH . 'wp-admin/includes/class-wp-importer.php';
				if ( file_exists( $class_wp_importer ) ) {
					include $class_wp_importer;
				}
			}
			if ( ! class_exists('Santos_WP_Import') ) { 
				$class_wp_import = SANTOS_CORE_DIR . '/importer/wordpress-importer.php';
				if ( file_exists( $class_wp_import ) ) {
					include $class_wp_import;
				}
			}	
			
			if ( class_exists( 'WP_Importer' ) && class_exists( 'Santos_WP_Import' ) ) {
				
				/*
				|--------------------------------------------------------------------------
				| Import choosen XML
				|--------------------------------------------------------------------------
				*/
				
				$importer = new Santos_WP_Import();
				
				$demo_file = sanitize_file_name($_POST['santos_demo_file']);
				$content_type = sanitize_file_name($_POST['santos_demo_content']);
				
								
				if ( in_array( $demo_file , $santos_recognized_file_names) ) {
					
				
					$theme_xml = SANTOS_CORE_DIR . '/xml/' . $demo_file . '.xml';
					
					$importer->fetch_attachments = true;
					ob_start();
					$importer->import($theme_xml);
					ob_end_clean();		
					
					
					
				} else {
					
					wp_redirect( admin_url( 'themes.php?page=santos-demos&santosimport=failed' ) );
					
				}
				

				
					
				/*
				|--------------------------------------------------------------------------
				| Set Reading Options
				|--------------------------------------------------------------------------
				*/
				
				$homepage 	= get_page_by_title( 'Home Version 1' );
				$posts_page = get_page_by_title( 'Blog' );
				
                
				if( isset($homepage->ID) ) {
					update_option('show_on_front', 'page');
					update_option('page_on_front',  $homepage->ID); // Home Page
				}
				
				if(isset($posts_page->ID) ) {
				update_option('page_for_posts', $posts_page->ID); // Blog Page
				}


										
				
				/*
                |--------------------------------------------------------------------------
                | Update Theme Options
                |--------------------------------------------------------------------------
                */
 
				if ( class_exists( 'ReduxFramework' ) && file_exists( SANTOS_CORE_DIR . '/xml/options/' . $demo_file. '_option.json' ) ) {
                    global $reduxConfig;
                    $option_file = SANTOS_CORE_DIR . '/xml/options/' . $demo_file. '_option.json';
                    $file_contents = file_get_contents( $option_file );
                    $options = json_decode($file_contents, true);
                    
                    foreach ($options as $key => $value) {
                            $reduxConfig->ReduxFramework->set($key, $value);
                    }
                   
                    
				   }
				
				  
								
				/*
				|--------------------------------------------------------------------------
				| Set Menu Navigation
				|--------------------------------------------------------------------------
				*/
												
				$locations = get_theme_mod( 'nav_menu_locations' ); 
				$menus = wp_get_nav_menus(); 

				
				if( is_array($menus) ) {
					
					
					foreach($menus as $menu) { 
						

						if( $menu->name == 'Main Menu' ) {
						$locations['primary_menu'] = $menu->term_id;
						}
						
						if( $menu->name == 'Top Left Menu' ) {
						$locations['top_left_menu'] = $menu->term_id;
						}
						
						if( $menu->name == 'Top Right Menu' ) {
						$locations['top_right_menu'] = $menu->term_id;
						}
						
						if( $menu->name == 'Footer Menu 1' ) {
						$locations['footer_menu_1'] = $menu->term_id;
						}
						
						if( $menu->name == 'Footer Menu 2' ) {
						$locations['footer_menu_2'] = $menu->term_id;
						}
						
						if( $menu->name == 'Footer Menu 3' ) {
						$locations['footer_menu_3'] = $menu->term_id;
						}
						
						
						if( $menu->name == 'Home 4 Menu' ) {
						$locations['second_menu'] = $menu->term_id;
						}
						
						
						
					}
				}
				
				set_theme_mod( 'nav_menu_locations', $locations );  
				
				
				/*
				|--------------------------------------------------------------------------
				| Update Import Flag
				|--------------------------------------------------------------------------
				*/
				update_option('santos_import_loaded', 'active');
				
				/*
				|--------------------------------------------------------------------------
				| Redirect User
				|--------------------------------------------------------------------------
				*/
				wp_redirect( admin_url( 'themes.php?page=santos-demos&santosimport=success' ) );
								
				
			}
		
		}
		
	}
} ?>