<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
/**
 * Shortcode attributes
 * @var $atts
 * @var $order
 * @var $orderby
 * Shortcode class
 * mobile_overlay_opacity
 * @var $this WPBakeryShortCode_santos_portfolio
 */
 

$slider ='';
$mobile_overlay_opacity = 0.8;
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

		$args = array(
                'post_type'=> 'santos-slider',
				'santos-sliders' => $slider,
                'orderby' => "menu_order",
                'order' => "ASC",
                'posts_per_page' => -1
            );
			
$i = 1;	
$ms_left = $ms_right = $custom_style = '';			
			
$santos_slider = new WP_Query( $args );	
if($santos_slider->have_posts() ) :

 
 
 $custom_style .= '@media (max-width: 768px) {';
 
 $default_src = get_template_directory_uri() .'/img/no_image.png' ;
while ($santos_slider->have_posts()) : $santos_slider->the_post(); 	
		
		$title_align = rwmb_meta( 'santos_slide_title_align' ) ? rwmb_meta( 'santos_slide_title_align' ) : 'left' ;
		$title_color = rwmb_meta( 'santos_slide_title_color' ) ? rwmb_meta( 'santos_slide_title_color' ) : '#333' ;
		$slide_subtitle = rwmb_meta( 'santos_slide_subtitle' ) ? rwmb_meta( 'santos_slide_subtitle' ) : '' ;
		$subtitle_color = rwmb_meta( 'santos_slide_title_color' ) ? rwmb_meta( 'santos_slide_title_color' ) : '#999' ;
		$image_position = rwmb_meta( 'santos_slide_image_position' ) ? rwmb_meta( 'santos_slide_image_position' ) : 'left' ;
		$slide_bg_color = rwmb_meta( 'santos_slide_bg_color' ) ? rwmb_meta( 'santos_slide_bg_color' ) : '#fff' ;
		
		$slide_img = '';
 		$slide_images = rwmb_meta( 'santos_slide_image', 'type=image&size=full' );
		  if( !empty($slide_images) ) {
					foreach ( $slide_images as $slide_image )
					{
					  $slide_img = $slide_image['url'];
					  break;
					}
			}

			
	
		$image_src = $slide_img ? esc_url( $slide_img ) : esc_url($default_src);	

		
		switch ($image_position) {
			case 'left':
				$content_position = 'right';
				break;
			case 'right':
				$content_position = 'left';
				break;
			default:
				$content_position = 'right';
		} 
		
		
		
		 
		
				${'ms_' . $content_position} .= '<div class="ms-section ms-content ms-'.$i.'" >
				<div class="overlay_color" style="background-color:'.$slide_bg_color.';"></div>
				<div class="ms-padding slide_content text-'.$title_align.'">
                    <h5 class="slide_subtitle" style="color:'.$subtitle_color.';">'.$slide_subtitle.'</h5>
                    <h2 class="slide_title" style="color:'.$title_color.';" >'.get_the_title().'</h2>
                    <div class="clearfix"></div> '.get_the_content().'
                </div></div>';
				
	
				
				${'ms_' . $image_position} .= '<div class="ms-section ms-image ms-'.$i.'" style="background: '.$slide_bg_color.' url('.$image_src.');"></div>';	
		
			
			$custom_style .= '
			#multiscroll .ms-'.$content_position.' .ms-section.ms-'.$i.'{
					background: url('.$image_src.');
				}
			.ms-section.ms-content .overlay_color{opacity: '.$mobile_overlay_opacity.';}
			';	
				
				
				
			$i ++; 
			
			
			
endwhile; endif;  wp_reset_query();	


$output = '<div class="full-height clearfix"> <div id="multiscroll" class="" > 
 <div class="ms-left">'.$ms_left.'</div>									
 <div class="ms-right"> '.$ms_right.'</div>
 </div></div>';
 

$custom_style .= '}';
santos_add_to_global_styles($custom_style);
 
echo do_shortcode($output);
			