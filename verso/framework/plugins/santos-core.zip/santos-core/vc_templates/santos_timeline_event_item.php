<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
/**
 * Shortcode attributes
 * @var $atts
 * @var $date
 * @var $title
 * @var $subtitle
 * Shortcode class
 * @var $this WPBakeryShortCode_santos_testimonial_carousel_item
 */
 
$date = $title = $subtitle =  '';
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );



$output = ' <li class="timeline-event" data-aos="fade-up">
                    <label class="timeline-event-icon"></label>
                    <div class="timeline-event-copy">
                        <p class="timeline-event-thumbnail">'.esc_attr($date).'</p>
                        <h3>'.esc_attr($title).'</h3>
                        <h4>'.esc_attr($subtitle).'</h4>
                        <p>'.esc_attr($content).'</p>
                    </div>
                </li>';


echo do_shortcode($output);