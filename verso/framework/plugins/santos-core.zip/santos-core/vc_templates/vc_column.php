<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Shortcode attributes
 * @var $atts
 * @var $el_class
 * @var $width
 * @var $css
 * @var $santos_column_padding
 * @var $padding_behaviour
 * @var $offset
 * @var $animation
 * @var $mobile_order
 * @var $content - shortcode content
 * Shortcode class
 * @var $this WPBakeryShortCode_VC_Column
 */
 
$el_class = $width = $css =  $offset = $santos_column_padding = $padding_behaviour = $animation = $data_aos = $mobile_order = '';
$output = '';
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$width = wpb_translateColumnWidthToSpan( $width );
$width = vc_column_offset_class_merge( $offset, $width );

$css_classes = array(
	$this->getExtraClass( $el_class ),
	'wpb_column',
	'vc_column_container',
	$width,
);

if (vc_shortcode_custom_css_has_property( $css, array('border', 'background') )) {
	$css_classes[]='vc_col-has-fill';
}



if (  $santos_column_padding != '' ) {
	$css_classes[] = 'column-'.$santos_column_padding;
}

if (  $mobile_order != '' ) {
	$css_classes[] = 'mobile_order_'.$mobile_order;
}



if($padding_behaviour == 'mobile_remove_padding'){
$css_classes[] = ' mobile_remove_padding';
}else if($padding_behaviour == 'mobile_add_padding'){
$css_classes[] = ' mobile_add_padding';
}



$wrapper_attributes = array();

$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( $css_classes ) ), $this->settings['base'], $atts ) );

if($animation !=''){
$data_aos .= 'data-aos='.$animation;
}

$wrapper_attributes[] = 'class="' . esc_attr( trim( $css_class ) ) . '"';

$output .= '<div ' . implode( ' ', $wrapper_attributes ) . ' '. esc_attr( $data_aos ).'>';


$output .= '<div class="vc_column-inner ' . esc_attr( trim( vc_shortcode_custom_css_class( $css ) ) ) . '">';
$output .= '<div class="wpb_wrapper">';
$output .= wpb_js_remove_wpautop( $content );
$output .= '</div>';
$output .= '</div>';
$output .= '</div>';

echo do_shortcode($output);