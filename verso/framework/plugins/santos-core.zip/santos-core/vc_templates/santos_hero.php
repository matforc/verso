<?php

$args = array(
    'image' => '',
	'parallax' => 'parallax',
	'hero_height' => 'height-100',
	'overlay_color' => '',
	'enable_scroll_icon' => '',
	'scroll_row_id' => '',
	'el_class' => '',
);

$output = $overlay_class = "";

extract(shortcode_atts($args, $atts));


$default_src = get_template_directory_uri() .'/img/no_image.png' ;
$img_url = wp_get_attachment_image_src( $image, 'full');	
$image_src = $img_url[0] ? esc_attr( $img_url[0] ) : $default_src;


$id = uniqid();
$custom_style ='';
$custom_style .= '
#santos_hero_'.$id.'{background-image:url('.$image_src.'); }
'; 
santos_add_to_global_styles($custom_style);



$css_classes = array(
	'santos_hero',
	'santos_hero_heading',
	'fullHeightSection',
	'background',
	$parallax,
	$el_class,
);

$css_classes[] = 'height_percent_'.$hero_height; 

$output = '<!-- Hero Heading -->
    <section id="santos_hero_'. esc_attr( $id ).'" class="'. implode(' ', $css_classes ).'"  data-img-width="1600" data-img-height="1064" data-diff="100">';
	
	
	if($overlay_color !=''){
	$overlay_class .= 'bg-overlay';
	$output .= "\n\t" . '<div class="'. esc_attr($overlay_class) .'" style="background-color:'. esc_attr($overlay_color) .';" ></div>';
	}

       $output .='<div class="container clearfix"><div class="flex-box"><div class="flex-inner-wrap">';
	   
			
		$output .= do_shortcode($content);
            

			
if($enable_scroll_icon == 'true'){

$output .= "\n\t" . '<a href="'. esc_attr($scroll_row_id) .'" class="scroll-icon">
            <div class="scroll-downs">
                <div class="mousey">
                    <div class="scrollery"></div>
                </div>
            </div>
        </a>';
}
			

            $output .= '
      </div>  </div> </div>
    </section>
    <!-- / Hero Heading -->';
	
	


echo do_shortcode($output);