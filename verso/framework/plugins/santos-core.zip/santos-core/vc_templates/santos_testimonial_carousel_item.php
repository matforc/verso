<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
/**
 * Shortcode attributes
 * @var $atts
 * @var $quote
 * @var $quote_color
 * @var $name
 * @var $name_color
 * @var $position
 * @var $position_color
 * Shortcode class
 * @var $this WPBakeryShortCode_santos_testimonial_carousel_item
 */
 
$quote = $quote_color = $name = $name_color = $position = $position_color =  '';
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );



$output = '<!-- feedback item -->
                    <div class="feedbackBox">
                        <h4 style="color:'.esc_attr($quote_color).';"><span>“</span> '.$quote.' <span>”</span></h4>
                        <h4><span style="color:'.esc_attr($name_color).';" class="feedbackName">'.esc_attr($name).'</span>  <span style="color:'.esc_attr($position_color).';" class="jobTitle">- '.esc_attr($position).'</span></h4>
                    </div>
                    <!-- / feedback item -->';


echo do_shortcode($output);