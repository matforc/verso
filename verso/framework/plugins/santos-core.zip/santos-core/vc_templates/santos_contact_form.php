<?php
if ( ! defined( 'ABSPATH' ) ) {
die( '-1' );
}
/**
* Shortcode attributes
* @var $atts
* @var $name_label
* @var $email_label
* @var $subject_label
* @var $message_label
* @var $submit_label
* @var $text_color
* @var $btn_text_color
* @var $btn_bg_color
* @var placeholder_animate
* @var placeholder_animate_color
* @var placeholder_animate_bg
* Shortcode class
* @var $this WPBakeryShortCode_santos_contact_form
*/
$output = $name_label = $email_label = $subject_label = $message_label = $submit_label =  '';
$placeholder_animate = $placeholder_animate_color  = $placeholder_animate_bg ='';
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$id = uniqid();

$custom_style ='';
$custom_style .= '
#santos_contact_form_'.$id.' .mat-input{color:'.$text_color.';}
'; 

if($btn_bg_color !='' || $btn_text_color != ''){
$custom_style .= '
#santos_contact_form_'.$id.' #submit_btn.btn{color:'.$btn_text_color.';background:'.$btn_bg_color.';}
';	 
}

if($placeholder_animate =='true' ){
	
if($placeholder_animate_color !='' || $placeholder_animate_bg != ''){
$custom_style .= '
#santos_contact_form_'.$id.' .input-contact > span.active,
#santos_contact_form_'.$id.' .textarea-contact > span.active{color:'.$placeholder_animate_color.';background:'.$placeholder_animate_bg.';}
';	 
}
}

santos_add_to_global_styles($custom_style);
santos_contact_us_javascript();
?>
	
	<div id="contact_form" class="santos_contact_form wrap santos_content_element <?php if($placeholder_animate =='true' ){ echo esc_attr( 'placeholder_animate' ); } ?>">
	<div id="santos_contact_form_<?php echo esc_attr( $id ); ?>">
		
			<div id="result"></div>
               
                    <div class="row">
                        <div class="col-md-6">
                            <div class="input-contact">
                                <input type="text" name="name">
                                <span><?php echo esc_attr($name_label); ?></span>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="input-contact">
                                <input type="text" name="email">
                                <span><?php echo esc_attr($email_label); ?></span>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="input-contact">
                                <input type="text" name="subject">
                                <span><?php echo esc_attr($subject_label); ?></span>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="textarea-contact">
                                <textarea name="message"></textarea>
                                <span><?php echo esc_attr($message_label); ?></span>
                            </div>
                        </div>
                        <div class="col-md-12">
                          
							<button id="submit_btn" class="btn btn-blue"><?php echo esc_attr($submit_label); ?></button>
                        </div>
                    </div>

		
			
		
		
	</div></div>
	
	