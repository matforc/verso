<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
/**
 * Shortcode attributes
 * @var $atts
 * @var $align
 * @var $pagination_color
 * Shortcode class
 * @var $this WPBakeryShortCode_santos_testimonial_carousel
 */
 
$output = $css = '';
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );

$id = uniqid();

$pagination_color =  '';

extract( $atts );

$custom_style ='';
if($pagination_color != ''){
$custom_style .= '
#santos_testimonial_carousel_'.$id.' .owl-theme .owl-dots .owl-dot.active span,
#santos_testimonial_carousel_'.$id.' .owl-theme .owl-dots .owl-dot:hover span {
    background: '.$pagination_color.';
}'; 

santos_add_to_global_styles($custom_style);	
}


$css_class = 'santos_testimonial_carousel wpb_content_element text-'.$align.' ' .$el_class ;

$output .= ' <div id="santos_testimonial_carousel_'. esc_attr( $id ).'" class="'.esc_attr($css_class).'"><div class="owl-carousel owl-theme owl-feedback">';
                   	
				$output .= do_shortcode($content);
					
			    $output .= ' </div></div>';
				
echo do_shortcode($output);