<?php
if ( ! defined( 'ABSPATH' ) ) {
die( '-1' );
}
/**
* Shortcode attributes
* @var $atts
* @var $address
* @var $phone
* @var $fax
* @var $email
* Shortcode class
* @var $this WPBakeryShortCode_santos_contact_info
*/
$output = $address = $phone = $fax = $email =  '';
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

	 $output .= '<div class="santos_contact_info contactInfo santos_content_element">';
		
		 if($address != "") {
			$output .=  '<h4>'. __('Address','sanots-core').' :</h4>';
            $output .=  '<p>' . esc_attr($address) . ' </p>';
			$output .=  '<div class="h-30"></div>';

        }

        if($phone != "" || $fax != "" ) {
			  $output .=  '<h4>'. __('Phones','sanots-core').' :</h4>';
             $output .=  '<p>' . esc_attr($phone) . ' </p>';
			  $output .=  '<p>' . esc_attr($fax) . ' </p>';
			  $output .=  '<div class="h-30"></div>';

        }



        if($email != "") {
			$output .=  '<h4>'. __('Email','sanots-core').' :</h4>';
			$output .=  '<p>' . esc_attr($email) . ' </p>';
			$output .=  '<div class="h-30"></div>';

        }
		$output .= '</div>';

		
	
echo do_shortcode($output);
