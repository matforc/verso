<?php
if ( ! defined( 'ABSPATH' ) ) {
die( '-1' );
}
/**
* Shortcode attributes
* @var $atts
* @var $title
* @var $link
* @var $style
* @var $text_color
* @var $bg_color
* @var $align
* @var $el_class
* Shortcode class
* @var $this WPBakeryShortCode_santos_team
*/
$title = $link = $style = $text_color = $align = $el_class = '';

$santos_options = get_option('santos_options');


$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$id = uniqid();

$link = ( '||' === $link ) ? '' : $link;
$link = vc_build_link( $link );
$a_href = $link['url'] ? $link['url'] : '#';
$a_title = $link['title'];
$a_target = $link['target'] ? $link['target'] : '_self';

$el_class = $this->getExtraClass( $el_class );

$bg_color = $bg_color ? $bg_color : $santos_options['theme_color'];

$custom_style ='';
if($style == 'outlined'){
$custom_style .= '
#santos_btn_'.$id.' .btn{color:'.$text_color.';border:2px solid '.$bg_color.';background:transparent;}
'; 	
}else{
$custom_style .= '
#santos_btn_'.$id.' .btn{color:'.$text_color.';background:'.$bg_color.';}
'; 
}

santos_add_to_global_styles($custom_style);
?>
<div id="santos_btn_<?php echo esc_attr( $id ); ?>" class="santos_btn_wrapper santos_content_element  text-<?php echo esc_attr( $align ); ?>">
    <a class="btn <?php echo esc_attr( trim( $el_class ) ); ?>" href="<?php echo esc_attr( $a_href ); ?>" title="<?php echo esc_attr( $a_title ); ?>" target="<?php echo esc_attr( $a_target ); ?>"><?php echo esc_attr( $title ); ?></a>
</div>