<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
/**
 * Shortcode attributes
 * @var $atts
 * @var $fancytext_prefix
 * @var $fancytext_strings
 * @var $fancytext_align
 * @var $fancytext_color
 * @var $prefixtext_color
 * @var $fancytext_tag
 * @var $text_size
 * @var $el_class
 * Shortcode class
 * @var $this WPBakeryShortCode_santos_icon_box
 */

$fancytext_prefix =  $fancytext_strings = $fancytext_align = $fancytext_color = $prefixtext_color = $el_class = $fancytext_tag  =  '';

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$id = uniqid();


$custom_style ='';
$custom_style .= '
#santos_fancy_text_'.$id.' .cd-words-wrapper b{color:'.$fancytext_color.';}
#santos_fancy_text_'.$id.' .cd-headline.clip .cd-words-wrapper::after { background-color: '.$fancytext_color.';}
'; 

if($text_size != 0 || $text_size !='' ){
	$custom_style .= '
	#santos_fancy_text_'.$id.' .cd-intro '.$fancytext_tag.'{font-size:'.$text_size.'px;line-height:'.($text_size+10).'px;}
	'; 
}
santos_add_to_global_styles($custom_style);


// Order of replacement
$order   = array("\r\n", "\n", "\r", "<br/>", "<br>");
$replace = '|';
// Processes \r\n's first so they aren't converted twice.
$str = str_replace($order, $replace, $fancytext_strings);
$lines = explode("|", $str);



			
$css_class = 'santos_fancy_text wpb_content_element text-'.$fancytext_align.' ' .$el_class ;

wp_enqueue_script( 'santos-fancy-text', get_template_directory_uri() . '/js/fancytext.js', array( 'jquery' ), null, true );


?>
 <!-- cd-intro -->
 <div id="santos_fancy_text_<?php echo esc_attr( $id ); ?>" class="<?php echo esc_attr( trim( $css_class ) ); ?>" >
     <div  class="cd-intro">
                        <<?php echo esc_attr( $fancytext_tag ); ?> class="cd-headline clip is-full-width">
			             <span style="color:<?php echo esc_attr( $prefixtext_color ); ?>"><?php echo esc_attr( $fancytext_prefix ); ?></span>
			             <span class="cd-words-wrapper">
						 <?php
						 $i=0;
						 foreach($lines as $line)
						{
							if($i == 0){
								echo '<b class="is-visible">'.strip_tags($line).'</b>';
							}else{
								echo '<b>'.strip_tags($line).'</b>';
							}
							$i++;
						}
						 
						?>
				            
			             </span>
		              </<?php echo esc_attr( $fancytext_tag ); ?>>
     </div>
</div>	 
<!-- cd-intro -->

