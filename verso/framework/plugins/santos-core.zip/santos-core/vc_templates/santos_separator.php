<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Shortcode attributes
 * @var $atts
 * @var string $color_style
 * @var string $custom_color
 * @var string $sep_width
 * @var string $el_class
 * @var string $align
 * Shortcode class
 * @var $this WPBakeryShortCode_VC_Separator
 */
$color_style = $custom_color = $sep_width = $el_class  = $align = '';
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$santos_options = get_option('santos_options');

$sep_color ='';
if($color_style == 'theme_color'){
$sep_color = $santos_options['theme_color'];
}else{
$sep_color = $custom_color;
}


?>
<div class="santos_separator_wrapper text-<?php echo esc_attr( $align ); ?> santos_sep_width_<?php echo esc_attr( $sep_width ); ?>">
<span class="santos_sep_holder">   
   <span style="border-color:<?php echo esc_attr($sep_color);?>" class="santos_sep_line" ></span>
</span>
</div>


