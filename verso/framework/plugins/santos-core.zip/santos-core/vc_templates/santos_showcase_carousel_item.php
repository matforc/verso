<?php

$args = array(
    "image"         => "",
);

extract(shortcode_atts($args, $atts));

$image = wp_get_attachment_image_src( $image, 'full');



$output = '';

$output .= ' <div class="recentDiv">
                    <a href="#">
                        <img src="'.$image[0].'" alt="" class="img-responsive" />
                    </a>
                </div>';


echo do_shortcode($output);