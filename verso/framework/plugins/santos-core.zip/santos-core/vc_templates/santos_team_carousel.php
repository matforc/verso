<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
/**
 * Shortcode attributes
 * @var $atts
 * @var $el_class
 * Shortcode class
 * @var $this WPBakeryShortCode_santos_testimonial_carousel
 */
 
$output = $css = '';
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );

$pagination_color =  '';

extract( $atts );


$css_class = 'santos_team_carousel wpb_content_element ' .$el_class ;

$output .= ' <div class="teamSliderContainer"> <div class="'.esc_attr($css_class).'"><div class="owl-carousel owl-theme teamSlider">';
                   	
				$output .= do_shortcode($content);
					
			    $output .= ' </div></div></div>';
				
echo do_shortcode($output);