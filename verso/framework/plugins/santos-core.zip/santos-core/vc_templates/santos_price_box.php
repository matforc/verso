<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
/**
 * Shortcode attributes
 * @var $atts
 * @var $featured
 * @var $bg_color
 * @var $price_color
 * @var $title
 * @var $content
 * @var $title_color
 * @var disable_title_sep
 * @var $desc_color
 * @var options_color
 * @var $options
 * @var $options_sep_color
 * @var $btn_title
 * @var $link
 * @var $btn_text_color 
 * @var $btn_bg_color 
 * @var $animation
 * @var disable_hover
 * @var $el_class
 * Shortcode class
 * @var $this WPBakeryShortCode_santos_icon_box
 */
 
  

$price =  $symbol = $title = $disable_title_sep = $options = $options_sep_color = $featured = $el_class = $disable_hover = $animation  = $data_aos = '';

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$id = uniqid();

// Order of replacement
$order   = array("\r\n", "\n", "\r", "<br/>", "<br>");
$replace = '|';
// Processes \r\n's first so they aren't converted twice.
$str = str_replace($order, $replace, $options);
$lines = explode("|", $str);

			
$css_class = 'santos_info_box wpb_content_element ' .$el_class ;

if($animation !=''){
$data_aos .= 'data-aos='.$animation;
}



$custom_style ='';
$custom_style .= '
#santos_pricebox_'.$id.' .priceNumber{color: '.$price_color.';}
#santos_pricebox_'.$id.' .priceTitle{color: '.$title_color.';}
#santos_pricebox_'.$id.' p{color: '.$desc_color.';}
#santos_pricebox_'.$id.' li{color: '.$options_color.';}
#santos_pricebox_'.$id.' .priceBox {background: '.$bg_color.';}
#santos_pricebox_'.$id.' .priceBox ul li {border-bottom: 1px solid '.$options_sep_color.';}
'; 
santos_add_to_global_styles($custom_style);


?>
 <!-- Price table -->
<div id="santos_pricebox_<?php echo esc_attr( $id ); ?>" class="<?php echo esc_attr( trim( $css_class ) ); ?>"  <?php echo esc_attr( $data_aos ); ?>>
		<div class="priceBox <?php if($featured){ echo 'premiumBox'; }   if($disable_hover == 'true'){ echo 'noHover'; }  ?>">
                    <span class="priceNumber"><?php echo esc_attr( $price ); ?><span><?php echo esc_attr( $symbol ); ?></span></span>
                    <h4 class="priceTitle"><?php echo esc_attr( $title ); ?></h4>
					
					<?php
					if (  $disable_title_sep != 'true' ) {
					?>
                    <hr />
					<?php } ?>
                    <p><?php echo esc_attr( $content ); ?></p>

					
					 <?php
					 
					 if($options !== ''){
						 
						 echo '<br />	 <ul>';

						 foreach($lines as $line)
						{

								echo '<li>'.strip_tags($line).'</li>';
						}
						
						echo '</ul>';
						
					 }	

					
					
					?>
						

					
                    <div class="h-50"></div>
				<?php
				echo do_shortcode( '[santos_button link="'. $link . '" title="'. $btn_title .'" text_color="'.$btn_text_color.'" bg_color="'.$btn_bg_color.'" align="left"]' );
				?>
                  
                </div>
			
</div>
 <!-- / Price table -->
 
