<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
/**
 * Shortcode attributes
 * @var $atts
 * @var $col
 * @var $disable_radius
 * @var $el_class
 * Shortcode class
 * @var $this WPBakeryShortCode_santos_testimonial_carousel
 */
 
$output = $css = $disable_radius = '';
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );

$id = uniqid();

extract( $atts );

$custom_style ='';
if($disable_radius == 'true'){
$custom_style .= '
#santos_gallery_'.$id.' .gallery_item_holder .recentDiv {
    border-radius: 0;
}'; 

santos_add_to_global_styles($custom_style);	
}



$css_class = 'santos_gallery santos_content_element '.$col.' ' .$el_class ;

$output .= '<!-- gallery section -->
        <div id="santos_gallery_'. esc_attr( $id ).'" class="'.esc_attr($css_class).' gallery">
             <div class="gallery-div">
                        <div class="gallery">
                            <!-- gallery_container -->
                            <div class="gallery_container clearfix">';
							
					$output .= do_shortcode($content);


						 $output .= '</div>
                            <!-- end gallery_container -->
                        </div>
                        <!-- gallery -->
                    </div>
               <!-- end gallery div -->
        </div>
        <!-- / projects section -->';
				
echo do_shortcode($output);