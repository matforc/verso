<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
/**
 * Shortcode attributes
 * @var $atts
 * @var $icon_ion
 * @var $icon_color
 * @var $icon_size 
 * @var $icon_align
 * Shortcode class
 * @var $this WPBakeryShortCode_santos_icons
 */
$icon_class = $icon_ion = $icon_align = $icon_color = $icon_size =  '';
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );





$icon_class = $icon_ion;

?>

<div class="santos_icon_wrap text-<?php echo esc_attr($icon_align); ?> "><i class="<?php echo esc_attr( $icon_class ); ?> " style="color:<?php echo esc_attr($icon_color); ?>; font-size:<?php echo esc_attr($icon_size); ?>px;" ></i>  </div>