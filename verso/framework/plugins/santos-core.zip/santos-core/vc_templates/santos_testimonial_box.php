<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
/**
 * Shortcode attributes
 * @var $atts
 * @var $bg_color
 * @var $quote
 * @var $quote_color
 * @var $name
 * @var $name_color
 * @var $position
 * @var $position_color
 * Shortcode class
 * @var $this WPBakeryShortCode_santos_testimonial_carousel_item
 */
 
$quote = $quote_color = $name = $name_color = $position = $position_color =  '';
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$default_src = get_template_directory_uri() .'/img/no_image.png' ;

$img_id = preg_replace( '/[^\d]/', '', $image );
$img_url = wp_get_attachment_image_src( $img_id, 'thumbnail' );

$image_src = $img_url[0] ? esc_attr( $img_url[0] ) : $default_src;


$output = ' <div style="background-color:'.esc_attr($bg_color).';">
            <div class="testimonialsBox text-center">
                <h4 class="quoteIcon">“</h4>
                <h4 style="color:'.esc_attr($quote_color).';">'.$quote.'</h4>
                <div class="h-30"></div>
                <img src="'.$image_src.'" class="img-circle" width="80" alt="" />
                <h4 style="color:'.esc_attr($name_color).';">'.esc_attr($name).'</h4>
                <h5 style="color:'.esc_attr($position_color).';">'.esc_attr($position).'</h5>
            </div>
        </div>';


echo do_shortcode($output);