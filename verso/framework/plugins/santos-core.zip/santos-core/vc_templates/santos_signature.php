<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
/**
 * Shortcode attributes
 * @var $atts
 * @var $width
 * @var $image
 * @var $align
 * @var $this WPBakeryShortCode_santos_signature
 */
 
$width = $align = $image =  '';
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );


if(is_numeric($image)) {
$image_src =  wp_get_attachment_image_src( $image,'full' );
} else {
$image_src = $image;
}

if(empty($align) ){ $align = 'left';}

?>
<div class="signature_wrap" style="width:100%;">
<img src="<?php echo esc_url($image_src[0]); ?>" class="img-responsive align<?php echo esc_attr($align); ?>" <?php if($width){ ?> width="<?php echo esc_attr( $width ); ?>" <?php } ?>  alt="" />
</div>
