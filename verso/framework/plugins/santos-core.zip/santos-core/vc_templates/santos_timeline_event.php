<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
/**
 * Shortcode attributes
 * @var $atts
 * @var $title_color
 * @var $subtitle_color
 * @var $description_color
 * Shortcode class
 * @var $this WPBakeryShortCode_santos_testimonial_carousel
 */
 
$output = $css = '';
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );

$pagination_color =  '';

extract( $atts );


$css_class = 'santos_timeline_event wpb_content_element ' .$el_class ;

$output .= ' <!-- time line --> <div class="'.esc_attr($css_class).'"><ul class="timeline">';
                   	
				$output .= do_shortcode($content);
					
			    $output .= ' </ul></div><!-- / time line  -->';
				
echo do_shortcode($output);