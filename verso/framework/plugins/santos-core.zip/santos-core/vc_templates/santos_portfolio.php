<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
/**
 * Shortcode attributes
 * @var $atts
 * @var $enable_filter
 * @var $filter_bg_color
 * @var $style
 * @var $column
 * @var $enable_spacing
 * @var $spacing_limit
 * @var $order
 * @var $orderby
 * @var $items_per_page
 * @var $hover_color_style
 * @var $hover_custom_color
 * @var $hover_opacity
 * @var $pagination
 * Shortcode class
 * @var $this WPBakeryShortCode_santos_portfolio
 */
 



 
$column=4;
$hover_custom_color = 'rgba(0, 0, 0, .8)';
$pagination = $filter_bg_color = '';
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$id = uniqid();

 $categories = get_categories('title_li=&orderby=name&hide_empty=1&taxonomy=santos-portfolio-category');
 $items_per_page = $items_per_page ? $items_per_page : -1 ;
 
 
 $santos_options = get_option('santos_options'); 



 
 
	if($hover_color_style == 'theme_color'){
		
		if (isset($santos_options['theme_color']) ) {
		$hover_color = santos_hex2rgb($santos_options['theme_color']);
		$hover_color = 'rgba('.$hover_color[0].','.$hover_color[1].','.$hover_color[2].','.$hover_opacity.')';
		}
	
				
	}else{
		
		$hover_color = $hover_custom_color;
		
	}
	
	
			if ( get_query_var('paged') ) {
				  $paged = get_query_var('paged');
				} elseif ( get_query_var('page') ) {
				  $paged = get_query_var('page');
				} else {
				  $paged = 1;
				}

 
	$args=array(
         'post_type' => 'santos-portfolio',
		 'post_status' => 'publish',
		 'posts_per_page' => $items_per_page,
		 'paged'=> $paged
     );
    
	if ($orderby) {
	$args['orderby'] = $orderby;
	}
	if ($order) {
	$args['order'] = $order;
	}
    
    
	query_posts($args);
	
$custom_style ='';
$custom_style .= '
#santos_portfolio_projects_'.$id.' .portfolio_item_hover{background-color: '.$hover_color.';}
'; 

$item_space = 'no_space';
if($enable_spacing == 'true'){ 
	$item_space = 'item_space';
	if($style=='grid'){
	$custom_style .= '
	#santos_portfolio_projects_'.$id.' .portfolio_item_holder{padding:0 15px;margin-bottom:30px;}
	'; 	
	}

	if($style=='masonry'){
		$custom_style .= '
	#santos_portfolio_projects_'.$id.' .portfolio_item_holder{padding:20px 10px;}
	'; 
	}

}


if($filter_bg_color !=''){	
$custom_style .= '
#santos_portfolio_projects_'.$id.' .portfolio-filters{background:'.$filter_bg_color.';}
'; 
}


santos_add_to_global_styles($custom_style);

if($column=='6' ){$cols=2;}
if($column=='4'){$cols=3;}
if($column=='3'){$cols=4;}

?>


    <!-- projects section -->
    <div id="santos_portfolio_projects_<?php echo esc_attr( $id ); ?>" class="projects santos_projects">
      
            <!-- main container -->
            <div class="main-container pt-30 clearfix">
                <!-- portfolio div -->
                <div class="portfolio-div">
                    <div class="portfolio">
                        <!-- portfolio_filter -->
						
						<?php
			if ( ! empty( $enable_filter ) ) {						
                
                if($categories){
				?>
				      <div class="categories-grid portfolio-filters">
                            <nav class="categories">
							
					<button  id="sort-portfolio"><span>Sort Portfolio</span> <i class="ion-ios-arrow-down"></i></button>
					
                                <ul class="portfolio_filter">
                                    <li><a href="" class="active all" data-filter="*"><?php esc_attr_e('All', 'santos')  ?></a></li>
									
							<?php
						foreach($categories as $category){
						?>
							<li><a href="" data-filter=".<?php echo esc_attr($category->slug); ?>"><?php echo esc_attr($category->cat_name); ?></a></li>
						<?php	
						}
						?>
                                  
                                </ul>
                            </nav>
                        </div>
						
					
				<?php
				}				
			 }
			?>
			 <!-- portfolio_filter -->

             <!-- portfolio_container -->
						
       <div  class="<?php if($style !== 'default'){echo 'no-padding';} ?> portfolio_container <?php echo esc_attr( $style ); ?>  <?php  echo esc_attr($item_space); ?>  <?php echo esc_attr($pagination); ?> clearfix" data-cols="<?php echo esc_attr($cols); ?>">
						
						
		<?php

			if(have_posts()) : while(have_posts()) : the_post();
			
			if ( has_post_thumbnail()) {
				$imgsrc = wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), "santos_portfolio_thumb" );
			}
			
			$item_categories = get_the_terms( get_the_ID () , 'santos-portfolio-category' );

			$cat_slug = '';
			$cat_name = '';

			if(is_object($item_categories) || is_array($item_categories))
	
					{
                
                        $i=0;
                       
						foreach ($item_categories as $cat)
						{
							$cat_slug .= $cat->slug .' ' ;
                            
                            
							if($i!=0){ $cat_name .='/ ';}
				            $cat_name .= $cat->name .' ' ;
							
                           
                        $i++;    
					}
                  

            }
			
			
			if($style == 'grid'){
		?>
		
		

							 <!-- single work -->
                            <div class="col-md-<?php echo $column; ?> col-sm-6 portfolio_item_holder <?php echo esc_attr($cat_slug); ?>">
                                <a href="<?php the_permalink(); ?>" class="portfolio_item"> <img src="<?php echo esc_url($imgsrc[0]); ?>" alt="image" class="img-responsive" />
                                    <div class="portfolio_item_hover">
                                        <div class="portfolio-border clearfix">
                                            <div class="item_info"> <span><?php the_title(); ?></span> <em><?php echo esc_attr($cat_name); ?></em> </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <!-- end single work -->
							

		<?php 	
		}else if($style == 'masonry'){
			
			 $image_size  = rwmb_meta( 'santos_project_masonry_image_size', 'type=select' );
			 
			 
		
			
			if($image_size == "large_width"){ 
            $thumb_size ='santos_wide';
            $item_width = 'col-md-6';
			}
			else{
			$thumb_size ='santos_default';
            $item_width = 'col-md-3';
			}
		
		

			
			
		?>	
							<!-- single work -->
                            <div class="<?php echo $item_width; ?> col-sm-6 portfolio_item_holder <?php echo esc_attr($cat_slug); ?>">
                                <a href="<?php the_permalink(); ?>" class="portfolio_item"> <img src="<?php echo esc_url($imgsrc[0]); ?>" alt="image" class="img-responsive" />
                                    <div class="portfolio_item_hover">
                                        <div class="portfolio-border clearfix">
                                            <div class="item_info"> <span><?php the_title(); ?></span> <em><?php echo esc_attr($cat_name); ?></em> </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <!-- end single work -->
							
			<?php				
			
		} else{
			
		?>
		
		

							<!-- single work -->
                            <div class="col-md-<?php echo $column; ?> col-sm-6 portfolio_item_holder <?php echo esc_attr($cat_slug); ?>">
                                <!-- recent item -->
                                <div class="recentDiv">
                                    <a href="<?php the_permalink(); ?>">
                                        <img src="<?php echo esc_url($imgsrc[0]); ?>" alt="" class="img-responsive" />
                                        <div class="recentTitleDiv">
                                            <h3><?php the_title(); ?></h3>
                                            <span><?php echo esc_attr($cat_name); ?></span>
                                        </div>
                                    </a>
                                </div>
                                <!-- / recent item -->
                            </div>
                            <!-- end single work -->

		<?php 	
		
			
		}
		
		endwhile;endif;  
		
		
		?>

                        </div>
                        <!-- end portfolio_container -->
				<?php		
						
				if($pagination == 'load_more' ){
				?>
				<div class="port_load_more_button_holder">
				<div class="port_load_more_button">
				<span class="load-more"  data-rel="<?php echo $wp_query->max_num_pages; ?>"  ><?php echo get_next_posts_link(esc_html__('Show more',  'santos')) ; ?></span></div>
                <div class="port_load_more_button_loading" ><a href="javascript: void(0)" ></a></div>
				
				</div>
				<?php
				}
				?>		
						
                    </div>
                    <!-- portfolio -->
                </div>
                <!-- end portfolio div -->
            </div>
			
			<?php wp_reset_query();   ?>
			
            <!-- end main container -->
       
       
    </div>
    <!-- / projects section -->