<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
/**
 * Shortcode attributes
 * @var $atts
 * @var $title
 * @var $number
 * @var $text_color
 * @var  enable_bg
 * @var $image
 * @var $this WPBakeryShortCode_santos_section_number
 */
 
$title = $number = $text_color =  $style = '';
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$wrapper_style = array();

if($enable_bg == 'true'){
$default_src = get_template_directory_uri() .'/img/no_image.png' ;
$img_url = wp_get_attachment_image_src( $image, 'full');	
$image_src = $img_url[0] ? esc_attr( $img_url[0] ) : $default_src;
$wrapper_style[] = 'background:url('. esc_url( $image_src ).')';
}

?>

<div class="step_box <?php if($enable_bg == 'true'){ echo 'bg'; } ?>" <?php echo 'style="' . implode( ' ', $wrapper_style ) . '"'; ?>>
<?php if($enable_bg == 'true'){ echo '<div class="boxOverlay"></div>'; } ?>
<div class="step_box_content">
<h3 class="numberH3" style="color:<?php echo esc_attr( $text_color ); ?>;"><?php echo esc_attr( $number ); ?></h3> <h3 style="color:<?php echo esc_attr( $text_color ); ?>;"><?php echo esc_attr( $title ); ?></h3>
<p style="color:<?php echo esc_attr( $text_color ); ?>;"><?php echo esc_attr( $content ); ?></p>
</div>
</div>
					