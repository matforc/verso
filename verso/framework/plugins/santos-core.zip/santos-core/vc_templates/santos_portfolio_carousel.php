<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
/**
 * Shortcode attributes
 * @var $atts
 * @var $order
 * @var $orderby
 * @var $items_per_page
 * Shortcode class
 * @var $this WPBakeryShortCode_santos_portfolio
 */
 


$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );


 
 $items_per_page = $items_per_page ? $items_per_page : -1 ;
 
 

 
	$args=array(
         'post_type' => 'santos-portfolio',
		 'post_status' => 'publish',
		 'posts_per_page' => $items_per_page,
     );
    
	if ($orderby) {
	$args['orderby'] = $orderby;
	}
	if ($order) {
	$args['order'] = $order;
	}
    
    
	query_posts($args);

?>


    <!-- projects section -->
	
	<div class="owl-carousel owl-theme recent">
			
			
	<?php

			if(have_posts()) : while(have_posts()) : the_post();
			
			if ( has_post_thumbnail()) {
				$imgsrc = wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), "full" );
			}
			
			$item_categories = get_the_terms( get_the_ID () , 'santos-portfolio-category' );

			$cat_slug = '';
			$cat_name = '';

			if(is_object($item_categories) || is_array($item_categories))
	
					{
                
                        $i=0;
                       
						foreach ($item_categories as $cat)
						{
							$cat_slug .= $cat->slug .' ' ;
                            
                            
							if($i!=0){ $cat_name .='/ ';}
				            $cat_name .= $cat->name .' ' ;
							
                           
                        $i++;    
					}
                  

            }
	?>			
			
			
                <!-- recent item -->
                <div class="recentDiv">
                    <a href="<?php the_permalink(); ?>">
                        <img src="<?php echo esc_url($imgsrc[0]); ?>" alt="" class="img-responsive" />
                        <div class="recentTitleDiv">
                            <h3><?php the_title(); ?></h3>
                            <span><?php echo esc_attr($cat_name); ?></span>
                        </div>
                    </a>
                </div>
                <!-- / recent item -->

				
		<?php 	
		
		
		
		endwhile;endif;  
		wp_reset_query();  
		
		?>
		

    </div>
			