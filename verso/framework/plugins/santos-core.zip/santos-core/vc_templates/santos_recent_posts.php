<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
/**
 * Shortcode attributes
 * @var $atts
 * @var $order
 * @var $orderby
 * @var $items_per_page
 * @var $ignore_post_format
 * @var $content_bg
* @var $post_excerpt_length
 
 * Shortcode class
 * @var $this WPBakeryShortCode_santos_blog
 */
 

$ignore_post_format = $post_excerpt_length = '';

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$post_excerpt_length = $post_excerpt_length ? $post_excerpt_length : 18;



$id = uniqid();

 $categories = get_categories('title_li=&orderby=name&hide_empty=1&taxonomy=portfolio-category');
 $items_per_page = $items_per_page ? $items_per_page : -1 ;
 
 
	$args=array(
         'post_type' => 'post',
		 'post_status' => 'publish',
		 'posts_per_page' => $items_per_page,
     );
    
	if ($orderby) {
	$args['orderby'] = $orderby;
	}
	if ($order) {
	$args['order'] = $order;
	}
    
    
	query_posts($args);
	
	
	$custom_style ='';
	
	if(!empty($content_bg)){
	$custom_style .= '
	#santos_recent_posts_'.$id.' .newsBox{background:'.$content_bg.';}
	';
	santos_add_to_global_styles($custom_style);
	}	
	
?>
	<div id="blogs">
	<div id="santos_recent_posts_<?php echo esc_attr( $id ); ?>" class="santos_recent_posts blog_container clearfix ">
					
		<?php

			if(have_posts()) : while(have_posts()) : the_post();
			
			

				
			
		?>
		
		
              <!-- single post -->
				<div class="col-md-4" data-aos="fade-up" data-aos-once="true">
                     
					
				<?php
					if($ignore_post_format != 'true'){
						if('' == get_post_format()){
						include( SANTOS_CORE_DIR .'/includes/post-format/content.php' ); 
						}else if('audio' == get_post_format()){
						include( SANTOS_CORE_DIR .'/includes/post-format/content-audio.php' ); 
						}else if('quote' == get_post_format()){
						include( SANTOS_CORE_DIR .'/includes/post-format/content-quote.php' ); 
						}else if('video' == get_post_format()){
						include( SANTOS_CORE_DIR .'/includes/post-format/content-video.php' ); 
						}
					}else{
						
											
					echo '<div class="newsBox">';

					$imgsrc = '';
					if ( has_post_thumbnail() ) { 
					$imgsrc = wp_get_attachment_image_src( get_post_thumbnail_id(get_the_id()), "santos_default" ); 
											
						echo '<a href="'. get_the_permalink().'"><img src="'. $imgsrc[0].' " alt="image" class="img-responsive" /></a>';
										
					} 
						 

				 

				echo '<div class="contentBlogDiv">
					<a class="newsDate">'. get_the_date() .'</a>
					
					<a href="'. get_the_permalink().'">
					<h4>'. get_the_title().'</h4>
					</a>
					<p>'.  santos_excerpt_limit($post_excerpt_length) .'</p>

					</div></div>';	
						
					}	
				?>

				

                    
                    </div>
					
                    <!-- end single post --> 
					

		<?php
		
		endwhile;endif;  
		wp_reset_query();  
		
		?>
		
		
      </div></div>
       <!-- end  blog -->
                   
 
