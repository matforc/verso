<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
/**
 * Shortcode attributes
* @var $atts
* @var $image
* @var $name
* @var $name_color
* @var $position
* @var $position_color
* @var $team_social_icon_1
* @var $team_social_icon_1_link
* @var $team_social_icon_1_target
* @var $team_social_icon_2
* @var $team_social_icon_2_link
* @var $team_social_icon_2_target
* @var $team_social_icon_3
* @var $team_social_icon_3_link
* @var $team_social_icon_3_target
* @var $team_social_icon_4
* @var $team_social_icon_4_link
* @var $team_social_icon_4_target
* @var $team_social_icon_5
* @var $team_social_icon_5_link
* @var $team_social_icon_5_target
* @var $icon_color
* @var $animation
* @var $animation_delay
* @var $el_class
* Shortcode class
 * @var $this WPBakeryShortCode_santos_testimonial_carousel_item
 */
 
$output = $image = $name = $name_color = $position = $position_color =  $icon_color = $el_class = $animation =  $data_aos = '';
$team_social_icon_1 = $team_social_icon_1_link  =  '';
$team_social_icon_2 = $team_social_icon_2_link  =  '';
$team_social_icon_3 = $team_social_icon_3_link  =  '';
$team_social_icon_4 = $team_social_icon_4_link  =  '';
$team_social_icon_5 = $team_social_icon_5_link  =  '';

$team_social_icon_1_target = $team_social_icon_2_target = $team_social_icon_3_target = $team_social_icon_4_target = $team_social_icon_5_target = '_blank';

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$default_src = get_template_directory_uri() .'/img/no_image.png' ;

$img_id = preg_replace( '/[^\d]/', '', $image );
$img_url = wp_get_attachment_image_src( $img_id, 'full' );

$image_src = $img_url[0] ? esc_attr( $img_url[0] ) : $default_src;
	

$css_class = 'santos_team_item ' .$el_class ;



  $output .='<div class="'. esc_attr( trim( $css_class ) ).' teamSliderItem">
                        <div class="col-md-4">
                            <img src="'. esc_url($image_src).'" class="img-responsive" alt="" />
                        </div>
                        <div class="col-md-8 flex-self">
                            <div class="teamPaddingSlider">
							 <h3 style="color:'.esc_attr( $name_color ).';">'. esc_attr( $name ) .'</h3>
                             <h5 style="color:'.esc_attr( $position_color ).';">'. esc_attr( $position ).'</h5>
                          
                                <div class="h-30"></div>
                                <p>Hanc ergo intuens debet institutum illud quasi signum absolvere. Quoniam
                                    <br /> si dis placet, ab Epicuro loqui discimus. </p>
						
                                <ul>';
								
        if($team_social_icon_1 != "") {
            $output .=  '<li><a href="' . esc_attr($team_social_icon_1_link) . '" target="' . esc_attr($team_social_icon_1_target) . '" style="color:'.esc_attr($icon_color).';border-color:'.esc_attr($icon_color).';" ><i class="ion-social-'. esc_attr($team_social_icon_1) .'"></i></a></li>';
        }

        if($team_social_icon_2 != "") {
             $output .=  '<li><a href="' . esc_attr($team_social_icon_2_link) . '" target="' . esc_attr($team_social_icon_2_target) . '"  style="color:'.esc_attr($icon_color).';border-color:'.esc_attr($icon_color).';"><i class="ion-social-'. esc_attr($team_social_icon_2) .'"></i></a></li>';
        }

        if($team_social_icon_3 != "") {
             $output .=  '<li><a href="' . esc_attr($team_social_icon_3_link) . '" target="' . esc_attr($team_social_icon_3_target) . '"  style="color:'.esc_attr($icon_color).';border-color:'.esc_attr($icon_color).';" ><i class="ion-social-'. esc_attr($team_social_icon_3) .'"></i></a></li>';
        }

        if($team_social_icon_4 != "") {
              $output .=  '<li><a href="' . esc_attr($team_social_icon_4_link) . '" target="' . esc_attr($team_social_icon_4_target) . '"  style="color:'.esc_attr($icon_color).';border-color:'.esc_attr($icon_color).';"><i class="ion-social-'. esc_attr($team_social_icon_4) .'"></i></a></li>';
        }

        if($team_social_icon_5 != "") {
             $output .=  '<li><a href="' . esc_attr($team_social_icon_5_link) . '" target="' . esc_attr($team_social_icon_5_target) . '"  style="color:'.esc_attr($icon_color).';border-color:'.esc_attr($icon_color).';"><i class="ion-social-'. esc_attr($team_social_icon_5) .'"></i></a></li>';
        }
		
		
				
				
				
                             $output .='</ul>
                            </div>
                        </div>
                    </div>
                    <!-- / Team slider item -->';
					
					
					



echo do_shortcode($output);