<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
/**
 * Shortcode attributes
 * @var $atts
 * @var $icon_ion
 * @var $icon_color
 * @var $icon_size
 * @var $icon_position
 * @var $icon_align
 * @var $title
 * @var $content
 * @var $title_color
 * @var $text_color
 * @var $image
 * @var $bg_color
 * @var $enable_hover
 * @var $hover_bg_color
 * @var $animation
 * @var $el_class
 * Shortcode class
 * @var $this WPBakeryShortCode_santos_icon_box
 */
$image = $bg_color = $icon_class = $icon_ion = $icon_position = $icon_align = $title = $icon_color = $icon_size = $title_color = $text_color = $enable_hover = $hover_bg_color = $el_class = $animation = $data_aos = '';
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );


$id = uniqid();

$icon_class = $icon_ion;

$default_src = get_template_directory_uri() .'/img/no_image.png' ;
$img_url = wp_get_attachment_image_src( $image, 'medium');	
$image_src = $img_url[0] ? esc_attr( $img_url[0] ) : $default_src;


$santos_options = get_option('santos_options'); 
$theme_color = isset($santos_options['theme_color']) ? $santos_options['theme_color'] : '#425bb5'; 
$icon_color = !empty($icon_color) ? $icon_color : $theme_color;
			
$css_class = 'santos_icon_box wpb_content_element ' .$el_class ;

if($animation !=''){
$data_aos .= 'data-aos='.$animation;
}

$custom_style ='';
$custom_style .= '
#santos_iconbox_'.$id.' .iconBox.hover-bg:not(.iconBG):hover{background:'.$hover_bg_color.';}
'; 

if($img_url[0] != ''){
$custom_style .= '
#santos_iconbox_'.$id.' .iconBox.iconBG{
	background: -webkit-linear-gradient( rgba(0, 0, 0, .5), rgba(0, 0, 0, .5)), url('.$image_src.');
    background: linear-gradient( rgba(0, 0, 0, .5), rgba(0, 0, 0, .5)), url('.$image_src.');
	}'; 	
}
if($bg_color != ''){
$custom_style .= '
#santos_iconbox_'.$id.' .iconBox.icon_bgcolor{
    background: '.$bg_color.';
	}'; 	
}

santos_add_to_global_styles($custom_style);

?>
<div id="santos_iconbox_<?php echo esc_attr( $id ); ?>" class="<?php echo esc_attr( trim( $css_class ) ); ?>"  <?php echo esc_attr( $data_aos ); ?>>


	
   <div class="iconBox <?php if($enable_hover) {echo 'hover-bg'; }  if($icon_position == 'top'){ echo ' text-'.$icon_align.' icon-top'; }  if($img_url[0] != ''){echo ' iconBG '; }  if($bg_color !='' ){echo ' icon_bgcolor '; } ?>">
				<i class="<?php echo esc_attr( $icon_class ); ?> " style="color:<?php echo esc_attr($icon_color); ?>; font-size:<?php echo esc_attr($icon_size); ?>px;" ></i>
                <div class="contentDiv">
                <h3 <?php if(!empty($title_color)){?> style="color:<?php echo esc_attr($title_color); ?>" <?php } ?>><?php echo esc_attr( $title ); ?></h3>
                <p  <?php if(!empty($text_color)){ ?> style="color:<?php echo esc_attr($text_color); ?>" <?php } ?>><?php echo esc_attr( $content ); ?> </p> 
                 </div>
    </div>

	
</div>