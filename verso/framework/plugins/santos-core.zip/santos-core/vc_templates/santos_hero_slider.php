<?php

$args = array(
	'style' => 'style_1',
	 'parallax' => 'parallax',
     'bg_color' => '',
	 "btn_title_color"         => "",
	 "btn_bg_color"         => "",
	 "text_width"  => "600",
);

$output = "";

extract(shortcode_atts($args, $atts));

wp_enqueue_script( 'flexslider');
wp_enqueue_style( 'flexslider');

$id = uniqid();
$custom_style ='';
$custom_style .= '
#santos_hero_slider_'.$id.'{background:'.$bg_color.';}
#santos_hero_slider_'.$id.' .interTextDiv { max-width: '.$text_width.'px;}
#santos_hero_slider_'.$id.' .btn{color:'.$btn_title_color.';background:'.$btn_bg_color.';}
'; 
santos_add_to_global_styles($custom_style);




$output = '<!-- Hero Slider -->
	<div class="santos_hero_slider_wrap clearfix">
    <section id="santos_hero_slider_'. esc_attr( $id ).'" class="santos_hero_slider '.$parallax.' '.$style.'">
        <div class="flexslider clearfix">
            <ul class="slides">';
			
		$output .= do_shortcode($content);
            


            $output .= '</ul>
        </div>
    </section></div>
    <!-- / Hero Slider -->';
	
	


echo do_shortcode($output);