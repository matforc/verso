<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
/**
 * Shortcode attributes
 * @var $atts
 * @var $image
 * @var $align
 * @var $title
 * @var $content
 * @var $title_color
 * @var $text_color
 * @var $animation
 * @var $el_class
 * Shortcode class
 * @var $this WPBakeryShortCode_santos_icon_box
 */
$image = $align = $title = $title_color = $text_color = $el_class = $animation = $data_aos = '';
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );


$default_src = get_template_directory_uri() .'/img/no_image.png' ;
$img_url = wp_get_attachment_image_src( $image, 'full');	
$image_src = $img_url[0] ? esc_attr( $img_url[0] ) : $default_src;
		
$css_class = 'santos_image_box wpb_content_element text-'.$align.' ' .$el_class ;

if($animation !=''){
$data_aos .= 'data-aos='.$animation;
}

?>
<div class="<?php echo esc_attr( trim( $css_class ) ); ?>"  <?php echo esc_attr( $data_aos ); ?>>
  <div class="imgBox">
                    <img src="<?php echo esc_url($image_src); ?>" class="img-responsive img-rounded" alt="" />
                    <div class="contentDiv">
                        <div class="h-20"></div>
                        <h4 <?php if(!empty($title_color)){?> style="color:<?php echo esc_attr($title_color); ?>" <?php } ?>> <?php echo esc_attr( $title ); ?></h4>
                        <p <?php if(!empty($text_color)){ ?> style="color:<?php echo esc_attr($text_color); ?>" <?php } ?>> <?php echo esc_attr( $content ); ?> </p>
                    </div>
	</div>
</div>