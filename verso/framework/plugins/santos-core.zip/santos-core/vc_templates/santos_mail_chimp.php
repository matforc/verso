<?php
if ( ! defined( 'ABSPATH' ) ) {
die( '-1' );
}
/**
* Shortcode attributes
* @var $atts
* @var $url
* @var $submit_msg
* @var $success_msg
* @var $error_invalid_value
* @var $error_invalid_sign
* @var $error_invalid_domain
* @var $error_invalid_username
* @var $error_invalid_email
* @var $this WPBakeryShortCode_santos_mail_chimp
*/


$output = $url = $submit_msg = $success_msg = $error_invalid_value = $error_invalid_sign = $error_invalid_domain = $error_invalid_username = $error_invalid_email =  '';
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

wp_enqueue_script( 'santos-ajaxchimp', get_template_directory_uri() . '/js/jquery.ajaxchimp.min.js', array( 'jquery' ), '1.0', true );

$output .= '<!-- ===== MAILCHIMP FORM STARTS ===== -->
	
	<form class="santos_mail_chimp subscription-form mailchimp inputSubscribeDiv" data-mailchimp-url="'.$url.'" data-submit-msg="'.$submit_msg.'" data-success="'.$success_msg.'"  data-error-value="'.$error_invalid_value.'" data-error-sign="'.$error_invalid_sign.'" data-error-domain="'.$error_invalid_domain.'" data-error-username="'.$error_invalid_username.'" data-error-email="'.$error_invalid_email.'"  >

				<label for="subscriber-email"></label>
				 <div class="notify">
						<input type="email" name="subscribe" class="form-control " placeholder="'.__('Enter your Email','santos').'">
                        <button class="btn btn-blue" type="submit">'.__('Subscribe','santos').'</button>
                 </div> 
				 
				 <!-- SUBSCRIPTION SUCCESSFUL OR ERROR MESSAGES -->
				<span class="subscription-success"> </span>
				<span class="subscription-error"> </span>
				 
				 </form><!-- /END MAILCHIMP FORM Ends -->';

echo do_shortcode($output);
