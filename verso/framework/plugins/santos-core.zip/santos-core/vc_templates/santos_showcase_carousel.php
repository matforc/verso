<?php

$args = array(
     'slide_items' => '3'
);

$output = "";

extract(shortcode_atts($args, $atts));


$output = '<div class="owl-carousel owl-theme showcase santos_showcase_carousel" data-slide-items="'.$slide_items.'">';

$output .= do_shortcode($content);

$output .= '</div><!-- showcase end -->';

echo do_shortcode($output);