<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
/**
 * Shortcode attributes
 * @var $atts
 * @var $map_latitude
 * @var $map_longitude
 * @var $map_height
 * @var $map_width
 * @var $map_zoom
 * @var $map_marker
 * @var $map_key
*/



extract(shortcode_atts(array(
		//"id" => "map",
		"map_width" => "100%",
		"map_height" => "400px",
		"map_latitude" => "51.5255069",
		"map_longitude" => "-0.0836207",
		"map_zoom" => "14",
		"map_marker" => "",		
), $atts));
			
			


$default_src = get_template_directory_uri() .'/img/cd-icon-location.svg' ;


$img_id = preg_replace( '/[^\d]/', '', $map_marker );
$img_url = wp_get_attachment_image_src( $img_id, 'full' );

$marker_src = $img_url[0] ? esc_attr( $img_url[0] ) : $default_src;

$map_key = '';
$santos_options = get_option('santos_options');
if(isset($santos_options['google_map_key']) && $santos_options['google_map_key'] !="" ){	
	$map_key = $santos_options['google_map_key'];
}
			

?>

<div class="map-container no-padding" style="height:<?php esc_attr_e($map_height); ?>;width:<?php esc_attr_e($map_width); ?>">
    <div id="cd-google-map">
        <div id="google-container"></div>
        <div id="cd-zoom-in"><i class="ion-ios-plus-empty"></i></div>
        <div id="cd-zoom-out"><i class="ion-ios-minus-empty"></i></div>
    </div>
</div>

<script src="https://maps.googleapis.com/maps/api/js?key=<?php echo esc_attr( $map_key ); ?>"></script>
<script>

    jQuery(document).ready(function($){
	//set your google maps parameters
	var latitude = <?php echo esc_attr( $map_latitude ); ?>,
		longitude = <?php echo esc_attr( $map_longitude ); ?>,
		map_zoom = <?php echo esc_attr( $map_zoom ); ?>;

	//google map custom marker icon - .png fallback for IE11
	var is_internetExplorer11= navigator.userAgent.toLowerCase().indexOf('trident') > -1;
	var marker_url =  '<?php echo esc_url($marker_src); ?>';
	

	
		
    	//we define here the style of the map
	var style= [ 
		
        {
        "featureType": "water",
            "elementType": "geometry",
            "stylers": [{
                "color": "#e9e9e9"
                    }, {
                "lightness": 17
                    }]
                }, {
            "featureType": "landscape",
            "elementType": "geometry",
            "stylers": [{
                "color": "#f5f5f5"
                    }, {
                "lightness": 20
                    }]
                }, {
            "featureType": "road.highway",
            "elementType": "geometry.fill",
            "stylers": [{
                "color": "#ffffff"
                    }, {
                "lightness": 17
                    }]
                }, {
            "featureType": "road.highway",
            "elementType": "geometry.stroke",
            "stylers": [{
                "color": "#ffffff"
                    }, {
                "lightness": 29
                    }, {
                "weight": 0.2
                    }]
                }, {
            "featureType": "road.arterial",
            "elementType": "geometry",
            "stylers": [{
                "color": "#ffffff"
                    }, {
                "lightness": 18
                    }]
                }, {
            "featureType": "road.local",
            "elementType": "geometry",
            "stylers": [{
                "color": "#ffffff"
                    }, {
                "lightness": 16
                    }]
                }, {
            "featureType": "poi",
            "elementType": "geometry",
            "stylers": [{
                "color": "#f5f5f5"
                    }, {
                "lightness": 21
                    }]
                }, {
            "featureType": "poi.park",
            "elementType": "geometry",
            "stylers": [{
                "color": "#dedede"
                    }, {
                "lightness": 21
                    }]
                }, {
            "elementType": "labels.text.stroke",
            "stylers": [{
                "visibility": "on"
                    }, {
                "color": "#ffffff"
                    }, {
                "lightness": 16
                    }]
                }, {
            "elementType": "labels.text.fill",
            "stylers": [{
                "saturation": 36
                    }, {
                "color": "#333333"
                    }, {
                "lightness": 40
                    }]
                }, {
            "elementType": "labels.icon",
            "stylers": [{
                "visibility": "off"
                    }]
                }, {
            "featureType": "transit",
            "elementType": "geometry",
            "stylers": [{
                "color": "#f2f2f2"
                    }, {
                "lightness": 19
                    }]
                }, {
            "featureType": "administrative",
            "elementType": "geometry.fill",
            "stylers": [{
                "color": "#fefefe"
                    }, {
                "lightness": 20
                    }]
                }, {
            "featureType": "administrative",
            "elementType": "geometry.stroke",
            "stylers": [{
                "color": "#fefefe"
                    }, {
                "lightness": 17
                    }, {
                "weight": 1.2
                    }]
                }
	];    
        
        
	//define the basic color of your map, plus a value for saturation and brightness
	var	main_color = '#222a2c',
		saturation_value= -50,
		brightness_value= -5;
		
	//set google map options
	var map_options = {
      	center: new google.maps.LatLng(latitude, longitude),
      	zoom: map_zoom,
      	panControl: false,
      	zoomControl: false,
      	mapTypeControl: false,
      	streetViewControl: false,
      	mapTypeId: google.maps.MapTypeId.ROADMAP,
      	scrollwheel: false,
        styles: style,
    }
    //inizialize the map
	var map = new google.maps.Map(document.getElementById('google-container'), map_options);
	//add a custom marker to the map				
	var marker = new google.maps.Marker({
	  	position: new google.maps.LatLng(latitude, longitude),
	    map: map,
	    visible: true,
	 	icon: marker_url,
	});

	//add custom buttons for the zoom-in/zoom-out on the map
	function CustomZoomControl(controlDiv, map) {
		//grap the zoom elements from the DOM and insert them in the map 
	  	var controlUIzoomIn= document.getElementById('cd-zoom-in'),
	  		controlUIzoomOut= document.getElementById('cd-zoom-out');
	  	controlDiv.appendChild(controlUIzoomIn);
	  	controlDiv.appendChild(controlUIzoomOut);

		// Setup the click event listeners and zoom-in or out according to the clicked element
		google.maps.event.addDomListener(controlUIzoomIn, 'click', function() {
		    map.setZoom(map.getZoom()+1)
		});
		google.maps.event.addDomListener(controlUIzoomOut, 'click', function() {
		    map.setZoom(map.getZoom()-1)
		});
	}

	var zoomControlDiv = document.createElement('div');
 	var zoomControl = new CustomZoomControl(zoomControlDiv, map);

  	//insert the zoom div on the top left of the map
  	map.controls[google.maps.ControlPosition.LEFT_TOP].push(zoomControlDiv);
});

  

</script>


