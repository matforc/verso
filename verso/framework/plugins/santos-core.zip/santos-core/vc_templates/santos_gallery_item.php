<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
/**
 * Shortcode attributes
 * @var $atts
 * @var $date
 * @var $title
 * @var $image
 * Shortcode class
 * @var $this WPBakeryShortCode_santos_testimonial_carousel_item
 */
 
$date = $title = $image =  '';
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

wp_enqueue_script( 'lightcase');
wp_enqueue_style( 'lightcase');


$default_src = get_template_directory_uri() .'/img/no_image.png' ;
$img_url = wp_get_attachment_image_src( $image, 'full');	
$image_src = $img_url[0] ? esc_attr( $img_url[0] ) : $default_src;

$output = '<!-- single work -->
             <div class="col-md-4 col-sm-6 gallery_item_holder"  data-aos="fade-up" data-aos-once="true">
                 <!-- recent item -->
                    <div class="recentDiv">
					<a  href="'. esc_url($image_src).'" data-rel="lightcase:myCollection-'. get_the_ID().'">
                                            <img src="'.esc_url($image_src).'" alt="" class="img-responsive" />';
									if($date != '' || $title != ''){	
                              $output .= '<div class="recentTitleDiv">
                                                <h3>'.esc_attr($title).'</h3>
                                                <span>'.esc_attr($date).'</span>
                                            </div>';
									}
                                   $output .= '</a>
                                    </div>
                                    <!-- / recent item -->
                                </div>
                           <!-- end single work -->';


echo do_shortcode($output);