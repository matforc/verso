<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
/**
 * Shortcode attributes
 * @var $atts
 * @var $url
 * @var $style
 * @var $title
 * @var $image
 * @var $this WPBakeryShortCode_santos_lightbox_video
 */
 
$url = $image = $title = '';
$style = 'btn';

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

wp_enqueue_script( 'lightcase');
wp_enqueue_style( 'lightcase');

$default_src = get_template_directory_uri() .'/img/no_image.png' ;


$img_id = preg_replace( '/[^\d]/', '', $image );
$img_url = wp_get_attachment_image_src( $img_id, 'full' );

$image_src = $img_url[0] ? esc_attr( $img_url[0] ) : $default_src;

if($style == 'img'){
?>

 <div class="videoBox">
      <a class="playIcon" data-rel="lightcase" href="<?php echo esc_attr( $url ); ?>">
        <i class="fa fa-play" aria-hidden="true"></i>
      </a>
		<img src="<?php echo esc_url($image_src); ?>" class="img-responsive" alt="" />
</div>
<?php
}else{
	?>

		<div class="btnsDiv">
                    <a data-rel="lightcase" href="<?php echo esc_attr( $url ); ?>" class="playVideo">
                        <span class="videoIcon"><i class="fa fa-play" aria-hidden="true"></i></span>
                        <span class="playText"> <?php echo esc_attr( $title ); ?></span>
                    </a>
                </div>
	
	<?php
	
}