<?php
if ( ! defined( 'ABSPATH' ) ) {
die( '-1' );
}
/**
* Shortcode attributes
* @var $atts
* @var $title
* @var $link
* @var $heading_color
* @var $btn_title
* @var btn_style
* @var $btn_title_color
* @var $btn_bg_color
* @var $btn_position
* @var $title_tag
* @var $align
* @var $el_class
* @var enable_btn_2
* @var btn_2_title
* @var btn_2_link
* @var btn_2_style
* @var btn_2_title_color
* @var btn_2_bg_color
* @var $enable_video
* @var $video_url
* @var $video_title
* Shortcode class
* @var $this WPBakeryShortCode_santos_team
*/

$title = $link = $title_color = $btn_title = $btn_style = $btn_title_color = $btn_bg_color = $align = $el_class = '';
$enable_btn_2 = $btn_2_title = $btn_2_link = $btn_2_style = $btn_2_title_color = $btn_2_bg_color =  '';

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$align = 'center';

$id = uniqid();

$link = ( '||' === $link ) ? '' : $link;
$link = vc_build_link( $link );
$a_href = $link['url'] ? $link['url'] : '#';
$a_title = $link['title'];
$a_target = $link['target'] ? $link['target'] : '_self';


$btn_2_link = ( '||' === $btn_2_link ) ? '' : $btn_2_link;
$btn_2_link = vc_build_link( $btn_2_link );
$a_2_href = $btn_2_link['url'] ? $btn_2_link['url'] : '#';
$a_2_title = $btn_2_link['title'];
$a_2_target = $btn_2_link['target'] ? $btn_2_link['target'] : '_self';



$el_class = $this->getExtraClass( $el_class );

$custom_style ='';
if($btn_style == 'outlined'){
$custom_style .= '
#santos_cta_btn_'.$id.' .btn.first{color:'.$btn_title_color.';border:2px solid '.$btn_bg_color.';background:transparent;}
'; 	
}else{
$custom_style .= '
#santos_cta_btn_'.$id.' .btn.first{color:'.$btn_title_color.';background:'.$btn_bg_color.';}
'; 
}


if($btn_2_style == 'outlined'){
$custom_style .= '
#santos_cta_btn_'.$id.' .btn.second{color:'.$btn_2_title_color.';border:2px solid '.$btn_2_bg_color.';background:transparent;}
'; 	
}else{
$custom_style .= '
#santos_cta_btn_'.$id.' .btn.second{color:'.$btn_2_title_color.';background:'.$btn_2_bg_color.';}
'; 
}


santos_add_to_global_styles($custom_style);

if($btn_position == 'bottom'){
?>

<!-- CTA -->
  <div id="santos_cta_btn_<?php echo esc_attr( $id ); ?>" class=" santos_cta_wrapper cta_1 santos_content_element <?php echo esc_attr( trim( $el_class ) ); ?>">
      <div class="cta_btn_inner text-<?php echo esc_attr( $align ); ?>">
            <<?php echo esc_attr($title_tag); ?> <?php if(!empty($title_color)){?> style="color:<?php echo esc_attr($title_color); ?>" <?php } ?> ><?php echo esc_attr( $title ); ?></<?php echo esc_attr($title_tag); ?>>
            <div class="h-30"></div>
			<a href="<?php echo esc_attr( $a_href ); ?>" title="<?php echo esc_attr( $a_title ); ?>" target="<?php echo esc_attr( $a_target ); ?>" class="btn first btn-blue"><?php echo esc_attr( $btn_title ); ?></a>
			
			
			
	<?php
	if ( $enable_btn_2 == 'true' ) {
	?>

		<a href="<?php echo esc_attr( $a_2_href ); ?>" title="<?php echo esc_attr( $a_2_title ); ?>" target="<?php echo esc_attr( $a_2_target ); ?>" class="btn second btn-blue"><?php echo esc_attr( $btn_2_title ); ?></a>
	<?php
	}
	?>
	
	<?php
	if ( $enable_video == 'true' ) {
		
		wp_enqueue_script( 'lightcase');
		wp_enqueue_style( 'lightcase');
		
	?>

			 <a data-rel="lightcase" href="<?php echo esc_attr($video_url); ?>" class="playVideo"><span class="videoIcon"><i class="fa fa-play" aria-hidden="true"></i></span>
               <span class="playText"> <?php echo esc_attr($video_title); ?> </span>
            </a>
	<?php
	}
	?>	
									
      </div>
  </div>
<!-- / CTA -->
<?php	
	
}else{
?>
<!-- CTA -->
  <div id="santos_cta_btn_<?php echo esc_attr( $id ); ?>" class=" santos_cta_wrapper cta_1 <?php echo esc_attr( trim( $el_class ) ); ?>">
      <div class="cta_btn_inner text-<?php echo esc_attr( $align ); ?>">
            <<?php echo esc_attr($title_tag); ?> <?php if(!empty($title_color)){?> style="color:<?php echo esc_attr($title_color); ?>" <?php } ?> ><?php echo esc_attr( $title ); ?></<?php echo esc_attr($title_tag); ?>>
            <a href="<?php echo esc_attr( $a_href ); ?>" title="<?php echo esc_attr( $a_title ); ?>" target="<?php echo esc_attr( $a_target ); ?>" class="btn first btn-blue"><?php echo esc_attr( $btn_title ); ?></a>
	
	
	
				
	<?php
	if ( $enable_btn_2 == 'true' ) {
	?>

		<a href="<?php echo esc_attr( $a_2_href ); ?>" title="<?php echo esc_attr( $a_2_title ); ?>" target="<?php echo esc_attr( $a_2_target ); ?>" class="btn second btn-blue"><?php echo esc_attr( $btn_2_title ); ?></a>
	<?php
	}
	?>
	
	
	<?php
	if ( $enable_video == 'true' ) {
		wp_enqueue_script( 'lightcase');
		wp_enqueue_style( 'lightcase');
	?>

			 <a data-rel="lightcase" href="<?php echo esc_attr($video_url); ?>" class="playVideo"><span class="videoIcon"><i class="fa fa-play" aria-hidden="true"></i></span>
               <span class="playText"> <?php echo esc_attr($video_title); ?> </span>
            </a>
	<?php
	}
	?>	
									
      </div>
  </div>
<!-- / CTA -->

<?php } ?>