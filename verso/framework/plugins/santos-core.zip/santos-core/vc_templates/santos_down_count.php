<?php
if ( ! defined( 'ABSPATH' ) ) {
die( '-1' );
}
/**
* Shortcode attributes
* @var $atts
* @var $day
* @var $month
* @var $year
* @var $count_color
* @var $count_size
* Shortcode class
* @var $this WPBakeryShortCode_santos_down_count
*/
$output = $day = $month = $year = $count_size = $count_color =  '';
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );
?>
<div class="countdown-div text-center">
<ul class="countdown" data-day="<?php echo esc_attr($day); ?>" data-month="<?php echo esc_attr($month); ?>" data-year="<?php echo esc_attr($year); ?>" >
	<li>
	<h2 style="color:<?php echo esc_attr( $count_color ); ?>;font-size:<?php echo esc_attr( $count_size ); ?>px;" class="days">00</h2>
	<p class="days_ref"><?php esc_html_e('days','santos'); ?></p>
	</li>

	<li>
	<h2 style="color:<?php echo esc_attr( $count_color ); ?>;font-size:<?php echo esc_attr( $count_size ); ?>px;" class="hours">00</h2>
	<p class="hours_ref"><?php esc_html_e('hours','santos'); ?></p>
	</li>

	<li>
	<h2 style="color:<?php echo esc_attr( $count_color ); ?>;font-size:<?php echo esc_attr( $count_size ); ?>px;" class="minutes">00</h2>
	<p class="minutes_ref"><?php esc_html_e('minutes','santos'); ?></p>
	</li>

	<li>
	<h2 style="color:<?php echo esc_attr( $count_color ); ?>;font-size:<?php echo esc_attr( $count_size ); ?>px;" class="seconds">00</h2>
	<p class="seconds_ref"><?php esc_html_e('seconds','santos'); ?></p>
	</li>
</ul>
</div><!-- end countdown -->