<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
/**
 * Shortcode attributes
 * @var $atts
 * @var $title
 * @var $number
 * @var $number_size
 * @var $title_color
 * @var $text_color
 * @var $number_color
 * @var $align
 * @var $this WPBakeryShortCode_santos_milestone
 */
 
$title = $number = $title_color = $number_color = $align = '';
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

wp_enqueue_script( 'countTo');

?>

<div class="count-box text-<?php echo esc_attr($align); ?>">
<span style="color:<?php echo esc_attr( $number_color ); ?>;font-size:<?php echo esc_attr( $number_size ); ?>px;line-height:<?php echo esc_attr( ($number_size+10) ); ?>px;" class="count" data-from="0" data-to="<?php echo esc_attr( $number ); ?>"></span>
<h4 class="count-name" style="color:<?php echo esc_attr( $title_color ); ?>;"><?php echo esc_attr( $title ); ?></h4>
 <p style="color:<?php echo esc_attr( $text_color ); ?>;"><?php echo esc_attr( $content ); ?></p>
</div>