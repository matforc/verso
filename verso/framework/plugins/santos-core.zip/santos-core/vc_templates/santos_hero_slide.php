<?php

$args = array(
    "image"         => "",
	"title" => "",
	"title_2" => "",
    "title_color"         => "",
	"description" => "",
    "description_color"         => "",
	"enable_button"         => "",
	"btn_title"         => "",
	"image"         => "",
	"link"         => "",
	"enable_video"         => "",
	"video_url"         => "",
	"video_title"         => "",	
);

extract(shortcode_atts($args, $atts));

$image = wp_get_attachment_image_src( $image, 'full');



$link = ( '||' === $link ) ? '' : $link;
$link = vc_build_link( $link );
$a_href = $link['url'] ? $link['url'] : '#';
$a_title = $link['title'];
$a_target = $link['target'] ? $link['target'] : '_self';






$output = '';


$output .= '<li  data-img-width="100%" data-img-height="1064" data-diff="100" style="background-image: url('.$image[0].');">
                    <div class="container">
                        <div class="flex-box">
                            <div class="interTextDiv">';
							
							if($title !=''){
                              $output .= '<h1 class="title_1" style="color:'.$title_color.';">'.$title.'</h1>';
							}	
								
							if($title_2 !=''){
							$output .= '<h1 class="title_2" style="color:'.$title_color.';">'.$title_2.'</h1>';		
								}
								
                            $output .= '<div class="h-30"></div>
                                <p style="color:'.$description_color.';">'.$description.'</p>
                                <div class="h-30"></div>
                                <div class="btnsDiv">';
							if ( $enable_button == 'true' ) {	
								$output .= '<a href="'.esc_attr( $a_href ).'" title="'. esc_attr( $a_title ).'" target="'. esc_attr( $a_target ).'" class="btn btn-blue">'.esc_attr($btn_title).'</a>';
																
							}		
							if ( $enable_video == 'true' ) {

								wp_enqueue_script( 'lightcase');
								wp_enqueue_style( 'lightcase');
								
								$output .= '<a data-rel="lightcase" href="'.esc_attr($video_url).'" class="playVideo"><span class="videoIcon"><i class="fa fa-play" aria-hidden="true"></i></span>
                                        <span class="playText"> '.esc_attr($video_title).'</span>
                                    </a>';
							}
							
                            $output .= '</div>
                            </div>
                        </div>
                    </div>
                </li>';

echo do_shortcode($output);