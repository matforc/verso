<?php

/**
 * Initialize CPT
 */ 
 
if(!function_exists('santos_portfolio_custom_post_type')  ){
function santos_portfolio_custom_post_type()
{

	$santos_options = get_option('santos_options'); 
	 
	$portfolio_cpt = (isset($santos_options['portfolio_slug']) ) ? $santos_options['portfolio_slug'] : '';

	$base = (isset($portfolio_cpt) && $portfolio_cpt !== '') ? strtolower($portfolio_cpt) : 'portfolio';
	$label = ucfirst($base);
	
    	 
	 $portfolio_labels = array(	
	 	'name' => $label,
		'singular_name' => sprintf(esc_html__('%s Item', 'santos-core' ), $label),
		'all_items' => sprintf(esc_html__('All %s', 'santos-core' ), $label),
		'add_new' => esc_html__('Add New', 'santos-core') ,
		'add_new_item' => sprintf(esc_html__('Add New %s', 'santos-core' ), $label),
		'edit' => esc_html__('Edit', 'santos-core') ,
		'edit_item' => sprintf(esc_html__('Edit %s', 'santos-core' ), $label),
		'new_item' => sprintf(esc_html__('New %s', 'santos-core' ), $label),
		'view_item' => sprintf(esc_html__('View %s', 'santos-core' ), $label),
		'search_items' => sprintf(esc_html__('Search %s', 'santos-core' ), $label),
		'not_found' => esc_html__('Nothing found in the Database.', 'santos-core') ,
		'not_found_in_trash' => esc_html__('Nothing found in Trash', 'santos-core') ,
	 );
	 
	
	

	 $args = array(
			'labels' => $portfolio_labels,
			'rewrite' => array('slug' => $base,'with_front' => false),
			'public' => true,
			'publicly_queryable' => true,
			'exclude_from_search' => false,
			'show_ui' => true,
			'hierarchical' => false,
			'has_archive' => true,
			'capability_type' => 'post',
			'menu_position' => 7,
			'menu_icon' => 'dashicons-portfolio',
			'supports' => array('title', 'editor', 'thumbnail')
			
       );  
  
    register_post_type( 'santos-portfolio' , $args );  



/*-----------------------------------------------------------------#
# Add taxonomys attached to portfolio 
#-----------------------------------------------------------------*/ 

$portfolio_category_labels = array(
	'name' => sprintf(esc_html__( '%s Categories', 'santos-core' ), $label), 
	'singular_name' => sprintf(esc_html__('%s Category', 'santos-core'), $label), 
	'search_items' =>  sprintf(esc_html__( 'Search %s Categories', 'santos-core'), $label), 
	'all_items' => sprintf(esc_html__( 'All %s Categories', 'santos-core'), $label), 
	'parent_item' => sprintf(esc_html__( 'Parent %s Category', 'santos-core'), $label), 
	'parent_item_colon' => sprintf(esc_html__( 'Parent %s Category:', 'santos-core'), $label), 
	'edit_item' => sprintf(esc_html__( 'Edit %s Category', 'santos-core'), $label), 
	'update_item' => sprintf(esc_html__( 'Update %s Category', 'santos-core'), $label), 
	'add_new_item' => sprintf(esc_html__( 'Add New %s Category', 'santos-core'), $label), 
	'new_item_name' => sprintf(esc_html__( 'New %s Category Name', 'santos-core'), $label) 
); 	

register_taxonomy("santos-portfolio-category", 
		array("santos-portfolio"), 
		array("hierarchical" => true, 
				'labels' => $portfolio_category_labels,
				'show_ui' => true,
    			'query_var' => true,
				'rewrite' => array( 'slug' => $base . '_cat' ),
));






add_action( 'admin_menu', 'santos_portfolio_ordering' );
function santos_portfolio_ordering() {
	add_submenu_page(
		'edit.php?post_type=santos-portfolio',
		'Order Portfolio',
		'Order',
		'edit_pages', 'portfolio-order',
		'santos_portfolio_order_page'
	);
}
function santos_portfolio_order_page(){ ?>
	
	<div class="wrap">
		<h2>Sort Portfolio</h2>
		<p>Simply drag the posts up or down and they will be saved in that order.</p>
	<?php $portfolio_items = new WP_Query( array( 'post_type' => 'santos-portfolio', 'posts_per_page' => -1, 'order' => 'ASC', 'orderby' => 'menu_order' ) ); ?>
	<?php if( $portfolio_items->have_posts() ) : ?>
		
		<?php wp_nonce_field( basename(__FILE__), 'santos_meta_box_nonce' ); ?>
		
		<table class="wp-list-table widefat fixed posts sortable-table" id="sortable-portfolio-table">
			<thead>
				<tr>
					<th class="column-order">Order</th>
					<th class="manage-column column-thumbnail">Image</th>
					<th class="manage-column column-caption">Title</th>
				</tr>
			</thead>
			<tbody data-post-type="portfolio">
			<?php while( $portfolio_items->have_posts() ) : $portfolio_items->the_post(); ?>
				<tr id="post-<?php the_ID(); ?>">
				
					<td class="column-order"><img src="<?php echo SANTOS_CORE_URI . '/img/sortable.png'; ?>" title="" alt="Move Icon" width="25" height="25" class="" /></td>
					<td class="thumbnail column-thumbnail">
						<?php 
						global $post;
			
					 $thumbnail = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), "medium" );
				            
					if( !empty($thumbnail) ) {
					  $slide_img = $thumbnail[0];
						echo '<img class="post-thumb" src="' . $slide_img . '" />';
					} else {
						echo '<img class="post-thumb" src="' . SANTOS_CORE_URI . '/img/post-default-thumb.jpg" />';
					} ?>
						
					</td>
					<td class="caption column-caption">
						<?php 
						$caption = get_the_title();
	        			echo $caption; ?>
					</td>
				</tr>
			<?php endwhile; ?>
			</tbody>
			<tfoot>
				<tr>
					<th class="column-order">Order</th>
					<th class="manage-column column-thumbnail">Image</th>
					<th class="manage-column column-caption">Caption</th>
				</tr>
			</tfoot>
		</table>
	<?php else: ?>
		<p>No Portfolio Posts found, why not <a href="post-new.php?post_type=santos-portfolio">create one?</a></p>
	<?php endif; ?>
	<?php wp_reset_postdata(); ?>
	</div><!-- .wrap -->
	
<?php }

add_action( 'admin_enqueue_scripts', 'santos_portfolio_enqueue_scripts' );

function santos_portfolio_enqueue_scripts($hook) {
	
	 if ( 'santos-portfolio_page_portfolio-order' != $hook ) 
        return;
	
	wp_enqueue_script( 'jquery-ui-sortable' );
	wp_enqueue_script( 'santos-portfolio-order', SANTOS_CORE_URI . '/js/portfolio_order.js' );
}
add_action( 'wp_ajax_santos_update_portfolio_order', 'santos_update_portfolio_order' );

/*Portfolio order ajax callback */
function santos_update_portfolio_order() {
	
	    global $wpdb;
	 
	    $post_type     = $_POST['postType'];
	    $order        = $_POST['order'];
		
		if (  !isset($_POST['santos_meta_box_nonce']) || !wp_verify_nonce( $_POST['santos_meta_box_nonce'], basename( __FILE__ ) ) )
			return;
		
	    foreach( $order as $menu_order => $post_id ) {
	        $post_id         = intval( str_ireplace( 'post-', '', $post_id ) );
	        $menu_order     = intval($menu_order);
			
	        wp_update_post( array( 'ID' => stripslashes(htmlspecialchars($post_id)), 'menu_order' => stripslashes(htmlspecialchars($menu_order)) ) );
    	}
 
	    die( '1' );
}
/*order the default Portfolio page correctly */  
function set_santos_portfolio_admin_order($wp_query) {  
  if (is_admin()) {  
  
    $post_type = $wp_query->query['post_type'];  
  
    if ( $post_type == 'santos-portfolio') {  
   
      $wp_query->set('orderby', 'menu_order');  
      $wp_query->set('order', 'ASC');  
    }  
  }  
}  
add_filter('pre_get_posts', 'set_santos_portfolio_admin_order'); 



	
	
}
add_action('init', 'santos_portfolio_custom_post_type');
}
?>